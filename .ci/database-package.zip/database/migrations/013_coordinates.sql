SET search_path = logistica, pg_catalog;

-- ============================================================================
-- 013 · Coordenadas opcionales para el mapa: el cliente puede elegir su direccion con un pin (como Uber) o
--       escribirla a mano. Un pedido o direccion sin pin sigue siendo valido.
--
-- Compatibilidad: solo se agregan columnas nulas y parametros nuevos al final con DEFAULT NULL; las llamadas
-- existentes a place_store_order y create_address siguen funcionando igual. El CHECK exige que latitud y longitud
-- vayan juntas y dentro de Ecuador (incluye Galapagos) para atrapar pines mal puestos.
-- La logica de place_store_order, create_address y update_address es la de 011 mas el manejo de coordenadas.
-- ============================================================================

-- Latitud y longitud validas: ambas nulas (modo manual) o ambas dentro del rectangulo de Ecuador.
CREATE FUNCTION valid_coordinates(p_lat double precision, p_lng double precision) RETURNS boolean
LANGUAGE sql IMMUTABLE AS $$
  SELECT CASE
    WHEN p_lat IS NULL AND p_lng IS NULL THEN true
    WHEN p_lat IS NULL OR p_lng IS NULL THEN false
    ELSE p_lat BETWEEN -5.1 AND 1.5 AND p_lng BETWEEN -92.5 AND -75.0
  END
$$;

ALTER TABLE customer_addresses
  ADD COLUMN latitude double precision,
  ADD COLUMN longitude double precision,
  ADD CONSTRAINT customer_addresses_coordinates_check CHECK (valid_coordinates(latitude, longitude));

ALTER TABLE store_orders
  ADD COLUMN delivery_latitude double precision,
  ADD COLUMN delivery_longitude double precision,
  ADD CONSTRAINT store_orders_coordinates_check CHECK (valid_coordinates(delivery_latitude, delivery_longitude));

-- Se reemplazan las firmas anteriores por las nuevas (mismos nombres, parametros extra con DEFAULT NULL).
DROP FUNCTION place_store_order(uuid, uuid, text, date, time, text, text, text, jsonb, uuid);
DROP FUNCTION create_address(uuid, text, uuid, text, text, text, boolean);

CREATE FUNCTION place_store_order(
  p_customer uuid, p_zone uuid, p_address text, p_date date, p_time time,
  p_recipient text, p_phone text, p_notes text, p_items jsonb, p_key uuid,
  p_lat double precision DEFAULT NULL, p_lng double precision DEFAULT NULL
) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path = logistica, pg_temp AS $$
DECLARE
  op operation_requests;
  v_settings store_settings;
  v_items jsonb;
  v_ids uuid[];
  v_lines integer;
  v_conflicts jsonb := '[]'::jsonb;
  v_result jsonb;
  v_order uuid;
  v_total bigint;
  v_count integer;
  v_reserved integer;
  v_zone_active boolean;
  r record;
BEGIN
  IF p_customer IS NULL OR p_zone IS NULL OR p_date IS NULL OR p_time IS NULL OR p_address IS NULL THEN
    RAISE EXCEPTION 'INVALID_ORDER' USING ERRCODE = '22023';
  END IF;
  IF NOT valid_coordinates(p_lat, p_lng) THEN RAISE EXCEPTION 'INVALID_COORDINATES' USING ERRCODE = '22023'; END IF;
  IF jsonb_typeof(p_items) IS DISTINCT FROM 'array' THEN RAISE EXCEPTION 'INVALID_ITEMS' USING ERRCODE = '22023'; END IF;
  v_lines := jsonb_array_length(p_items);
  IF v_lines NOT BETWEEN 1 AND 20 THEN RAISE EXCEPTION 'INVALID_ITEMS' USING ERRCODE = '22023'; END IF;

  -- Normaliza y ordena las lineas: el mismo contenido produce siempre el mismo hash de idempotencia.
  SELECT jsonb_agg(jsonb_build_object('productId', x.pid, 'quantity', x.qty, 'unitPriceCents', x.price) ORDER BY x.pid)
    INTO v_items
    FROM (SELECT (e ->> 'productId')::uuid AS pid, (e ->> 'quantity')::integer AS qty, (e ->> 'unitPriceCents')::integer AS price
            FROM jsonb_array_elements(p_items) e) x;
  IF EXISTS (SELECT 1 FROM jsonb_to_recordset(v_items) AS t("productId" uuid, quantity integer, "unitPriceCents" integer)
              WHERE t."productId" IS NULL OR t.quantity IS NULL OR t.quantity NOT BETWEEN 1 AND 10
                 OR t."unitPriceCents" IS NULL OR t."unitPriceCents" < 1)
     OR (SELECT count(DISTINCT t."productId") FROM jsonb_to_recordset(v_items) AS t("productId" uuid)) <> v_lines THEN
    RAISE EXCEPTION 'INVALID_ITEMS' USING ERRCODE = '22023';
  END IF;

  op := begin_request('store-order:' || p_customer::text, p_key, jsonb_build_object(
          'zone', p_zone, 'address', btrim(p_address), 'date', p_date, 'time', p_time,
          'recipient', p_recipient, 'phone', p_phone, 'notes', p_notes, 'items', v_items,
          'lat', p_lat, 'lng', p_lng));
  IF op.status = 'completada' THEN
    RETURN op.response_body || jsonb_build_object('replayed', true);
  END IF;

  PERFORM 1 FROM app_users WHERE id = p_customer AND role = 'cliente' AND is_active;
  IF NOT FOUND THEN RAISE EXCEPTION 'CUSTOMER_USER_NOT_FOUND' USING ERRCODE = '23503'; END IF;
  SELECT is_active INTO v_zone_active FROM zones WHERE id = p_zone;
  IF NOT FOUND THEN RAISE EXCEPTION 'ZONE_NOT_FOUND' USING ERRCODE = '23503'; END IF;

  SELECT * INTO v_settings FROM store_settings;

  -- Franja valida: hora en punto, dentro del horario y con la anticipacion minima.
  IF NOT v_zone_active THEN
    v_conflicts := jsonb_build_array(jsonb_build_object('reason', 'zone_inactive'));
  ELSIF extract(minute FROM p_time) <> 0 OR extract(second FROM p_time) <> 0
     OR extract(hour FROM p_time) NOT BETWEEN v_settings.first_slot_hour AND v_settings.last_slot_hour THEN
    v_conflicts := jsonb_build_array(jsonb_build_object('reason', 'slot_invalid'));
  ELSIF (p_date + p_time) < ((clock_timestamp() AT TIME ZONE 'America/Guayaquil') + make_interval(mins => v_settings.min_lead_minutes)) THEN
    v_conflicts := jsonb_build_array(jsonb_build_object('reason', 'slot_unavailable'));
  END IF;

  IF jsonb_array_length(v_conflicts) = 0 THEN
    PERFORM pg_advisory_xact_lock(hashtextextended('slot:' || p_zone::text || ':' || p_date::text || ':' || extract(hour FROM p_time)::integer::text, 0));
    SELECT count(*) INTO v_reserved FROM orders
     WHERE zone_id = p_zone AND delivery_date = p_date AND extract(hour FROM delivery_time) = extract(hour FROM p_time)
       AND status <> 'cancelado';
    IF v_reserved >= v_settings.slot_capacity THEN
      v_conflicts := jsonb_build_array(jsonb_build_object('reason', 'slot_full', 'capacity', v_settings.slot_capacity));
    END IF;
  END IF;

  IF jsonb_array_length(v_conflicts) = 0 THEN
    -- Bloqueo en orden de id (evita interbloqueos entre compras con los mismos productos) y comprobacion ya bloqueada.
    SELECT array_agg(t."productId" ORDER BY t."productId") INTO v_ids
      FROM jsonb_to_recordset(v_items) AS t("productId" uuid);
    PERFORM 1 FROM products WHERE id = ANY (v_ids) ORDER BY id FOR UPDATE;

    FOR r IN
      SELECT t."productId" AS product_id, t.quantity, t."unitPriceCents" AS expected_price,
             p.id AS found_id, p.price_cents, p.stock_quantity,
             (p.is_active AND coalesce(c.is_active, false)) AS orderable
        FROM jsonb_to_recordset(v_items) AS t("productId" uuid, quantity integer, "unitPriceCents" integer)
        LEFT JOIN products p ON p.id = t."productId"
        LEFT JOIN categories c ON c.id = p.category_id
       ORDER BY t."productId"
    LOOP
      IF r.found_id IS NULL OR NOT r.orderable THEN
        v_conflicts := v_conflicts || jsonb_build_object('productId', r.product_id, 'reason', 'unavailable');
      ELSIF r.price_cents <> r.expected_price THEN
        v_conflicts := v_conflicts || jsonb_build_object('productId', r.product_id, 'reason', 'price_changed', 'currentPriceCents', r.price_cents);
      ELSIF r.stock_quantity < r.quantity THEN
        v_conflicts := v_conflicts || jsonb_build_object('productId', r.product_id, 'reason', 'insufficient_stock', 'available', r.stock_quantity);
      END IF;
    END LOOP;
  END IF;

  IF jsonb_array_length(v_conflicts) > 0 THEN
    v_result := jsonb_build_object('status', 'conflict', 'conflicts', v_conflicts, 'replayed', false);
    PERFORM finish_request(op.id, v_result);
    RETURN v_result;
  END IF;

  v_order := create_order_for_customer(p_zone, p_address, p_date, p_time, p_recipient, p_phone, p_notes, p_customer);

  INSERT INTO order_items(order_id, product_id, sku, product_name, unit_price_cents, quantity)
    SELECT v_order, p.id, p.sku, p.name, p.price_cents, t.quantity
      FROM jsonb_to_recordset(v_items) AS t("productId" uuid, quantity integer, "unitPriceCents" integer)
      JOIN products p ON p.id = t."productId";

  UPDATE products p
     SET stock_quantity = p.stock_quantity - t.quantity, updated_at = clock_timestamp()
    FROM jsonb_to_recordset(v_items) AS t("productId" uuid, quantity integer, "unitPriceCents" integer)
   WHERE p.id = t."productId";

  INSERT INTO stock_movements(product_id, order_id, delta, reason, balance_after, actor_user_id)
    SELECT p.id, v_order, -t.quantity, 'sale', p.stock_quantity, p_customer
      FROM jsonb_to_recordset(v_items) AS t("productId" uuid, quantity integer, "unitPriceCents" integer)
      JOIN products p ON p.id = t."productId";

  SELECT sum(line_total_cents), count(*) INTO v_total, v_count FROM order_items WHERE order_id = v_order;
  INSERT INTO store_orders(order_id, customer_user_id, total_cents, items_count, delivery_latitude, delivery_longitude)
    VALUES (v_order, p_customer, v_total, v_count, p_lat, p_lng);

  v_result := jsonb_build_object('status', 'ok', 'orderId', v_order, 'totalCents', v_total, 'itemsCount', v_count, 'replayed', false);
  PERFORM finish_request(op.id, v_result);
  RETURN v_result;
END $$;

CREATE FUNCTION create_address(p_user uuid, p_label text, p_zone uuid, p_address text, p_recipient text, p_phone text, p_default boolean,
  p_lat double precision DEFAULT NULL, p_lng double precision DEFAULT NULL) RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path = logistica, pg_temp AS $$
DECLARE v_id uuid; v_count integer; v_default boolean;
BEGIN
  PERFORM 1 FROM app_users WHERE id = p_user AND role = 'cliente' AND is_active FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'UNAUTHORIZED_ACTOR' USING ERRCODE = '42501'; END IF;
  IF NOT valid_coordinates(p_lat, p_lng) THEN RAISE EXCEPTION 'INVALID_COORDINATES' USING ERRCODE = '22023'; END IF;
  PERFORM 1 FROM zones WHERE id = p_zone AND is_active;
  IF NOT FOUND THEN RAISE EXCEPTION 'ZONE_NOT_FOUND' USING ERRCODE = '23503'; END IF;
  SELECT count(*) INTO v_count FROM customer_addresses WHERE user_id = p_user;
  IF v_count >= 10 THEN RAISE EXCEPTION 'ADDRESS_LIMIT' USING ERRCODE = 'LG413'; END IF;
  v_default := coalesce(p_default, false) OR v_count = 0;
  IF v_default THEN UPDATE customer_addresses SET is_default = false, version = version + 1, updated_at = clock_timestamp() WHERE user_id = p_user AND is_default; END IF;
  INSERT INTO customer_addresses(user_id, label, zone_id, address, recipient_name, recipient_phone, is_default, latitude, longitude)
    VALUES (p_user, btrim(p_label), p_zone, btrim(p_address), NULLIF(btrim(coalesce(p_recipient, '')), ''), p_phone, v_default, p_lat, p_lng) RETURNING id INTO v_id;
  RETURN v_id;
END $$;

CREATE OR REPLACE FUNCTION update_address(p_id uuid, p_user uuid, p_patch jsonb, p_expected_version bigint) RETURNS bigint
LANGUAGE plpgsql SECURITY DEFINER SET search_path = logistica, pg_temp AS $$
DECLARE a customer_addresses; v_version bigint;
BEGIN
  IF jsonb_typeof(p_patch) IS DISTINCT FROM 'object' OR p_patch = '{}'::jsonb
     OR EXISTS (SELECT 1 FROM jsonb_object_keys(p_patch) k WHERE k NOT IN ('label', 'zoneId', 'address', 'recipientName', 'recipientPhone', 'isDefault', 'latitude', 'longitude')) THEN
    RAISE EXCEPTION 'INVALID_PATCH' USING ERRCODE = '22023';
  END IF;
  PERFORM 1 FROM app_users WHERE id = p_user AND role = 'cliente' AND is_active FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'UNAUTHORIZED_ACTOR' USING ERRCODE = '42501'; END IF;
  SELECT * INTO a FROM customer_addresses WHERE id = p_id AND user_id = p_user FOR UPDATE;
  IF a.id IS NULL THEN RAISE EXCEPTION 'ADDRESS_NOT_FOUND' USING ERRCODE = 'LG404'; END IF;
  IF a.version <> p_expected_version THEN RAISE EXCEPTION 'VERSION_CONFLICT' USING ERRCODE = 'LG409'; END IF;
  -- Las coordenadas van juntas: el parche trae las dos (valores) o las dos en null (borrar el pin).
  IF (p_patch ? 'latitude') <> (p_patch ? 'longitude') THEN RAISE EXCEPTION 'INVALID_COORDINATES' USING ERRCODE = '22023'; END IF;
  IF p_patch ? 'latitude' AND NOT valid_coordinates(
       NULLIF(p_patch ->> 'latitude', '')::double precision, NULLIF(p_patch ->> 'longitude', '')::double precision) THEN
    RAISE EXCEPTION 'INVALID_COORDINATES' USING ERRCODE = '22023';
  END IF;
  IF p_patch ? 'zoneId' THEN
    PERFORM 1 FROM zones WHERE id = (p_patch ->> 'zoneId')::uuid AND is_active;
    IF NOT FOUND THEN RAISE EXCEPTION 'ZONE_NOT_FOUND' USING ERRCODE = '23503'; END IF;
  END IF;
  IF p_patch ? 'isDefault' THEN
    IF (p_patch ->> 'isDefault')::boolean THEN
      UPDATE customer_addresses SET is_default = false, version = version + 1, updated_at = clock_timestamp() WHERE user_id = p_user AND is_default AND id <> p_id;
    ELSIF a.is_default THEN
      RAISE EXCEPTION 'DEFAULT_REQUIRED' USING ERRCODE = '22023';
    END IF;
  END IF;
  UPDATE customer_addresses SET
    label = CASE WHEN p_patch ? 'label' THEN btrim(p_patch ->> 'label') ELSE label END,
    zone_id = CASE WHEN p_patch ? 'zoneId' THEN (p_patch ->> 'zoneId')::uuid ELSE zone_id END,
    address = CASE WHEN p_patch ? 'address' THEN btrim(p_patch ->> 'address') ELSE address END,
    recipient_name = CASE WHEN p_patch ? 'recipientName' THEN NULLIF(btrim(coalesce(p_patch ->> 'recipientName', '')), '') ELSE recipient_name END,
    recipient_phone = CASE WHEN p_patch ? 'recipientPhone' THEN NULLIF(p_patch ->> 'recipientPhone', '') ELSE recipient_phone END,
    is_default = CASE WHEN p_patch ? 'isDefault' THEN (p_patch ->> 'isDefault')::boolean ELSE is_default END,
    latitude = CASE WHEN p_patch ? 'latitude' THEN NULLIF(p_patch ->> 'latitude', '')::double precision ELSE latitude END,
    longitude = CASE WHEN p_patch ? 'longitude' THEN NULLIF(p_patch ->> 'longitude', '')::double precision ELSE longitude END,
    version = version + 1, updated_at = clock_timestamp()
  WHERE id = p_id RETURNING version INTO v_version;
  RETURN v_version;
END $$;

REVOKE ALL ON FUNCTION
  logistica.valid_coordinates(double precision, double precision),
  logistica.place_store_order(uuid, uuid, text, date, time, text, text, text, jsonb, uuid, double precision, double precision),
  logistica.create_address(uuid, text, uuid, text, text, text, boolean, double precision, double precision)
FROM PUBLIC;

GRANT EXECUTE ON FUNCTION
  logistica.valid_coordinates(double precision, double precision),
  logistica.place_store_order(uuid, uuid, text, date, time, text, text, text, jsonb, uuid, double precision, double precision),
  logistica.create_address(uuid, text, uuid, text, text, text, boolean, double precision, double precision)
TO logistica_app;
