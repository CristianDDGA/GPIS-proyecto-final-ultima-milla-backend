SET search_path = logistica, pg_catalog;

-- ============================================================================
-- 012 · Las comprobaciones de consistencia que se disparan al confirmar la transaccion corren con los permisos
--       del dueno, igual que el resto de funciones de escritura.
--
-- Problema: dispatch_consistency() es el disparador diferido (se ejecuta al COMMIT) de pedidos, rutas, paradas,
-- repartidores y usuarios. Llama a assert_order() y assert_route(), que hacen SELECT ... FOR UPDATE / FOR SHARE.
-- Como la funcion corria con los permisos de quien confirma (logistica_app, que solo puede leer las tablas), en un
-- PostgreSQL donde las funciones nuevas no son ejecutables por PUBLIC (Supabase) toda escritura de pedidos o rutas
-- fallaba al confirmar con "permission denied for function assert_order" (42501). Las pruebas locales no lo detectaban.
--
-- Solucion: dispatch_consistency() pasa a SECURITY DEFINER con search_path fijo. Asi assert_order/assert_route se
-- ejecutan como el dueno y el rol de la API no necesita ningun permiso nuevo. La logica de las comprobaciones no cambia.
-- ============================================================================
ALTER FUNCTION dispatch_consistency() SECURITY DEFINER SET search_path = logistica, pg_temp;
