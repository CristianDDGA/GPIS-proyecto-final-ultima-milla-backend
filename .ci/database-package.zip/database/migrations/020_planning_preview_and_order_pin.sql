SET search_path = logistica, pg_catalog;

-- ============================================================================
-- 020 · Vista previa de la planificacion y pin en los pedidos del administrador.
--
-- 1. preview_routes(fecha, capacidad): dice, sin modificar nada, cuantas rutas y de que tamano saldrian por zona si se
--    generara el plan ahora. Usa la misma regla que generate_routes (zonas activas, pedidos pendientes de la fecha,
--    rutas llenas hasta la capacidad en orden de hora), y la prueba SQL compara ambas.
--
-- 2. Los pedidos del administrador (orders) pueden llevar un pin: delivery_latitude / delivery_longitude, opcionales y
--    validados con valid_coordinates (013). create_order_with_pin los crea; create_order sigue igual (sin pin).
--    Las funciones de rutas (016) leian las coordenadas solo de store_orders; ahora usan el pin del pedido cuando no es
--    de tienda. Para pedidos sin pin nada cambia (la distancia cuenta 0 y manda la hora).
--
-- Compatibilidad: no se eliminan ni se cambian firmas; CREATE OR REPLACE conserva las de sequence_route_stops,
-- courier_dispatch_score y place_late_order.
-- ============================================================================

-- ------------------------------ Pin del pedido ------------------------------
ALTER TABLE orders
  ADD COLUMN delivery_latitude double precision,
  ADD COLUMN delivery_longitude double precision,
  ADD CONSTRAINT orders_coordinates_check CHECK (valid_coordinates(delivery_latitude, delivery_longitude));

CREATE FUNCTION create_order_with_pin(
  p_zone uuid, p_address text, p_date date, p_time time, p_lat double precision, p_lng double precision,
  p_recipient text DEFAULT NULL, p_phone text DEFAULT NULL, p_notes text DEFAULT NULL
) RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path = logistica, pg_temp AS $$
DECLARE result uuid;
BEGIN
  IF p_lat IS NULL OR p_lng IS NULL OR NOT valid_coordinates(p_lat, p_lng) THEN
    RAISE EXCEPTION 'INVALID_COORDINATES' USING ERRCODE = '22023';
  END IF;
  IF p_time IS NOT NULL AND extract(second FROM p_time) <> 0 THEN RAISE EXCEPTION 'INVALID_DELIVERY_TIME' USING ERRCODE = '22007'; END IF;
  IF p_date < (clock_timestamp() AT TIME ZONE 'America/Guayaquil')::date THEN
    RAISE EXCEPTION 'DELIVERY_DATE_IN_PAST' USING ERRCODE = '22007';
  END IF;
  PERFORM set_config('logistica.source', 'web', true);
  PERFORM set_config('logistica.actor_subject', '', true);
  INSERT INTO orders(zone_id, delivery_address, delivery_date, delivery_time, recipient_name, recipient_phone, notes, delivery_latitude, delivery_longitude)
    VALUES (p_zone, btrim(p_address), p_date, p_time, p_recipient, p_phone, p_notes, p_lat, p_lng) RETURNING id INTO result;
  RETURN result;
END $$;

-- Ordena las paradas por vecino mas cercano con penalizacion horaria; el pin es el de tienda o, si no, el del pedido.
CREATE OR REPLACE FUNCTION sequence_route_stops(p_route uuid) RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = logistica, pg_temp AS $$
DECLARE
  n integer; i integer; ordered uuid[] := '{}'; nxt record;
  cur_lat double precision; cur_lng double precision; cur_time time;
BEGIN
  SELECT count(*) INTO n FROM route_stops WHERE route_id = p_route AND released_at IS NULL;
  IF n < 2 THEN RETURN; END IF;
  FOR i IN 1..n LOOP
    SELECT s.order_id AS order_id, o.delivery_time AS delivery_time,
           coalesce(so.delivery_latitude, o.delivery_latitude) AS lat,
           coalesce(so.delivery_longitude, o.delivery_longitude) AS lng
      INTO nxt
      FROM route_stops s
      JOIN orders o ON o.id = s.order_id
      LEFT JOIN store_orders so ON so.order_id = s.order_id
     WHERE s.route_id = p_route AND s.released_at IS NULL AND s.order_id <> ALL (ordered)
     ORDER BY CASE WHEN i = 1 THEN 0 ELSE
                coalesce(distance_km(cur_lat, cur_lng,
                           coalesce(so.delivery_latitude, o.delivery_latitude),
                           coalesce(so.delivery_longitude, o.delivery_longitude)), 0)
                + 5 * abs(extract(epoch FROM (o.delivery_time - cur_time)) / 3600.0)
              END,
              o.delivery_time, o.id
     LIMIT 1;
    ordered := ordered || nxt.order_id;
    cur_lat := nxt.lat; cur_lng := nxt.lng; cur_time := nxt.delivery_time;
  END LOOP;
  PERFORM reorder_route(p_route, ordered);
END $$;

-- Puntaje de un conductor para atender un pedido (menor es mejor): distancia desde su ultima entrega del dia + carga.
CREATE OR REPLACE FUNCTION courier_dispatch_score(p_courier uuid, p_date date, p_lat double precision, p_lng double precision)
RETURNS double precision LANGUAGE sql STABLE SECURITY DEFINER SET search_path = logistica, pg_temp AS $$
  SELECT coalesce(distance_km(last_stop.lat, last_stop.lng, p_lat, p_lng), 0)
         + 3.0 * (
           SELECT count(*) FROM routes r JOIN route_stops s ON s.route_id = r.id
            WHERE r.courier_id = p_courier AND r.service_date = p_date AND r.status = 'completada'
         )
    FROM (SELECT 1) base
    LEFT JOIN LATERAL (
      SELECT coalesce(so.delivery_latitude, o.delivery_latitude) AS lat, coalesce(so.delivery_longitude, o.delivery_longitude) AS lng
        FROM routes r
        JOIN route_stops s ON s.route_id = r.id
        JOIN orders o ON o.id = s.order_id AND o.status = 'entregado'
        LEFT JOIN store_orders so ON so.order_id = o.id
       WHERE r.courier_id = p_courier AND r.service_date = p_date
         AND (so.order_id IS NOT NULL OR o.delivery_latitude IS NOT NULL)
       ORDER BY o.delivered_at DESC, o.id
       LIMIT 1
    ) last_stop ON true
$$;

CREATE OR REPLACE FUNCTION place_late_order(p_order uuid, p_capacity integer, p_key uuid) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path = logistica, pg_temp AS $$
DECLARE op operation_requests; o orders; r_id uuid; c couriers; result jsonb; o_lat double precision; o_lng double precision;
BEGIN
  IF p_capacity IS NULL OR p_capacity < 1 THEN RAISE EXCEPTION 'INVALID_CAPACITY' USING ERRCODE = '22023'; END IF;
  op = begin_request('late:' || p_order::text, p_key, jsonb_build_object('orderId', p_order, 'capacity', p_capacity));
  IF op.status = 'completada' THEN RETURN op.response_body; END IF;
  SELECT * INTO o FROM orders WHERE id = p_order;
  IF o.id IS NULL THEN RAISE EXCEPTION 'ORDER_NOT_FOUND' USING ERRCODE = 'P0002'; END IF;
  PERFORM pg_advisory_xact_lock(hashtextextended('plan:' || o.delivery_date::text, 0));
  IF o.status <> 'pendiente' THEN RAISE EXCEPTION 'ORDER_ALREADY_ASSIGNED' USING ERRCODE = '23514'; END IF;
  SELECT coalesce(so.delivery_latitude, o.delivery_latitude), coalesce(so.delivery_longitude, o.delivery_longitude)
    INTO o_lat, o_lng FROM (SELECT 1) base LEFT JOIN store_orders so ON so.order_id = p_order;
  SELECT r.id INTO r_id FROM routes r WHERE r.zone_id = o.zone_id AND r.service_date = o.delivery_date AND r.status IN ('planificada', 'asignada')
    AND (SELECT count(*) FROM route_stops WHERE route_id = r.id AND released_at IS NULL) < r.capacity_limit
    ORDER BY (SELECT min(distance_km(coalesce(so2.delivery_latitude, o2.delivery_latitude), coalesce(so2.delivery_longitude, o2.delivery_longitude), o_lat, o_lng))
                FROM route_stops s JOIN orders o2 ON o2.id = s.order_id LEFT JOIN store_orders so2 ON so2.order_id = s.order_id
               WHERE s.route_id = r.id AND s.released_at IS NULL) NULLS LAST,
             r.created_at, r.id LIMIT 1 FOR UPDATE OF r SKIP LOCKED;
  IF r_id IS NULL THEN
    SELECT * INTO c FROM couriers x WHERE x.is_enabled AND x.is_available AND NOT EXISTS (
      SELECT 1 FROM routes WHERE courier_id = x.id AND status IN ('asignada', 'en_curso')
    ) ORDER BY courier_dispatch_score(x.id, o.delivery_date, o_lat, o_lng), x.id LIMIT 1 FOR UPDATE OF x SKIP LOCKED;
    IF c.id IS NULL THEN
      result = jsonb_build_object('status', 'pendiente', 'reason', 'NO_AVAILABLE_COURIER', 'orderId', p_order);
      PERFORM finish_request(op.id, result); RETURN result;
    END IF;
    r_id = create_route(o.zone_id, o.delivery_date, least(p_capacity, c.max_orders_per_trip), 'zona_hora_nn_v2');
    PERFORM add_order_to_route(r_id, p_order); PERFORM assign_route(r_id, c.id);
  ELSE
    PERFORM add_order_to_route(r_id, p_order);
    PERFORM sequence_route_stops(r_id);
  END IF;
  result = jsonb_build_object('status', 'asignado_a_ruta', 'routeId', r_id, 'orderId', p_order);
  PERFORM finish_request(op.id, result); RETURN result;
END $$;

-- --------------------------- Vista previa del plan ---------------------------
-- Solo lectura. routeSizes: el tamano de cada ruta que se crearia, en el orden en que se llenan.
CREATE FUNCTION preview_routes(p_date date, p_capacity integer) RETURNS jsonb
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = logistica, pg_temp AS $$
DECLARE v_zones jsonb; v_total_orders integer; v_total_routes integer; v_couriers integer;
BEGIN
  IF p_date IS NULL OR p_capacity IS NULL OR p_capacity < 1 THEN RAISE EXCEPTION 'INVALID_PLAN_PARAMETERS' USING ERRCODE = '22023'; END IF;

  SELECT coalesce(jsonb_agg(jsonb_build_object(
           'zoneId', t.id, 'zoneName', t.name, 'orders', t.n,
           'routes', ceil(t.n::numeric / p_capacity)::integer,
           'routeSizes', (SELECT jsonb_agg(least(p_capacity, t.n - (g - 1) * p_capacity) ORDER BY g)
                            FROM generate_series(1, ceil(t.n::numeric / p_capacity)::integer) g)
         ) ORDER BY t.name, t.id), '[]'::jsonb),
         coalesce(sum(t.n), 0)::integer,
         coalesce(sum(ceil(t.n::numeric / p_capacity)), 0)::integer
    INTO v_zones, v_total_orders, v_total_routes
    FROM (SELECT z.id, z.name, count(o.id)::integer AS n
            FROM zones z
            JOIN orders o ON o.zone_id = z.id AND o.delivery_date = p_date AND o.status = 'pendiente'
           WHERE z.is_active
           GROUP BY z.id, z.name) t;

  SELECT count(*)::integer INTO v_couriers FROM couriers x
   WHERE x.is_enabled AND x.is_available
     AND NOT EXISTS (SELECT 1 FROM routes WHERE courier_id = x.id AND status IN ('asignada', 'en_curso'));

  RETURN jsonb_build_object('date', p_date, 'capacity', p_capacity, 'zones', v_zones,
                            'totalOrders', v_total_orders, 'totalRoutes', v_total_routes, 'availableCouriers', v_couriers);
END $$;

REVOKE ALL ON FUNCTION
  logistica.create_order_with_pin(uuid, text, date, time, double precision, double precision, text, text, text),
  logistica.preview_routes(date, integer)
FROM PUBLIC;

GRANT EXECUTE ON FUNCTION
  logistica.create_order_with_pin(uuid, text, date, time, double precision, double precision, text, text, text),
  logistica.preview_routes(date, integer)
TO logistica_app;
