SET search_path = logistica, pg_catalog;

-- Verificación de correo, recuperación de clave y cierre de sesiones por usuario.
-- Solo se verifica por código quien se registra por su cuenta; las cuentas creadas por un
-- administrador nacen verificadas ('admin') y las anteriores a esta migración quedan 'legacy'.

ALTER TABLE app_users
  ADD COLUMN IF NOT EXISTS email_verified_at timestamptz,
  ADD COLUMN IF NOT EXISTS email_verified_via text,
  ADD COLUMN IF NOT EXISTS tokens_valid_after timestamptz;

ALTER TABLE app_users DROP CONSTRAINT IF EXISTS app_users_email_verified_via_check;
ALTER TABLE app_users ADD CONSTRAINT app_users_email_verified_via_check CHECK (
  (email_verified_at IS NULL AND email_verified_via IS NULL)
  OR (email_verified_at IS NOT NULL AND email_verified_via IN ('code', 'admin', 'legacy', 'demo'))
);

UPDATE app_users
  SET email_verified_at = clock_timestamp(), email_verified_via = 'legacy'
  WHERE email_verified_at IS NULL;

-- Un código vigente por usuario y propósito. Solo se guarda su hash; nunca el código.
CREATE TABLE IF NOT EXISTS email_codes (
  user_id uuid NOT NULL REFERENCES app_users(id) ON DELETE CASCADE,
  purpose text NOT NULL CHECK (purpose IN ('verify_email', 'reset_password')),
  code_hash text NOT NULL CHECK (code_hash ~ '^[0-9a-f]{64}$'),
  expires_at timestamptz NOT NULL,
  attempts integer NOT NULL DEFAULT 0 CHECK (attempts >= 0),
  sent_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  PRIMARY KEY (user_id, purpose)
);

CREATE INDEX IF NOT EXISTS email_codes_expires_idx ON email_codes (expires_at);

-- Alta de cuentas de confianza (creadas por un administrador o en modo demo): nacen verificadas.
CREATE FUNCTION register_trusted_app_user(
  p_auth_subject text,
  p_email text,
  p_password_hash text,
  p_role text,
  p_display_name text,
  p_via text
) RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path=logistica,pg_temp AS $$
DECLARE
  v_id uuid;
BEGIN
  IF p_via NOT IN ('admin', 'demo') THEN
    RAISE EXCEPTION 'INVALID_VERIFICATION_SOURCE' USING ERRCODE='22023';
  END IF;
  v_id := register_app_user(p_auth_subject, p_email, p_password_hash, p_role, p_display_name);
  UPDATE app_users
    SET email_verified_at = clock_timestamp(), email_verified_via = p_via
    WHERE id = v_id;
  RETURN v_id;
END $$;

-- Emite (o reemplaza) el código del usuario. Devuelve 'COOLDOWN' si se pidió hace menos de 60 s.
CREATE FUNCTION issue_email_code(
  p_user uuid,
  p_purpose text,
  p_code_hash text,
  p_ttl_seconds integer
) RETURNS text
LANGUAGE plpgsql SECURITY DEFINER SET search_path=logistica,pg_temp AS $$
DECLARE
  v_sent timestamptz;
BEGIN
  IF p_purpose NOT IN ('verify_email', 'reset_password')
     OR p_ttl_seconds IS NULL OR p_ttl_seconds NOT BETWEEN 60 AND 3600 THEN
    RAISE EXCEPTION 'INVALID_CODE_REQUEST' USING ERRCODE='22023';
  END IF;
  SELECT sent_at INTO v_sent FROM email_codes WHERE user_id = p_user AND purpose = p_purpose FOR UPDATE;
  IF FOUND AND v_sent > clock_timestamp() - interval '60 seconds' THEN
    RETURN 'COOLDOWN';
  END IF;
  INSERT INTO email_codes(user_id, purpose, code_hash, expires_at)
    VALUES (p_user, p_purpose, p_code_hash, clock_timestamp() + make_interval(secs => p_ttl_seconds))
    ON CONFLICT (user_id, purpose) DO UPDATE
      SET code_hash = EXCLUDED.code_hash,
          expires_at = EXCLUDED.expires_at,
          attempts = 0,
          sent_at = clock_timestamp();
  RETURN 'OK';
END $$;

-- Interna: valida y consume el código. Cinco fallos lo invalidan. Devuelve OK | INVALID | EXPIRED | LOCKED.
-- Devuelve texto (no lanza excepciones) para que el contador de intentos se conserve.
CREATE FUNCTION consume_email_code(p_user uuid, p_purpose text, p_code_hash text) RETURNS text
LANGUAGE plpgsql SECURITY DEFINER SET search_path=logistica,pg_temp AS $$
DECLARE
  r email_codes;
BEGIN
  SELECT * INTO r FROM email_codes WHERE user_id = p_user AND purpose = p_purpose FOR UPDATE;
  IF NOT FOUND THEN
    RETURN 'INVALID';
  END IF;
  IF r.expires_at <= clock_timestamp() THEN
    DELETE FROM email_codes WHERE user_id = p_user AND purpose = p_purpose;
    RETURN 'EXPIRED';
  END IF;
  IF r.code_hash <> p_code_hash THEN
    IF r.attempts + 1 >= 5 THEN
      DELETE FROM email_codes WHERE user_id = p_user AND purpose = p_purpose;
      RETURN 'LOCKED';
    END IF;
    UPDATE email_codes SET attempts = attempts + 1 WHERE user_id = p_user AND purpose = p_purpose;
    RETURN 'INVALID';
  END IF;
  DELETE FROM email_codes WHERE user_id = p_user AND purpose = p_purpose;
  RETURN 'OK';
END $$;

CREATE FUNCTION confirm_email(p_user uuid, p_code_hash text) RETURNS text
LANGUAGE plpgsql SECURITY DEFINER SET search_path=logistica,pg_temp AS $$
DECLARE
  v_result text;
BEGIN
  v_result := consume_email_code(p_user, 'verify_email', p_code_hash);
  IF v_result = 'OK' THEN
    UPDATE app_users
      SET email_verified_at = clock_timestamp(), email_verified_via = 'code'
      WHERE id = p_user AND email_verified_at IS NULL;
  END IF;
  RETURN v_result;
END $$;

-- Restablece la clave con un código válido y cierra las sesiones anteriores.
CREATE FUNCTION reset_password_with_code(p_user uuid, p_code_hash text, p_new_password_hash text) RETURNS text
LANGUAGE plpgsql SECURITY DEFINER SET search_path=logistica,pg_temp AS $$
DECLARE
  v_result text;
BEGIN
  IF btrim(coalesce(p_new_password_hash, '')) = '' THEN
    RAISE EXCEPTION 'INVALID_PASSWORD_HASH' USING ERRCODE='22023';
  END IF;
  v_result := consume_email_code(p_user, 'reset_password', p_code_hash);
  IF v_result = 'OK' THEN
    UPDATE app_users
      SET password_hash = p_new_password_hash, tokens_valid_after = clock_timestamp()
      WHERE id = p_user AND is_active;
    IF NOT FOUND THEN
      RETURN 'INVALID';
    END IF;
  END IF;
  RETURN v_result;
END $$;

-- Cambio de clave (propio o por un administrador): reemplaza el hash y cierra las sesiones anteriores.
CREATE FUNCTION set_app_user_password(p_user uuid, p_new_password_hash text) RETURNS boolean
LANGUAGE plpgsql SECURITY DEFINER SET search_path=logistica,pg_temp AS $$
BEGIN
  IF btrim(coalesce(p_new_password_hash, '')) = '' THEN
    RAISE EXCEPTION 'INVALID_PASSWORD_HASH' USING ERRCODE='22023';
  END IF;
  UPDATE app_users
    SET password_hash = p_new_password_hash, tokens_valid_after = clock_timestamp()
    WHERE id = p_user AND is_active;
  RETURN FOUND;
END $$;

REVOKE ALL ON FUNCTION
  logistica.register_trusted_app_user(text, text, text, text, text, text),
  logistica.issue_email_code(uuid, text, text, integer),
  logistica.consume_email_code(uuid, text, text),
  logistica.confirm_email(uuid, text),
  logistica.reset_password_with_code(uuid, text, text),
  logistica.set_app_user_password(uuid, text)
FROM PUBLIC;

-- consume_email_code es interna: solo la invocan las demás funciones.
GRANT EXECUTE ON FUNCTION
  logistica.register_trusted_app_user(text, text, text, text, text, text),
  logistica.issue_email_code(uuid, text, text, integer),
  logistica.confirm_email(uuid, text),
  logistica.reset_password_with_code(uuid, text, text),
  logistica.set_app_user_password(uuid, text)
TO logistica_app;
