SET search_path = logistica, pg_catalog;

-- ============================================================================
-- 010 · Tienda: categorias, productos, stock, pedidos con productos y franjas de entrega.
--
-- Compatibilidad: esta migracion solo AGREGA objetos. No modifica orders, route_stops ni ninguna funcion
-- existente; POST /orders y el flujo de rutas y entregas siguen igual. Un pedido de tienda es un pedido
-- normal (orders) mas filas en store_orders y order_items.
-- Todas las escrituras pasan por funciones SECURITY DEFINER; logistica_app solo tiene SELECT en las tablas.
-- Dinero: enteros en centavos, nunca decimales.
-- Codigos SQLSTATE propios: LG404 no existe, LG409 version desactualizada, LG412 stock insuficiente.
-- ============================================================================

-- Ultima barrera contra texto invisible o decorativo en nombres visibles. Es una lista negra independiente de la
-- configuracion regional del servidor; la lista blanca estricta de caracteres vive en la API.
-- Bloquea: controles, espacios y marcas invisibles, direccion de escritura, selectores de variacion (emoji),
-- simbolos y flechas (U+205F-U+2BFF), keycaps, emojis (U+1F000-U+1FFFF) y etiquetas.
CREATE FUNCTION is_clean_store_text(p_text text) RETURNS boolean
LANGUAGE sql IMMUTABLE PARALLEL SAFE AS $$
  SELECT p_text IS NOT NULL
     AND p_text !~ '[\x01-\x1F\x7F-\xA0 -‏ -  -⯿⃐-⃿　︀-️﻿\U0001F000-\U0001FFFF\U000E0000-\U000E007F]'
$$;

-- Igual, pero admite el salto de linea (U+000A) para descripciones de varias lineas.
CREATE FUNCTION is_clean_store_multiline(p_text text) RETURNS boolean
LANGUAGE sql IMMUTABLE PARALLEL SAFE AS $$
  SELECT p_text IS NOT NULL
     AND p_text !~ '[\x01-\x09\x0B-\x1F\x7F-\xA0 -‏ -  -⯿⃐-⃿　︀-️﻿\U0001F000-\U0001FFFF\U000E0000-\U000E007F]'
$$;

-- Texto de busqueda sin tildes ni mayusculas, para comparar "audifonos" con "Audifonos".
CREATE FUNCTION store_search_text(p_text text) RETURNS text
LANGUAGE sql IMMUTABLE PARALLEL SAFE AS $$
  SELECT translate(lower(coalesce(p_text, '')), 'áàäâéèëêíìïîóòöôúùüûñ', 'aaaaeeeeiiiioooouuuun')
$$;

-- Consulta de busqueda por prefijos. Solo conserva [a-z0-9], asi que ningun texto del usuario puede inyectar sintaxis.
CREATE FUNCTION store_search_query(p_text text) RETURNS tsquery
LANGUAGE sql IMMUTABLE PARALLEL SAFE AS $$
  SELECT to_tsquery('simple', string_agg(w.word || ':*', ' & '))
  FROM (
    SELECT word FROM regexp_split_to_table(regexp_replace(store_search_text(p_text), '[^a-z0-9]+', ' ', 'g'), ' ') AS word
    WHERE word <> '' LIMIT 8
  ) w
$$;

-- ---------------------------------------------------------------------------
-- Configuracion de la tienda (una sola fila)
-- ---------------------------------------------------------------------------
CREATE TABLE store_settings (
  id boolean PRIMARY KEY DEFAULT true CHECK (id),
  slot_capacity integer NOT NULL DEFAULT 10 CHECK (slot_capacity BETWEEN 1 AND 500),
  first_slot_hour integer NOT NULL DEFAULT 8 CHECK (first_slot_hour BETWEEN 0 AND 23),
  last_slot_hour integer NOT NULL DEFAULT 20 CHECK (last_slot_hour BETWEEN 0 AND 23),
  min_lead_minutes integer NOT NULL DEFAULT 60 CHECK (min_lead_minutes BETWEEN 0 AND 10080),
  updated_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  CHECK (first_slot_hour <= last_slot_hour)
);
INSERT INTO store_settings DEFAULT VALUES;

-- ---------------------------------------------------------------------------
-- Catalogo
-- ---------------------------------------------------------------------------
CREATE TABLE categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL CHECK (name = btrim(name) AND length(name) BETWEEN 2 AND 60 AND name ~ '[^[:space:]]' AND is_clean_store_text(name)),
  name_key text GENERATED ALWAYS AS (lower(name)) STORED,
  is_active boolean NOT NULL DEFAULT true,
  version bigint NOT NULL DEFAULT 1 CHECK (version > 0),
  created_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  updated_at timestamptz NOT NULL DEFAULT clock_timestamp()
);
CREATE UNIQUE INDEX categories_name_key_idx ON categories(name_key);

CREATE TABLE products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sku text NOT NULL CHECK (sku ~ '^[A-Z0-9][A-Z0-9-]{1,38}[A-Z0-9]$'),
  name text NOT NULL CHECK (name = btrim(name) AND length(name) BETWEEN 2 AND 120 AND name ~ '[^[:space:]]' AND is_clean_store_text(name)),
  brand text CHECK (brand IS NULL OR (brand = btrim(brand) AND length(brand) BETWEEN 2 AND 60 AND is_clean_store_text(brand))),
  description text CHECK (description IS NULL OR (length(description) BETWEEN 1 AND 2000 AND is_clean_store_multiline(description))),
  category_id uuid NOT NULL REFERENCES categories(id) ON DELETE RESTRICT,
  price_cents integer NOT NULL CHECK (price_cents BETWEEN 1 AND 100000000),
  compare_at_price_cents integer CHECK (compare_at_price_cents IS NULL OR compare_at_price_cents > price_cents),
  stock_quantity integer NOT NULL DEFAULT 0 CHECK (stock_quantity >= 0),
  image_key text CHECK (image_key IS NULL OR image_key ~ '^[0-9a-f]{32}\.(jpg|png)$'),
  is_active boolean NOT NULL DEFAULT true,
  version bigint NOT NULL DEFAULT 1 CHECK (version > 0),
  search_vector tsvector GENERATED ALWAYS AS (
    to_tsvector('simple', store_search_text(name || ' ' || coalesce(brand, '') || ' ' || coalesce(description, '')))
  ) STORED,
  created_by uuid REFERENCES app_users(id) ON DELETE RESTRICT,
  created_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  updated_at timestamptz NOT NULL DEFAULT clock_timestamp()
);
CREATE UNIQUE INDEX products_sku_idx ON products(sku);
CREATE INDEX products_catalog_idx ON products(category_id, price_cents, id) WHERE is_active;
CREATE INDEX products_search_idx ON products USING gin(search_vector);

ALTER TABLE categories ADD COLUMN search_vector tsvector
  GENERATED ALWAYS AS (to_tsvector('simple', store_search_text(name))) STORED;
CREATE INDEX categories_search_idx ON categories USING gin(search_vector);

-- Historial de cambios del catalogo (quien cambio que, y cuando). Inmutable.
CREATE TABLE product_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id uuid NOT NULL REFERENCES products(id) ON DELETE RESTRICT,
  actor_user_id uuid REFERENCES app_users(id) ON DELETE RESTRICT,
  action text NOT NULL CHECK (action IN ('created', 'updated', 'activated', 'deactivated', 'stock_adjusted')),
  changes jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT clock_timestamp()
);
CREATE INDEX product_events_product_idx ON product_events(product_id, created_at DESC);

-- Libro de movimientos de stock. El stock actual vive en products; cada cambio deja una fila aqui.
CREATE TABLE stock_movements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id uuid NOT NULL REFERENCES products(id) ON DELETE RESTRICT,
  order_id uuid REFERENCES orders(id) ON DELETE RESTRICT,
  delta integer NOT NULL CHECK (delta <> 0),
  reason text NOT NULL CHECK (reason IN ('initial', 'restock', 'correction', 'damage', 'sale')),
  balance_after integer NOT NULL CHECK (balance_after >= 0),
  actor_user_id uuid REFERENCES app_users(id) ON DELETE RESTRICT,
  created_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  CHECK ((reason = 'sale') = (order_id IS NOT NULL))
);
CREATE INDEX stock_movements_product_idx ON stock_movements(product_id, created_at DESC);
-- Una venta descuenta un producto UNA sola vez por pedido.
CREATE UNIQUE INDEX stock_movements_sale_once_idx ON stock_movements(order_id, product_id) WHERE reason = 'sale';

-- ---------------------------------------------------------------------------
-- Pedidos de tienda: encabezado y lineas con copia del nombre y precio al momento de comprar
-- ---------------------------------------------------------------------------
CREATE TABLE store_orders (
  order_id uuid PRIMARY KEY REFERENCES orders(id) ON DELETE RESTRICT,
  customer_user_id uuid NOT NULL REFERENCES app_users(id) ON DELETE RESTRICT,
  total_cents bigint NOT NULL CHECK (total_cents > 0),
  items_count integer NOT NULL CHECK (items_count BETWEEN 1 AND 20),
  payment_method text NOT NULL DEFAULT 'contra_entrega' CHECK (payment_method IN ('contra_entrega')),
  created_at timestamptz NOT NULL DEFAULT clock_timestamp()
);
CREATE INDEX store_orders_customer_idx ON store_orders(customer_user_id, created_at DESC, order_id);

CREATE TABLE order_items (
  order_id uuid NOT NULL REFERENCES orders(id) ON DELETE RESTRICT,
  product_id uuid NOT NULL REFERENCES products(id) ON DELETE RESTRICT,
  sku text NOT NULL,
  product_name text NOT NULL,
  unit_price_cents integer NOT NULL CHECK (unit_price_cents > 0),
  quantity integer NOT NULL CHECK (quantity BETWEEN 1 AND 10),
  line_total_cents bigint GENERATED ALWAYS AS (unit_price_cents::bigint * quantity) STORED,
  PRIMARY KEY (order_id, product_id)
);
CREATE INDEX order_items_product_idx ON order_items(product_id);

-- Los registros historicos no se editan ni se borran.
CREATE FUNCTION store_immutable() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN RAISE EXCEPTION 'STORE_RECORD_IMMUTABLE' USING ERRCODE = '23514'; END $$;
CREATE TRIGGER order_items_immutable BEFORE UPDATE OR DELETE ON order_items FOR EACH ROW EXECUTE FUNCTION store_immutable();
CREATE TRIGGER store_orders_immutable BEFORE UPDATE OR DELETE ON store_orders FOR EACH ROW EXECUTE FUNCTION store_immutable();
CREATE TRIGGER stock_movements_immutable BEFORE UPDATE OR DELETE ON stock_movements FOR EACH ROW EXECUTE FUNCTION store_immutable();
CREATE TRIGGER product_events_immutable BEFORE UPDATE OR DELETE ON product_events FOR EACH ROW EXECUTE FUNCTION store_immutable();

-- ---------------------------------------------------------------------------
-- Funciones de administracion (solo las puede llamar un usuario administrador activo)
-- ---------------------------------------------------------------------------
CREATE FUNCTION require_store_admin(p_actor uuid) RETURNS void
LANGUAGE plpgsql STABLE AS $$
BEGIN
  IF p_actor IS NULL OR NOT EXISTS (SELECT 1 FROM app_users WHERE id = p_actor AND role = 'personal' AND is_active) THEN
    RAISE EXCEPTION 'ACTOR_NOT_ALLOWED' USING ERRCODE = '42501';
  END IF;
END $$;

CREATE FUNCTION create_category(p_name text, p_actor uuid) RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path = logistica, pg_temp AS $$
DECLARE v_id uuid;
BEGIN
  PERFORM require_store_admin(p_actor);
  INSERT INTO categories(name) VALUES (btrim(p_name)) RETURNING id INTO v_id;
  RETURN v_id;
END $$;

CREATE FUNCTION update_category(p_id uuid, p_name text, p_is_active boolean, p_expected_version bigint, p_actor uuid) RETURNS bigint
LANGUAGE plpgsql SECURITY DEFINER SET search_path = logistica, pg_temp AS $$
DECLARE v_version bigint;
BEGIN
  PERFORM require_store_admin(p_actor);
  UPDATE categories
     SET name = coalesce(btrim(p_name), name),
         is_active = coalesce(p_is_active, is_active),
         version = version + 1,
         updated_at = clock_timestamp()
   WHERE id = p_id AND version = p_expected_version
   RETURNING version INTO v_version;
  IF NOT FOUND THEN
    IF EXISTS (SELECT 1 FROM categories WHERE id = p_id) THEN
      RAISE EXCEPTION 'VERSION_CONFLICT' USING ERRCODE = 'LG409';
    END IF;
    RAISE EXCEPTION 'CATEGORY_NOT_FOUND' USING ERRCODE = 'LG404';
  END IF;
  RETURN v_version;
END $$;

CREATE FUNCTION create_product(
  p_sku text, p_name text, p_brand text, p_description text, p_category uuid,
  p_price_cents integer, p_compare_at_cents integer, p_stock integer, p_image_key text,
  p_is_active boolean, p_actor uuid
) RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path = logistica, pg_temp AS $$
DECLARE v_id uuid;
BEGIN
  PERFORM require_store_admin(p_actor);
  IF p_stock IS NULL OR p_stock < 0 OR p_stock > 1000000 THEN
    RAISE EXCEPTION 'INVALID_STOCK' USING ERRCODE = '22023';
  END IF;
  INSERT INTO products(sku, name, brand, description, category_id, price_cents, compare_at_price_cents,
                       stock_quantity, image_key, is_active, created_by)
    VALUES (p_sku, btrim(p_name), NULLIF(btrim(coalesce(p_brand, '')), ''), NULLIF(btrim(coalesce(p_description, '')), ''),
            p_category, p_price_cents, p_compare_at_cents, p_stock, p_image_key, coalesce(p_is_active, true), p_actor)
    RETURNING id INTO v_id;
  IF p_stock > 0 THEN
    INSERT INTO stock_movements(product_id, delta, reason, balance_after, actor_user_id)
      VALUES (v_id, p_stock, 'initial', p_stock, p_actor);
  END IF;
  INSERT INTO product_events(product_id, actor_user_id, action, changes)
    VALUES (v_id, p_actor, 'created', jsonb_build_object('sku', p_sku, 'priceCents', p_price_cents, 'stock', p_stock));
  RETURN v_id;
END $$;

-- Cambios parciales con control de version: si otro administrador edito antes, falla con LG409.
-- El stock NO se edita aqui (ver adjust_stock) y no cambia la version: asi una venta no invalida el formulario abierto.
CREATE FUNCTION update_product(p_id uuid, p_expected_version bigint, p_patch jsonb, p_actor uuid) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path = logistica, pg_temp AS $$
DECLARE
  v_old products;
  v_new products;
  v_changes jsonb;
  v_action text;
BEGIN
  PERFORM require_store_admin(p_actor);
  IF jsonb_typeof(p_patch) IS DISTINCT FROM 'object' OR p_patch = '{}'::jsonb THEN
    RAISE EXCEPTION 'INVALID_PATCH' USING ERRCODE = '22023';
  END IF;
  IF EXISTS (SELECT 1 FROM jsonb_object_keys(p_patch) k
              WHERE k NOT IN ('name', 'brand', 'description', 'categoryId', 'priceCents', 'compareAtPriceCents', 'imageKey', 'isActive')) THEN
    RAISE EXCEPTION 'INVALID_PATCH' USING ERRCODE = '22023';
  END IF;
  SELECT * INTO v_old FROM products WHERE id = p_id FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'PRODUCT_NOT_FOUND' USING ERRCODE = 'LG404'; END IF;
  IF v_old.version <> p_expected_version THEN RAISE EXCEPTION 'VERSION_CONFLICT' USING ERRCODE = 'LG409'; END IF;

  UPDATE products SET
    name = CASE WHEN p_patch ? 'name' THEN btrim(p_patch ->> 'name') ELSE name END,
    brand = CASE WHEN p_patch ? 'brand' THEN NULLIF(btrim(coalesce(p_patch ->> 'brand', '')), '') ELSE brand END,
    description = CASE WHEN p_patch ? 'description' THEN NULLIF(btrim(coalesce(p_patch ->> 'description', '')), '') ELSE description END,
    category_id = CASE WHEN p_patch ? 'categoryId' THEN (p_patch ->> 'categoryId')::uuid ELSE category_id END,
    price_cents = CASE WHEN p_patch ? 'priceCents' THEN (p_patch ->> 'priceCents')::integer ELSE price_cents END,
    compare_at_price_cents = CASE WHEN p_patch ? 'compareAtPriceCents' THEN (p_patch ->> 'compareAtPriceCents')::integer ELSE compare_at_price_cents END,
    image_key = CASE WHEN p_patch ? 'imageKey' THEN p_patch ->> 'imageKey' ELSE image_key END,
    is_active = CASE WHEN p_patch ? 'isActive' THEN (p_patch ->> 'isActive')::boolean ELSE is_active END,
    version = version + 1,
    updated_at = clock_timestamp()
  WHERE id = p_id
  RETURNING * INTO v_new;

  SELECT coalesce(jsonb_object_agg(n.key, jsonb_build_object('from', to_jsonb(v_old) -> n.key, 'to', n.value)), '{}'::jsonb)
    INTO v_changes
    FROM jsonb_each(to_jsonb(v_new)) n
   WHERE n.key NOT IN ('version', 'updated_at', 'search_vector')
     AND (to_jsonb(v_old) -> n.key) IS DISTINCT FROM n.value;

  v_action := CASE
    WHEN v_changes ? 'is_active' AND (SELECT count(*) FROM jsonb_object_keys(v_changes)) = 1
      THEN CASE WHEN v_new.is_active THEN 'activated' ELSE 'deactivated' END
    ELSE 'updated'
  END;
  INSERT INTO product_events(product_id, actor_user_id, action, changes) VALUES (p_id, p_actor, v_action, v_changes);
  RETURN jsonb_build_object('id', p_id, 'version', v_new.version);
END $$;

-- Ajuste de stock por diferencia (+/-): es conmutativo, asi dos administradores a la vez nunca se pisan.
CREATE FUNCTION adjust_stock(p_product uuid, p_delta integer, p_reason text, p_actor uuid) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path = logistica, pg_temp AS $$
DECLARE v_stock integer;
BEGIN
  PERFORM require_store_admin(p_actor);
  IF p_delta IS NULL OR p_delta = 0 OR abs(p_delta) > 100000 THEN
    RAISE EXCEPTION 'INVALID_STOCK_DELTA' USING ERRCODE = '22023';
  END IF;
  IF p_reason IS NULL OR p_reason NOT IN ('restock', 'correction', 'damage') THEN
    RAISE EXCEPTION 'INVALID_STOCK_REASON' USING ERRCODE = '22023';
  END IF;
  UPDATE products
     SET stock_quantity = stock_quantity + p_delta, updated_at = clock_timestamp()
   WHERE id = p_product AND stock_quantity + p_delta >= 0
   RETURNING stock_quantity INTO v_stock;
  IF NOT FOUND THEN
    IF EXISTS (SELECT 1 FROM products WHERE id = p_product) THEN
      RAISE EXCEPTION 'INSUFFICIENT_STOCK' USING ERRCODE = 'LG412';
    END IF;
    RAISE EXCEPTION 'PRODUCT_NOT_FOUND' USING ERRCODE = 'LG404';
  END IF;
  INSERT INTO stock_movements(product_id, delta, reason, balance_after, actor_user_id)
    VALUES (p_product, p_delta, p_reason, v_stock, p_actor);
  INSERT INTO product_events(product_id, actor_user_id, action, changes)
    VALUES (p_product, p_actor, 'stock_adjusted', jsonb_build_object('delta', p_delta, 'reason', p_reason, 'balance', v_stock));
  RETURN jsonb_build_object('id', p_product, 'stock', v_stock);
END $$;

-- Devuelve true (y no void): el cliente de la API (Prisma) no puede leer columnas de tipo void.
CREATE FUNCTION set_store_settings(p_capacity integer, p_first_hour integer, p_last_hour integer, p_lead_minutes integer, p_actor uuid) RETURNS boolean
LANGUAGE plpgsql SECURITY DEFINER SET search_path = logistica, pg_temp AS $$
BEGIN
  PERFORM require_store_admin(p_actor);
  UPDATE store_settings
     SET slot_capacity = p_capacity, first_slot_hour = p_first_hour, last_slot_hour = p_last_hour,
         min_lead_minutes = p_lead_minutes, updated_at = clock_timestamp()
   WHERE id;
  RETURN true;
END $$;

-- ---------------------------------------------------------------------------
-- Franjas de entrega: una por hora, con cupo por zona, fecha y hora.
-- ---------------------------------------------------------------------------
CREATE FUNCTION delivery_slots(p_zone uuid, p_date date)
RETURNS TABLE (slot_time time, capacity integer, reserved integer, available boolean)
LANGUAGE sql SECURITY DEFINER SET search_path = logistica, pg_temp AS $$
  SELECT make_time(h, 0, 0),
         s.slot_capacity,
         coalesce(o.n, 0)::integer,
         ((p_date + make_time(h, 0, 0)) >= ((clock_timestamp() AT TIME ZONE 'America/Guayaquil') + make_interval(mins => s.min_lead_minutes))
           AND coalesce(o.n, 0) < s.slot_capacity)
    FROM store_settings s
   CROSS JOIN generate_series(s.first_slot_hour, s.last_slot_hour) AS h
    LEFT JOIN LATERAL (
      SELECT count(*) AS n FROM orders x
       WHERE x.zone_id = p_zone AND x.delivery_date = p_date AND extract(hour FROM x.delivery_time) = h
    ) o ON true
   ORDER BY h
$$;

-- ---------------------------------------------------------------------------
-- Pedido de tienda: UNA transaccion que valida, descuenta stock, reserva la franja y crea el pedido.
--
-- Concurrencia:
--   * Idempotencia con begin_request/finish_request: reintentar con la misma Idempotency-Key devuelve el mismo
--     resultado (replayed=true) y nunca crea otro pedido ni descuenta stock dos veces. La misma clave con otro
--     contenido falla (IDEMPOTENCY_PAYLOAD_CONFLICT, 23514).
--   * Franja: candado consultivo por zona-fecha-hora antes de contar el cupo; dos clientes no pueden tomar el ultimo.
--   * Productos: se bloquean en orden de id (sin interbloqueos) y se comprueban ya bloqueados; el descuento no puede
--     dejar el stock negativo ni siquiera si fallara una regla (CHECK stock_quantity >= 0).
-- Los rechazos de negocio (precio, stock, franja) devuelven status=conflict sin escribir nada y quedan como el
-- resultado de esa clave; para reintentar tras corregir se usa una clave nueva.
-- ---------------------------------------------------------------------------
CREATE FUNCTION place_store_order(
  p_customer uuid, p_zone uuid, p_address text, p_date date, p_time time,
  p_recipient text, p_phone text, p_notes text, p_items jsonb, p_key uuid
) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path = logistica, pg_temp AS $$
DECLARE
  op operation_requests;
  v_settings store_settings;
  v_items jsonb;
  v_ids uuid[];
  v_lines integer;
  v_conflicts jsonb := '[]'::jsonb;
  v_result jsonb;
  v_order uuid;
  v_total bigint;
  v_count integer;
  v_reserved integer;
  v_zone_active boolean;
  r record;
BEGIN
  IF p_customer IS NULL OR p_zone IS NULL OR p_date IS NULL OR p_time IS NULL OR p_address IS NULL THEN
    RAISE EXCEPTION 'INVALID_ORDER' USING ERRCODE = '22023';
  END IF;
  IF jsonb_typeof(p_items) IS DISTINCT FROM 'array' THEN RAISE EXCEPTION 'INVALID_ITEMS' USING ERRCODE = '22023'; END IF;
  v_lines := jsonb_array_length(p_items);
  IF v_lines NOT BETWEEN 1 AND 20 THEN RAISE EXCEPTION 'INVALID_ITEMS' USING ERRCODE = '22023'; END IF;

  -- Normaliza y ordena las lineas: el mismo contenido produce siempre el mismo hash de idempotencia.
  SELECT jsonb_agg(jsonb_build_object('productId', x.pid, 'quantity', x.qty, 'unitPriceCents', x.price) ORDER BY x.pid)
    INTO v_items
    FROM (SELECT (e ->> 'productId')::uuid AS pid, (e ->> 'quantity')::integer AS qty, (e ->> 'unitPriceCents')::integer AS price
            FROM jsonb_array_elements(p_items) e) x;
  IF EXISTS (SELECT 1 FROM jsonb_to_recordset(v_items) AS t("productId" uuid, quantity integer, "unitPriceCents" integer)
              WHERE t."productId" IS NULL OR t.quantity IS NULL OR t.quantity NOT BETWEEN 1 AND 10
                 OR t."unitPriceCents" IS NULL OR t."unitPriceCents" < 1)
     OR (SELECT count(DISTINCT t."productId") FROM jsonb_to_recordset(v_items) AS t("productId" uuid)) <> v_lines THEN
    RAISE EXCEPTION 'INVALID_ITEMS' USING ERRCODE = '22023';
  END IF;

  op := begin_request('store-order:' || p_customer::text, p_key, jsonb_build_object(
          'zone', p_zone, 'address', btrim(p_address), 'date', p_date, 'time', p_time,
          'recipient', p_recipient, 'phone', p_phone, 'notes', p_notes, 'items', v_items));
  IF op.status = 'completada' THEN
    RETURN op.response_body || jsonb_build_object('replayed', true);
  END IF;

  PERFORM 1 FROM app_users WHERE id = p_customer AND role = 'cliente' AND is_active;
  IF NOT FOUND THEN RAISE EXCEPTION 'CUSTOMER_USER_NOT_FOUND' USING ERRCODE = '23503'; END IF;
  SELECT is_active INTO v_zone_active FROM zones WHERE id = p_zone;
  IF NOT FOUND THEN RAISE EXCEPTION 'ZONE_NOT_FOUND' USING ERRCODE = '23503'; END IF;

  SELECT * INTO v_settings FROM store_settings;

  -- Franja valida: hora en punto, dentro del horario y con la anticipacion minima.
  IF NOT v_zone_active THEN
    v_conflicts := jsonb_build_array(jsonb_build_object('reason', 'zone_inactive'));
  ELSIF extract(minute FROM p_time) <> 0 OR extract(second FROM p_time) <> 0
     OR extract(hour FROM p_time) NOT BETWEEN v_settings.first_slot_hour AND v_settings.last_slot_hour THEN
    v_conflicts := jsonb_build_array(jsonb_build_object('reason', 'slot_invalid'));
  ELSIF (p_date + p_time) < ((clock_timestamp() AT TIME ZONE 'America/Guayaquil') + make_interval(mins => v_settings.min_lead_minutes)) THEN
    v_conflicts := jsonb_build_array(jsonb_build_object('reason', 'slot_unavailable'));
  END IF;

  IF jsonb_array_length(v_conflicts) = 0 THEN
    PERFORM pg_advisory_xact_lock(hashtextextended('slot:' || p_zone::text || ':' || p_date::text || ':' || extract(hour FROM p_time)::integer::text, 0));
    SELECT count(*) INTO v_reserved FROM orders
     WHERE zone_id = p_zone AND delivery_date = p_date AND extract(hour FROM delivery_time) = extract(hour FROM p_time);
    IF v_reserved >= v_settings.slot_capacity THEN
      v_conflicts := jsonb_build_array(jsonb_build_object('reason', 'slot_full', 'capacity', v_settings.slot_capacity));
    END IF;
  END IF;

  IF jsonb_array_length(v_conflicts) = 0 THEN
    -- Bloqueo en orden de id (evita interbloqueos entre compras con los mismos productos) y comprobacion ya bloqueada.
    SELECT array_agg(t."productId" ORDER BY t."productId") INTO v_ids
      FROM jsonb_to_recordset(v_items) AS t("productId" uuid);
    PERFORM 1 FROM products WHERE id = ANY (v_ids) ORDER BY id FOR UPDATE;

    FOR r IN
      SELECT t."productId" AS product_id, t.quantity, t."unitPriceCents" AS expected_price,
             p.id AS found_id, p.price_cents, p.stock_quantity,
             (p.is_active AND coalesce(c.is_active, false)) AS orderable
        FROM jsonb_to_recordset(v_items) AS t("productId" uuid, quantity integer, "unitPriceCents" integer)
        LEFT JOIN products p ON p.id = t."productId"
        LEFT JOIN categories c ON c.id = p.category_id
       ORDER BY t."productId"
    LOOP
      IF r.found_id IS NULL OR NOT r.orderable THEN
        v_conflicts := v_conflicts || jsonb_build_object('productId', r.product_id, 'reason', 'unavailable');
      ELSIF r.price_cents <> r.expected_price THEN
        v_conflicts := v_conflicts || jsonb_build_object('productId', r.product_id, 'reason', 'price_changed', 'currentPriceCents', r.price_cents);
      ELSIF r.stock_quantity < r.quantity THEN
        v_conflicts := v_conflicts || jsonb_build_object('productId', r.product_id, 'reason', 'insufficient_stock', 'available', r.stock_quantity);
      END IF;
    END LOOP;
  END IF;

  IF jsonb_array_length(v_conflicts) > 0 THEN
    v_result := jsonb_build_object('status', 'conflict', 'conflicts', v_conflicts, 'replayed', false);
    PERFORM finish_request(op.id, v_result);
    RETURN v_result;
  END IF;

  v_order := create_order_for_customer(p_zone, p_address, p_date, p_time, p_recipient, p_phone, p_notes, p_customer);

  INSERT INTO order_items(order_id, product_id, sku, product_name, unit_price_cents, quantity)
    SELECT v_order, p.id, p.sku, p.name, p.price_cents, t.quantity
      FROM jsonb_to_recordset(v_items) AS t("productId" uuid, quantity integer, "unitPriceCents" integer)
      JOIN products p ON p.id = t."productId";

  UPDATE products p
     SET stock_quantity = p.stock_quantity - t.quantity, updated_at = clock_timestamp()
    FROM jsonb_to_recordset(v_items) AS t("productId" uuid, quantity integer, "unitPriceCents" integer)
   WHERE p.id = t."productId";

  INSERT INTO stock_movements(product_id, order_id, delta, reason, balance_after, actor_user_id)
    SELECT p.id, v_order, -t.quantity, 'sale', p.stock_quantity, p_customer
      FROM jsonb_to_recordset(v_items) AS t("productId" uuid, quantity integer, "unitPriceCents" integer)
      JOIN products p ON p.id = t."productId";

  SELECT sum(line_total_cents), count(*) INTO v_total, v_count FROM order_items WHERE order_id = v_order;
  INSERT INTO store_orders(order_id, customer_user_id, total_cents, items_count) VALUES (v_order, p_customer, v_total, v_count);

  v_result := jsonb_build_object('status', 'ok', 'orderId', v_order, 'totalCents', v_total, 'itemsCount', v_count, 'replayed', false);
  PERFORM finish_request(op.id, v_result);
  RETURN v_result;
END $$;

-- ---------------------------------------------------------------------------
-- Permisos: la API (logistica_app) lee tablas y ejecuta funciones; nadie escribe directo.
-- ---------------------------------------------------------------------------
GRANT SELECT ON logistica.categories, logistica.products, logistica.product_events, logistica.stock_movements,
  logistica.store_orders, logistica.order_items, logistica.store_settings TO logistica_app, logistica_readonly;

REVOKE ALL ON FUNCTION
  logistica.create_category(text, uuid),
  logistica.update_category(uuid, text, boolean, bigint, uuid),
  logistica.create_product(text, text, text, text, uuid, integer, integer, integer, text, boolean, uuid),
  logistica.update_product(uuid, bigint, jsonb, uuid),
  logistica.adjust_stock(uuid, integer, text, uuid),
  logistica.set_store_settings(integer, integer, integer, integer, uuid),
  logistica.delivery_slots(uuid, date),
  logistica.place_store_order(uuid, uuid, text, date, time, text, text, text, jsonb, uuid),
  logistica.require_store_admin(uuid)
FROM PUBLIC;

GRANT EXECUTE ON FUNCTION
  logistica.create_category(text, uuid),
  logistica.update_category(uuid, text, boolean, bigint, uuid),
  logistica.create_product(text, text, text, text, uuid, integer, integer, integer, text, boolean, uuid),
  logistica.update_product(uuid, bigint, jsonb, uuid),
  logistica.adjust_stock(uuid, integer, text, uuid),
  logistica.set_store_settings(integer, integer, integer, integer, uuid),
  logistica.delivery_slots(uuid, date),
  logistica.place_store_order(uuid, uuid, text, date, time, text, text, text, jsonb, uuid)
TO logistica_app;
