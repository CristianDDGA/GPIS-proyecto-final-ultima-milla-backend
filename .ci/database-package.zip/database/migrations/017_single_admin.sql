SET search_path = logistica, pg_catalog;

-- ============================================================================
-- 017 · Un solo administrador.
--
-- Toda cuenta nueva pasa por register_app_user (directo o desde register_trusted_app_user). A partir de ahora esa
-- funcion rechaza crear un segundo usuario con rol 'personal' (administrador): SQLSTATE 23505 con el mensaje
-- ADMIN_ALREADY_EXISTS. Un bloqueo consultivo evita que dos solicitudes simultaneas creen dos administradores.
--
-- Compatibilidad: firma y permisos iguales a 005; solo se agrega la regla. La cuenta de administrador actual no se
-- toca. Las pruebas SQL que insertan filas directo en app_users no pasan por aqui (el rol de la API no puede hacerlo).
-- ============================================================================

CREATE OR REPLACE FUNCTION register_app_user(
  p_auth_subject text,
  p_email text,
  p_password_hash text,
  p_role text,
  p_display_name text DEFAULT NULL
) RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path=logistica,pg_temp AS $$
DECLARE
  v_email text;
  v_subject text;
  v_result uuid;
BEGIN
  v_email := lower(btrim(coalesce(p_email, '')));
  v_subject := btrim(coalesce(p_auth_subject, ''));
  IF v_email = '' OR v_email !~ '^[^[:space:]@]+@[^[:space:]@]+\.[^[:space:]@]+$' THEN
    RAISE EXCEPTION 'INVALID_EMAIL' USING ERRCODE='22023';
  END IF;
  IF btrim(coalesce(p_password_hash, '')) = '' THEN
    RAISE EXCEPTION 'INVALID_PASSWORD_HASH' USING ERRCODE='22023';
  END IF;
  IF p_role NOT IN ('personal', 'repartidor', 'cliente') THEN
    RAISE EXCEPTION 'INVALID_ROLE' USING ERRCODE='22023';
  END IF;
  IF v_subject = '' THEN
    v_subject := v_email;
  END IF;

  IF p_role = 'personal' THEN
    PERFORM pg_advisory_xact_lock(hashtextextended('single-admin', 0));
    IF EXISTS (SELECT 1 FROM app_users WHERE role = 'personal') THEN
      RAISE EXCEPTION 'ADMIN_ALREADY_EXISTS' USING ERRCODE='23505';
    END IF;
  END IF;

  INSERT INTO app_users(auth_subject, email, password_hash, role, display_name)
    VALUES (v_subject, v_email, p_password_hash, p_role, NULLIF(btrim(coalesce(p_display_name, '')), ''))
    RETURNING id INTO v_result;
  RETURN v_result;
END $$;
