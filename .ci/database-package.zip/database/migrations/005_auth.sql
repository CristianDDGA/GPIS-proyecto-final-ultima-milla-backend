SET search_path = logistica, pg_catalog;

ALTER TABLE app_users DROP CONSTRAINT IF EXISTS app_users_role_check;
ALTER TABLE app_users ADD CONSTRAINT app_users_role_check CHECK (role IN ('personal', 'repartidor', 'cliente'));

ALTER TABLE app_users
  ADD COLUMN IF NOT EXISTS email text,
  ADD COLUMN IF NOT EXISTS password_hash text,
  ADD COLUMN IF NOT EXISTS display_name text;

CREATE UNIQUE INDEX IF NOT EXISTS app_users_email_unique_idx
  ON app_users (lower(email))
  WHERE email IS NOT NULL;

ALTER TABLE orders
  ADD COLUMN IF NOT EXISTS customer_user_id uuid REFERENCES app_users(id) ON DELETE RESTRICT;

CREATE INDEX IF NOT EXISTS orders_customer_date_idx
  ON orders (customer_user_id, delivery_date, id)
  WHERE customer_user_id IS NOT NULL;

CREATE FUNCTION register_app_user(
  p_auth_subject text,
  p_email text,
  p_password_hash text,
  p_role text,
  p_display_name text DEFAULT NULL
) RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path=logistica,pg_temp AS $$
DECLARE
  v_email text;
  v_subject text;
  v_result uuid;
BEGIN
  v_email := lower(btrim(coalesce(p_email, '')));
  v_subject := btrim(coalesce(p_auth_subject, ''));
  IF v_email = '' OR v_email !~ '^[^[:space:]@]+@[^[:space:]@]+\.[^[:space:]@]+$' THEN
    RAISE EXCEPTION 'INVALID_EMAIL' USING ERRCODE='22023';
  END IF;
  IF btrim(coalesce(p_password_hash, '')) = '' THEN
    RAISE EXCEPTION 'INVALID_PASSWORD_HASH' USING ERRCODE='22023';
  END IF;
  IF p_role NOT IN ('personal', 'repartidor', 'cliente') THEN
    RAISE EXCEPTION 'INVALID_ROLE' USING ERRCODE='22023';
  END IF;
  IF v_subject = '' THEN
    v_subject := v_email;
  END IF;

  INSERT INTO app_users(auth_subject, email, password_hash, role, display_name)
    VALUES (v_subject, v_email, p_password_hash, p_role, NULLIF(btrim(coalesce(p_display_name, '')), ''))
    RETURNING id INTO v_result;
  RETURN v_result;
END $$;

CREATE FUNCTION create_order_for_customer(
  p_zone uuid,
  p_address text,
  p_date date,
  p_time time,
  p_recipient text DEFAULT NULL,
  p_phone text DEFAULT NULL,
  p_notes text DEFAULT NULL,
  p_customer_user uuid DEFAULT NULL
) RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path=logistica,pg_temp AS $$
DECLARE
  v_subject text := '';
  v_result uuid;
BEGIN
  IF p_time IS NOT NULL AND extract(second FROM p_time) <> 0 THEN
    RAISE EXCEPTION 'INVALID_DELIVERY_TIME' USING ERRCODE='22007';
  END IF;
  IF p_date < (clock_timestamp() AT TIME ZONE 'America/Guayaquil')::date THEN
    RAISE EXCEPTION 'DELIVERY_DATE_IN_PAST' USING ERRCODE='22007';
  END IF;
  IF p_customer_user IS NOT NULL THEN
    SELECT auth_subject INTO v_subject FROM app_users WHERE id = p_customer_user AND is_active;
    IF NOT FOUND THEN
      RAISE EXCEPTION 'CUSTOMER_USER_NOT_FOUND' USING ERRCODE='23503';
    END IF;
  END IF;

  PERFORM set_config('logistica.source', 'web', true);
  PERFORM set_config('logistica.actor_subject', coalesce(v_subject, ''), true);
  INSERT INTO orders(zone_id, delivery_address, delivery_date, delivery_time, recipient_name, recipient_phone, notes, customer_user_id)
    VALUES (p_zone, btrim(p_address), p_date, p_time, p_recipient, p_phone, p_notes, p_customer_user)
    RETURNING id INTO v_result;
  RETURN v_result;
END $$;

GRANT EXECUTE ON FUNCTION
  logistica.register_app_user(text, text, text, text, text),
  logistica.create_order_for_customer(uuid, text, date, time, text, text, text, uuid)
TO logistica_app;
