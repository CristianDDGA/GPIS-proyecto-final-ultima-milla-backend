SET search_path = logistica, pg_catalog;

-- Activar o desactivar una cuenta de usuario (gestión para el administrador).
-- Devuelve texto en lugar de lanzar excepciones: OK | UNCHANGED | NOT_FOUND | LAST_ADMIN | HAS_ACTIVE_ROUTE.
--  * No se puede desactivar al último administrador activo.
--  * No se puede desactivar a un repartidor con una ruta asignada o en curso (quedaría sin poder operarla).
--  * Al desactivar se cierran todas sus sesiones (tokens_valid_after).
CREATE FUNCTION set_app_user_active(p_user uuid, p_active boolean) RETURNS text
LANGUAGE plpgsql SECURITY DEFINER SET search_path=logistica,pg_temp AS $$
DECLARE
  u app_users;
BEGIN
  IF p_active IS NULL THEN
    RAISE EXCEPTION 'INVALID_ACTIVE_FLAG' USING ERRCODE='22023';
  END IF;
  SELECT * INTO u FROM app_users WHERE id = p_user FOR UPDATE;
  IF NOT FOUND THEN
    RETURN 'NOT_FOUND';
  END IF;
  IF u.is_active = p_active THEN
    RETURN 'UNCHANGED';
  END IF;
  IF NOT p_active THEN
    IF u.role = 'personal' THEN
      -- Bloquea a los demás administradores activos para que dos desactivaciones simultáneas no dejen el sistema sin ninguno.
      PERFORM 1 FROM app_users WHERE role = 'personal' AND is_active AND id <> p_user FOR UPDATE;
      IF NOT FOUND THEN
        RETURN 'LAST_ADMIN';
      END IF;
    END IF;
    IF EXISTS (
      SELECT 1 FROM couriers c JOIN routes r ON r.courier_id = c.id
      WHERE c.user_id = p_user AND r.status IN ('asignada', 'en_curso')
    ) THEN
      RETURN 'HAS_ACTIVE_ROUTE';
    END IF;
  END IF;
  UPDATE app_users
    SET is_active = p_active,
        tokens_valid_after = CASE WHEN p_active THEN tokens_valid_after ELSE clock_timestamp() END
    WHERE id = p_user;
  RETURN 'OK';
END $$;

REVOKE ALL ON FUNCTION logistica.set_app_user_active(uuid, boolean) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION logistica.set_app_user_active(uuid, boolean) TO logistica_app;
