SET search_path = logistica, pg_catalog;

-- Solicitudes para pasar de cliente a conductor (repartidor).
-- Flujo: borrador (datos y archivos) -> pendiente (enviada) -> aprobada | rechazada | cancelada.
-- Solo el administrador resuelve. Al aprobar, en una sola transacción el usuario pasa de 'cliente' a
-- 'repartidor', se crea su ficha en couriers y se cierran sus sesiones (el token nuevo trae el rol nuevo).
-- Las imágenes viven en disco (fuera de la base); aquí solo queda su metadato y la clave de almacenamiento.

CREATE TABLE IF NOT EXISTS courier_applications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES app_users(id) ON DELETE RESTRICT,
  status text NOT NULL DEFAULT 'borrador'
    CHECK (status IN ('borrador', 'pendiente', 'aprobada', 'rechazada', 'cancelada')),
  full_name text NOT NULL CHECK (full_name ~ '[^[:space:]]'),
  national_id text NOT NULL CHECK (national_id ~ '^[0-9]{10}$'),
  phone text NOT NULL CHECK (phone ~ '^\+?[0-9]{7,15}$'),
  birth_date date NOT NULL,
  vehicle_type text NOT NULL CHECK (vehicle_type IN ('moto', 'auto', 'camioneta')),
  license_number text NOT NULL CHECK (license_number ~ '^[A-Za-z0-9-]{4,20}$'),
  license_category text NOT NULL CHECK (license_category IN ('A', 'A1', 'B', 'C', 'C1', 'D', 'D1', 'E', 'E1', 'F', 'G')),
  license_expires_on date NOT NULL,
  submitted_at timestamptz,
  reviewed_at timestamptz,
  reviewed_by uuid REFERENCES app_users(id) ON DELETE RESTRICT,
  rejection_reason text CHECK (rejection_reason IS NULL OR rejection_reason ~ '[^[:space:]]'),
  approved_capacity integer CHECK (approved_capacity IS NULL OR approved_capacity > 0),
  created_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  updated_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  CHECK ((status IN ('aprobada', 'rechazada')) = (reviewed_at IS NOT NULL AND reviewed_by IS NOT NULL)),
  CHECK ((status = 'rechazada') = (rejection_reason IS NOT NULL)),
  CHECK ((status = 'aprobada') = (approved_capacity IS NOT NULL))
);

-- Un usuario solo tiene una solicitud abierta (borrador o pendiente) y una cédula no puede estar en
-- dos solicitudes vigentes (pendiente o aprobada).
CREATE UNIQUE INDEX IF NOT EXISTS courier_applications_one_open_per_user_idx
  ON courier_applications (user_id) WHERE status IN ('borrador', 'pendiente');
CREATE UNIQUE INDEX IF NOT EXISTS courier_applications_national_id_live_idx
  ON courier_applications (national_id) WHERE status IN ('pendiente', 'aprobada');
CREATE INDEX IF NOT EXISTS courier_applications_status_idx
  ON courier_applications (status, submitted_at DESC, id);

CREATE TABLE IF NOT EXISTS courier_application_files (
  application_id uuid NOT NULL REFERENCES courier_applications(id) ON DELETE CASCADE,
  kind text NOT NULL CHECK (kind IN ('license', 'photo')),
  content_type text NOT NULL CHECK (content_type IN ('image/jpeg', 'image/png')),
  size_bytes integer NOT NULL CHECK (size_bytes > 0 AND size_bytes <= 5242880),
  sha256 text NOT NULL CHECK (sha256 ~ '^[0-9a-f]{64}$'),
  storage_key text NOT NULL CHECK (storage_key ~ '^[0-9a-f]{32}\.(jpg|png)$'),
  uploaded_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  PRIMARY KEY (application_id, kind)
);

DROP TRIGGER IF EXISTS courier_applications_touch ON courier_applications;
CREATE FUNCTION courier_applications_touch() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF NEW.id <> OLD.id OR NEW.user_id <> OLD.user_id OR NEW.created_at <> OLD.created_at THEN
    RAISE EXCEPTION 'Identidad, dueño y creación inmutables' USING ERRCODE='23514';
  END IF;
  IF OLD.status IN ('aprobada', 'rechazada', 'cancelada') THEN
    RAISE EXCEPTION 'Una solicitud resuelta no se modifica' USING ERRCODE='23514';
  END IF;
  NEW.updated_at := clock_timestamp();
  RETURN NEW;
END $$;
CREATE TRIGGER courier_applications_touch BEFORE UPDATE ON courier_applications
  FOR EACH ROW EXECUTE FUNCTION courier_applications_touch();

-- Hoy en Ecuador (la fecha de caducidad de la licencia y la mayoría de edad se miden con ella).
CREATE FUNCTION application_today() RETURNS date LANGUAGE sql STABLE AS $$
  SELECT (clock_timestamp() AT TIME ZONE 'America/Guayaquil')::date
$$;

-- Crea o actualiza el borrador del usuario. Devuelve:
-- OK | NOT_CLIENT | EMAIL_NOT_VERIFIED | ALREADY_PENDING | DUPLICATE_NATIONAL_ID
CREATE FUNCTION save_courier_application_draft(
  p_user uuid,
  p_full_name text,
  p_national_id text,
  p_phone text,
  p_birth_date date,
  p_vehicle_type text,
  p_license_number text,
  p_license_category text,
  p_license_expires_on date
) RETURNS text
LANGUAGE plpgsql SECURITY DEFINER SET search_path=logistica,pg_temp AS $$
DECLARE
  u app_users;
  open_app courier_applications;
BEGIN
  SELECT * INTO u FROM app_users WHERE id = p_user AND is_active FOR UPDATE;
  IF NOT FOUND OR u.role <> 'cliente' THEN RETURN 'NOT_CLIENT'; END IF;
  IF u.email_verified_at IS NULL THEN RETURN 'EMAIL_NOT_VERIFIED'; END IF;
  IF EXISTS (
    SELECT 1 FROM courier_applications
    WHERE national_id = p_national_id AND status IN ('pendiente', 'aprobada') AND user_id <> p_user
  ) THEN RETURN 'DUPLICATE_NATIONAL_ID'; END IF;
  SELECT * INTO open_app FROM courier_applications
    WHERE user_id = p_user AND status IN ('borrador', 'pendiente') FOR UPDATE;
  IF FOUND AND open_app.status = 'pendiente' THEN RETURN 'ALREADY_PENDING'; END IF;
  IF FOUND THEN
    UPDATE courier_applications SET
      full_name = p_full_name, national_id = p_national_id, phone = p_phone, birth_date = p_birth_date,
      vehicle_type = p_vehicle_type, license_number = p_license_number, license_category = p_license_category,
      license_expires_on = p_license_expires_on
      WHERE id = open_app.id;
  ELSE
    INSERT INTO courier_applications(
      user_id, full_name, national_id, phone, birth_date, vehicle_type, license_number, license_category, license_expires_on
    ) VALUES (
      p_user, p_full_name, p_national_id, p_phone, p_birth_date, p_vehicle_type, p_license_number, p_license_category, p_license_expires_on
    );
  END IF;
  RETURN 'OK';
END $$;

-- Registra (o reemplaza) un archivo del borrador. Devuelve OK | NO_DRAFT.
CREATE FUNCTION attach_courier_application_file(
  p_user uuid,
  p_kind text,
  p_content_type text,
  p_size integer,
  p_sha256 text,
  p_storage_key text
) RETURNS text
LANGUAGE plpgsql SECURITY DEFINER SET search_path=logistica,pg_temp AS $$
DECLARE
  app_id uuid;
BEGIN
  SELECT id INTO app_id FROM courier_applications WHERE user_id = p_user AND status = 'borrador' FOR UPDATE;
  IF NOT FOUND THEN RETURN 'NO_DRAFT'; END IF;
  INSERT INTO courier_application_files(application_id, kind, content_type, size_bytes, sha256, storage_key)
    VALUES (app_id, p_kind, p_content_type, p_size, p_sha256, p_storage_key)
    ON CONFLICT (application_id, kind) DO UPDATE SET
      content_type = EXCLUDED.content_type, size_bytes = EXCLUDED.size_bytes, sha256 = EXCLUDED.sha256,
      storage_key = EXCLUDED.storage_key, uploaded_at = clock_timestamp();
  RETURN 'OK';
END $$;

-- Envía el borrador a revisión. Devuelve OK | NO_DRAFT | MISSING_FILES | LICENSE_EXPIRED | UNDERAGE | DUPLICATE_NATIONAL_ID.
CREATE FUNCTION submit_courier_application(p_user uuid) RETURNS text
LANGUAGE plpgsql SECURITY DEFINER SET search_path=logistica,pg_temp AS $$
DECLARE
  a courier_applications;
  u app_users;
BEGIN
  SELECT * INTO u FROM app_users WHERE id = p_user AND is_active FOR UPDATE;
  IF NOT FOUND OR u.role <> 'cliente' THEN RETURN 'NO_DRAFT'; END IF;
  SELECT * INTO a FROM courier_applications WHERE user_id = p_user AND status = 'borrador' FOR UPDATE;
  IF NOT FOUND THEN RETURN 'NO_DRAFT'; END IF;
  IF (SELECT count(*) FROM courier_application_files WHERE application_id = a.id) < 2 THEN RETURN 'MISSING_FILES'; END IF;
  IF a.license_expires_on <= application_today() THEN RETURN 'LICENSE_EXPIRED'; END IF;
  IF a.birth_date > (application_today() - interval '18 years')::date THEN RETURN 'UNDERAGE'; END IF;
  IF EXISTS (
    SELECT 1 FROM courier_applications
    WHERE national_id = a.national_id AND status IN ('pendiente', 'aprobada') AND id <> a.id
  ) THEN RETURN 'DUPLICATE_NATIONAL_ID'; END IF;
  UPDATE courier_applications SET status = 'pendiente', submitted_at = clock_timestamp() WHERE id = a.id;
  RETURN 'OK';
END $$;

-- El solicitante cancela su solicitud abierta (borrador o pendiente). Devuelve OK | NOT_FOUND.
CREATE FUNCTION cancel_courier_application(p_user uuid) RETURNS text
LANGUAGE plpgsql SECURITY DEFINER SET search_path=logistica,pg_temp AS $$
DECLARE
  n integer;
BEGIN
  UPDATE courier_applications SET status = 'cancelada'
    WHERE user_id = p_user AND status IN ('borrador', 'pendiente');
  GET DIAGNOSTICS n = ROW_COUNT;
  IF n = 0 THEN RETURN 'NOT_FOUND'; END IF;
  RETURN 'OK';
END $$;

-- El administrador aprueba o rechaza una solicitud pendiente. Devuelve:
-- OK | NOT_FOUND | NOT_PENDING | NOT_CLIENT | FORBIDDEN
-- Aprobar: rol 'repartidor', ficha en couriers y sesiones anteriores cerradas, todo en una transacción.
-- Rechazar: el motivo es obligatorio.
CREATE FUNCTION review_courier_application(
  p_id uuid,
  p_reviewer uuid,
  p_approve boolean,
  p_reason text,
  p_capacity integer
) RETURNS text
LANGUAGE plpgsql SECURITY DEFINER SET search_path=logistica,pg_temp AS $$
DECLARE
  a courier_applications;
  u app_users;
BEGIN
  IF p_approve IS NULL THEN RAISE EXCEPTION 'INVALID_DECISION' USING ERRCODE='22023'; END IF;
  IF NOT EXISTS (SELECT 1 FROM app_users WHERE id = p_reviewer AND is_active AND role = 'personal') THEN
    RETURN 'FORBIDDEN';
  END IF;
  SELECT * INTO a FROM courier_applications WHERE id = p_id FOR UPDATE;
  IF NOT FOUND THEN RETURN 'NOT_FOUND'; END IF;
  IF a.status <> 'pendiente' THEN RETURN 'NOT_PENDING'; END IF;
  IF p_approve THEN
    IF p_capacity IS NULL OR p_capacity < 1 THEN RAISE EXCEPTION 'INVALID_CAPACITY' USING ERRCODE='22023'; END IF;
    SELECT * INTO u FROM app_users WHERE id = a.user_id AND is_active FOR UPDATE;
    IF NOT FOUND OR u.role <> 'cliente' THEN RETURN 'NOT_CLIENT'; END IF;
    UPDATE app_users SET role = 'repartidor', tokens_valid_after = clock_timestamp() WHERE id = a.user_id;
    INSERT INTO couriers(user_id, display_name, max_orders_per_trip) VALUES (a.user_id, a.full_name, p_capacity);
    UPDATE courier_applications SET
      status = 'aprobada', reviewed_at = clock_timestamp(), reviewed_by = p_reviewer, approved_capacity = p_capacity
      WHERE id = a.id;
  ELSE
    IF p_reason IS NULL OR btrim(p_reason) = '' THEN RAISE EXCEPTION 'REASON_REQUIRED' USING ERRCODE='22023'; END IF;
    UPDATE courier_applications SET
      status = 'rechazada', reviewed_at = clock_timestamp(), reviewed_by = p_reviewer, rejection_reason = btrim(p_reason)
      WHERE id = a.id;
  END IF;
  RETURN 'OK';
END $$;

GRANT SELECT ON logistica.courier_applications, logistica.courier_application_files TO logistica_app;

REVOKE ALL ON FUNCTION
  logistica.application_today(),
  logistica.save_courier_application_draft(uuid, text, text, text, date, text, text, text, date),
  logistica.attach_courier_application_file(uuid, text, text, integer, text, text),
  logistica.submit_courier_application(uuid),
  logistica.cancel_courier_application(uuid),
  logistica.review_courier_application(uuid, uuid, boolean, text, integer)
FROM PUBLIC;

GRANT EXECUTE ON FUNCTION
  logistica.application_today(),
  logistica.save_courier_application_draft(uuid, text, text, text, date, text, text, text, date),
  logistica.attach_courier_application_file(uuid, text, text, integer, text, text),
  logistica.submit_courier_application(uuid),
  logistica.cancel_courier_application(uuid),
  logistica.review_courier_application(uuid, uuid, boolean, text, integer)
TO logistica_app;
