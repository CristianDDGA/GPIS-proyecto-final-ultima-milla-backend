SET search_path = logistica, pg_catalog;

-- ============================================================================
-- 018 · Nombre de zona unico.
--
-- La API ya rechazaba nombres repetidos, pero con una comprobacion previa (leer y luego insertar): dos solicitudes
-- simultaneas, o variantes de mayusculas y espacios, podian crear dos zonas iguales. El indice lo garantiza en la base.
-- Se compara sin importar mayusculas ni espacios en los extremos, igual que findByName de la API.
--
-- Compatibilidad: no cambia funciones ni firmas. Falla (y no aplica) si ya hubiera nombres repetidos; en produccion
-- se comprobo antes que no los hay.
-- ============================================================================

CREATE UNIQUE INDEX zones_name_unique_idx ON zones (lower(btrim(name)));
