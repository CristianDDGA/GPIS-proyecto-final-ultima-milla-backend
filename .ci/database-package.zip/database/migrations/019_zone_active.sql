SET search_path = logistica, pg_catalog;

-- ============================================================================
-- 019 · Activar y desactivar zonas.
--
-- La columna zones.is_active existe desde la 001 y ya se respeta en todo el sistema: una zona inactiva no entra en la
-- planificacion de rutas, no recibe pedidos ni direcciones y no la devuelve zone_for_point. Faltaba poder cambiarla.
--
-- Regla: no se desactiva una zona con trabajo abierto, es decir:
--   * rutas planificadas, asignadas o en curso, o
--   * pedidos que no esten entregados ni cancelados (incluye los de entrega fallida, que el cliente puede reprogramar).
-- La fila de la zona se bloquea con FOR UPDATE; los pedidos y rutas nuevos toman FOR SHARE sobre ella (002/011), asi que
-- no puede colarse un pedido entre la comprobacion y el cambio.
--
-- Reactivar no tiene condiciones. Devuelve false si la zona no existe; cambiar al mismo estado es idempotente.
-- No cambia funciones ni firmas existentes.
-- ============================================================================

CREATE FUNCTION set_zone_active(p_zone uuid, p_active boolean) RETURNS boolean
LANGUAGE plpgsql SECURITY DEFINER SET search_path = logistica, pg_temp AS $$
DECLARE v_zone zones;
BEGIN
  IF p_active IS NULL THEN RAISE EXCEPTION 'ZONE_ACTIVE_REQUIRED' USING ERRCODE = '22023'; END IF;
  SELECT * INTO v_zone FROM zones WHERE id = p_zone FOR UPDATE;
  IF NOT FOUND THEN RETURN false; END IF;
  IF v_zone.is_active = p_active THEN RETURN true; END IF;
  IF NOT p_active AND (
    EXISTS (SELECT 1 FROM routes WHERE zone_id = p_zone AND status IN ('planificada', 'asignada', 'en_curso'))
    OR EXISTS (SELECT 1 FROM orders WHERE zone_id = p_zone AND status NOT IN ('entregado', 'cancelado'))
  ) THEN
    RAISE EXCEPTION 'ZONE_HAS_OPEN_WORK' USING ERRCODE = '23514';
  END IF;
  UPDATE zones SET is_active = p_active WHERE id = p_zone;
  RETURN true;
END $$;

REVOKE ALL ON FUNCTION logistica.set_zone_active(uuid, boolean) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION logistica.set_zone_active(uuid, boolean) TO logistica_app;
