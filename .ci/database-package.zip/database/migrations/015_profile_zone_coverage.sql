SET search_path = logistica, pg_catalog;

-- ============================================================================
-- 015 · Perfil del cliente y cobertura de zonas
--
-- 1. Perfil: el usuario puede tener un telefono (opcional) y editar su nombre y su telefono desde su perfil.
--    Mismo formato que el telefono del destinatario (011): de 7 a 15 digitos, con + opcional.
-- 2. Cobertura de zonas: cada zona puede tener un centro (latitud y longitud dentro de Ecuador) y un radio en km.
--    zone_for_point devuelve la zona activa que cubre un punto (la del centro mas cercano). Sin PostGIS: distancia
--    de gran circulo (haversine) en SQL. Una zona sin cobertura sigue funcionando como antes (se elige a mano).
--
-- Compatibilidad: solo columnas nulas y funciones nuevas; ninguna firma existente cambia.
-- ============================================================================

-- ---------------------------------------------------------------------------- 1. Perfil
ALTER TABLE app_users ADD COLUMN phone text;
ALTER TABLE app_users ADD CONSTRAINT app_users_phone_check CHECK (phone IS NULL OR phone ~ '^\+?[0-9]{7,15}$');

-- Cambia el nombre y el telefono de una cuenta activa. Recibe los dos valores finales (NULL borra).
-- false si la cuenta no existe o esta inactiva.
CREATE FUNCTION update_profile(p_user uuid, p_display_name text, p_phone text) RETURNS boolean
LANGUAGE plpgsql SECURITY DEFINER SET search_path = logistica, pg_temp AS $$
BEGIN
  UPDATE app_users
     SET display_name = NULLIF(btrim(coalesce(p_display_name, '')), ''),
         phone = NULLIF(btrim(coalesce(p_phone, '')), '')
   WHERE id = p_user AND is_active;
  RETURN FOUND;
END $$;

-- ---------------------------------------------------------------------------- 2. Cobertura de zonas
ALTER TABLE zones
  ADD COLUMN center_latitude double precision,
  ADD COLUMN center_longitude double precision,
  ADD COLUMN coverage_radius_km numeric(5, 2),
  ADD CONSTRAINT zones_coverage_check CHECK (
    (center_latitude IS NULL AND center_longitude IS NULL AND coverage_radius_km IS NULL)
    OR (center_latitude IS NOT NULL AND center_longitude IS NOT NULL AND coverage_radius_km BETWEEN 0.1 AND 50
        AND valid_coordinates(center_latitude, center_longitude))
  );

-- Distancia en km entre dos puntos (haversine, radio medio de la Tierra 6371 km).
CREATE FUNCTION distance_km(p_lat1 double precision, p_lng1 double precision, p_lat2 double precision, p_lng2 double precision)
RETURNS double precision LANGUAGE sql IMMUTABLE AS $$
  SELECT 2 * 6371 * asin(sqrt(
    power(sin(radians(p_lat2 - p_lat1) / 2), 2)
    + cos(radians(p_lat1)) * cos(radians(p_lat2)) * power(sin(radians(p_lng2 - p_lng1) / 2), 2)
  ))
$$;

-- Fija o quita (los tres en NULL) la cobertura de una zona. false si la zona no existe.
CREATE FUNCTION set_zone_coverage(p_zone uuid, p_lat double precision, p_lng double precision, p_radius_km numeric)
RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path = logistica, pg_temp AS $$
BEGIN
  UPDATE zones SET center_latitude = p_lat, center_longitude = p_lng, coverage_radius_km = p_radius_km WHERE id = p_zone;
  RETURN FOUND;
END $$;

-- Zona activa que cubre el punto: la de centro mas cercano entre las que lo incluyen en su radio. NULL si ninguna.
CREATE FUNCTION zone_for_point(p_lat double precision, p_lng double precision) RETURNS uuid
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = logistica, pg_temp AS $$
  SELECT z.id
    FROM zones z
   WHERE z.is_active AND z.coverage_radius_km IS NOT NULL
     AND valid_coordinates(p_lat, p_lng) AND p_lat IS NOT NULL
     AND distance_km(z.center_latitude, z.center_longitude, p_lat, p_lng) <= z.coverage_radius_km
   ORDER BY distance_km(z.center_latitude, z.center_longitude, p_lat, p_lng), z.id
   LIMIT 1
$$;

REVOKE ALL ON FUNCTION
  logistica.update_profile(uuid, text, text),
  logistica.set_zone_coverage(uuid, double precision, double precision, numeric),
  logistica.zone_for_point(double precision, double precision),
  logistica.distance_km(double precision, double precision, double precision, double precision)
FROM PUBLIC;

GRANT EXECUTE ON FUNCTION
  logistica.update_profile(uuid, text, text),
  logistica.set_zone_coverage(uuid, double precision, double precision, numeric),
  logistica.zone_for_point(double precision, double precision),
  logistica.distance_km(double precision, double precision, double precision, double precision)
TO logistica_app;
