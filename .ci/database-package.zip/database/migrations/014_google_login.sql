SET search_path = logistica, pg_catalog;

-- ============================================================================
-- 014 · Inicio de sesion con Google
--
-- Una cuenta puede vincularse a una identidad de Google (google_sub). Quien entra con Google prueba que controla su
-- correo, asi que su cuenta nace verificada con email_verified_via = 'google' y sin contrasena (password_hash NULL).
-- Reglas que aplica el backend: Google solo crea o vincula cuentas de CLIENTE; un administrador o un repartidor nunca se
-- crea ni se vincula con Google. Una cuenta de cliente ya vinculada que despues pasa a repartidor (aprobacion de su
-- solicitud) conserva su vinculacion y puede seguir entrando.
-- ============================================================================

ALTER TABLE app_users ADD COLUMN google_sub text;
ALTER TABLE app_users ADD CONSTRAINT app_users_google_sub_check
  CHECK (google_sub IS NULL OR (length(google_sub) BETWEEN 1 AND 255 AND google_sub ~ '^[0-9A-Za-z_.:-]+$'));
CREATE UNIQUE INDEX app_users_google_sub_idx ON app_users (google_sub) WHERE google_sub IS NOT NULL;

ALTER TABLE app_users DROP CONSTRAINT IF EXISTS app_users_email_verified_via_check;
ALTER TABLE app_users ADD CONSTRAINT app_users_email_verified_via_check CHECK (
  (email_verified_at IS NULL AND email_verified_via IS NULL)
  OR (email_verified_at IS NOT NULL AND email_verified_via IN ('code', 'admin', 'legacy', 'demo', 'google'))
);

-- Alta de un cliente que entra por primera vez con Google. Devuelve el id; 23505 si el correo o la identidad ya existen.
CREATE FUNCTION register_google_user(p_sub text, p_email text, p_display_name text) RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path = logistica, pg_temp AS $$
DECLARE v_email text; v_id uuid;
BEGIN
  v_email := lower(btrim(coalesce(p_email, '')));
  IF v_email = '' OR v_email !~ '^[^[:space:]@]+@[^[:space:]@]+\.[^[:space:]@]+$' THEN
    RAISE EXCEPTION 'INVALID_EMAIL' USING ERRCODE = '22023';
  END IF;
  IF p_sub IS NULL OR btrim(p_sub) = '' THEN RAISE EXCEPTION 'INVALID_GOOGLE_SUB' USING ERRCODE = '22023'; END IF;
  INSERT INTO app_users(auth_subject, email, password_hash, role, display_name, email_verified_at, email_verified_via, google_sub)
    VALUES (v_email, v_email, NULL, 'cliente', NULLIF(btrim(coalesce(p_display_name, '')), ''), clock_timestamp(), 'google', p_sub)
    RETURNING id INTO v_id;
  RETURN v_id;
END $$;

-- Vincula Google a una cuenta de cliente activa cuyo correo se confirmo por codigo (el usuario ya demostro que es suyo).
-- 'OK', 'NOT_ELIGIBLE' (no es cliente, esta inactiva o su correo no se confirmo por codigo) o 'SUB_IN_USE'.
CREATE FUNCTION link_google_account(p_user uuid, p_sub text) RETURNS text
LANGUAGE plpgsql SECURITY DEFINER SET search_path = logistica, pg_temp AS $$
DECLARE u app_users;
BEGIN
  IF p_sub IS NULL OR btrim(p_sub) = '' THEN RAISE EXCEPTION 'INVALID_GOOGLE_SUB' USING ERRCODE = '22023'; END IF;
  SELECT * INTO u FROM app_users WHERE id = p_user FOR UPDATE;
  IF u.id IS NULL OR NOT u.is_active OR u.role <> 'cliente' OR u.email_verified_via IS DISTINCT FROM 'code' THEN
    RETURN 'NOT_ELIGIBLE';
  END IF;
  IF u.google_sub IS NOT NULL THEN RETURN CASE WHEN u.google_sub = p_sub THEN 'OK' ELSE 'NOT_ELIGIBLE' END; END IF;
  IF EXISTS (SELECT 1 FROM app_users WHERE google_sub = p_sub) THEN RETURN 'SUB_IN_USE'; END IF;
  UPDATE app_users SET google_sub = p_sub WHERE id = p_user;
  RETURN 'OK';
END $$;

REVOKE ALL ON FUNCTION
  logistica.register_google_user(text, text, text),
  logistica.link_google_account(uuid, text)
FROM PUBLIC;

GRANT EXECUTE ON FUNCTION
  logistica.register_google_user(text, text, text),
  logistica.link_google_account(uuid, text)
TO logistica_app;
