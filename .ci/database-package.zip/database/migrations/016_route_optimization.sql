SET search_path = logistica, pg_catalog;

-- ============================================================================
-- 016 · Optimizacion del armado de rutas (algoritmo zona_hora_nn_v2).
--
-- Antes (zona_hora_v1): las paradas de cada ruta quedaban en el orden en que se agregaban (hora de entrega) y un
-- pedido tardio iba a la primera ruta con cupo y al primer conductor libre por id. No se usaba la distancia.
--
-- Ahora, sin cambiar firmas ni contratos:
--   1. Agrupacion por zona y fecha, y llenado de rutas por hora de entrega con tope de capacidad (CVRP con ventanas
--      horarias, igual que antes).
--   2. Orden de paradas por vecino mas cercano con penalizacion horaria: parte del pedido con la hora mas temprana
--      y avanza siempre a la parada de menor costo = distancia_km + 5 * |diferencia de horas|. Sin coordenadas
--      (pedido sin pin) la distancia cuenta 0 y manda la hora, como antes.
--   3. Pedido tardio: entre las rutas de su zona y fecha con cupo elige la mas cercana (distancia a su parada mas
--      cercana); sin coordenadas conserva el criterio anterior (la mas antigua). Luego reordena la ruta.
--   4. Conductor para una ruta nueva: puntaje ponderado = distancia desde su ultima entrega del dia
--      + 3 * entregas ya hechas ese dia (reparto de carga); gana el menor puntaje, empate por id.
-- La concurrencia no cambia: mismos bloqueos (advisory por fecha, FOR UPDATE SKIP LOCKED) e idempotencia.
-- ============================================================================

-- Ordena las paradas vigentes de una ruta por vecino mas cercano con penalizacion horaria (5 km por hora).
CREATE FUNCTION sequence_route_stops(p_route uuid) RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = logistica, pg_temp AS $$
DECLARE
  n integer; i integer; ordered uuid[] := '{}'; nxt record;
  cur_lat double precision; cur_lng double precision; cur_time time;
BEGIN
  SELECT count(*) INTO n FROM route_stops WHERE route_id = p_route AND released_at IS NULL;
  IF n < 2 THEN RETURN; END IF;
  FOR i IN 1..n LOOP
    SELECT s.order_id AS order_id, o.delivery_time AS delivery_time,
           so.delivery_latitude AS lat, so.delivery_longitude AS lng
      INTO nxt
      FROM route_stops s
      JOIN orders o ON o.id = s.order_id
      LEFT JOIN store_orders so ON so.order_id = s.order_id
     WHERE s.route_id = p_route AND s.released_at IS NULL AND s.order_id <> ALL (ordered)
     ORDER BY CASE WHEN i = 1 THEN 0 ELSE
                coalesce(distance_km(cur_lat, cur_lng, so.delivery_latitude, so.delivery_longitude), 0)
                + 5 * abs(extract(epoch FROM (o.delivery_time - cur_time)) / 3600.0)
              END,
              o.delivery_time, o.id
     LIMIT 1;
    ordered := ordered || nxt.order_id;
    cur_lat := nxt.lat; cur_lng := nxt.lng; cur_time := nxt.delivery_time;
  END LOOP;
  PERFORM reorder_route(p_route, ordered);
END $$;

-- Puntaje de un conductor para atender un pedido en un punto y fecha (menor es mejor).
CREATE FUNCTION courier_dispatch_score(p_courier uuid, p_date date, p_lat double precision, p_lng double precision)
RETURNS double precision LANGUAGE sql STABLE SECURITY DEFINER SET search_path = logistica, pg_temp AS $$
  SELECT coalesce(distance_km(last_stop.lat, last_stop.lng, p_lat, p_lng), 0)
         + 3.0 * (
           SELECT count(*) FROM routes r JOIN route_stops s ON s.route_id = r.id
            WHERE r.courier_id = p_courier AND r.service_date = p_date AND r.status = 'completada'
         )
    FROM (SELECT 1) base
    LEFT JOIN LATERAL (
      SELECT so.delivery_latitude AS lat, so.delivery_longitude AS lng
        FROM routes r
        JOIN route_stops s ON s.route_id = r.id
        JOIN orders o ON o.id = s.order_id AND o.status = 'entregado'
        JOIN store_orders so ON so.order_id = o.id
       WHERE r.courier_id = p_courier AND r.service_date = p_date
       ORDER BY o.delivered_at DESC, o.id
       LIMIT 1
    ) last_stop ON true
$$;

CREATE OR REPLACE FUNCTION generate_routes(p_date date, p_capacity integer, p_key uuid) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path = logistica, pg_temp AS $$
DECLARE op operation_requests; z record; item record; current_route uuid; used integer; result jsonb = '[]'; rid uuid;
BEGIN
  IF p_date IS NULL OR p_capacity IS NULL OR p_capacity < 1 THEN RAISE EXCEPTION 'INVALID_PLAN_PARAMETERS' USING ERRCODE = '22023'; END IF;
  op = begin_request('plan:' || p_date::text, p_key, jsonb_build_object('date', p_date, 'capacity', p_capacity));
  IF op.status = 'completada' THEN RETURN op.response_body; END IF;
  PERFORM pg_advisory_xact_lock(hashtextextended('plan:' || p_date::text, 0));
  FOR z IN SELECT id FROM zones WHERE is_active ORDER BY id LOOP
    current_route = NULL; used = 0;
    FOR item IN SELECT id FROM orders WHERE zone_id = z.id AND delivery_date = p_date AND status = 'pendiente' ORDER BY delivery_time, id FOR UPDATE SKIP LOCKED LOOP
      IF current_route IS NULL OR used = p_capacity THEN
        current_route = create_route(z.id, p_date, p_capacity, 'zona_hora_nn_v2'); used = 0;
        result = result || jsonb_build_array(current_route);
      END IF;
      PERFORM add_order_to_route(current_route, item.id); used = used + 1;
    END LOOP;
  END LOOP;
  FOR rid IN SELECT x::uuid FROM jsonb_array_elements_text(result) x LOOP
    PERFORM sequence_route_stops(rid);
  END LOOP;
  result = jsonb_build_object('routeIds', result, 'date', p_date);
  PERFORM finish_request(op.id, result); RETURN result;
END $$;

CREATE OR REPLACE FUNCTION place_late_order(p_order uuid, p_capacity integer, p_key uuid) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path = logistica, pg_temp AS $$
DECLARE op operation_requests; o orders; r_id uuid; c couriers; result jsonb; o_lat double precision; o_lng double precision;
BEGIN
  IF p_capacity IS NULL OR p_capacity < 1 THEN RAISE EXCEPTION 'INVALID_CAPACITY' USING ERRCODE = '22023'; END IF;
  op = begin_request('late:' || p_order::text, p_key, jsonb_build_object('orderId', p_order, 'capacity', p_capacity));
  IF op.status = 'completada' THEN RETURN op.response_body; END IF;
  SELECT * INTO o FROM orders WHERE id = p_order;
  IF o.id IS NULL THEN RAISE EXCEPTION 'ORDER_NOT_FOUND' USING ERRCODE = 'P0002'; END IF;
  PERFORM pg_advisory_xact_lock(hashtextextended('plan:' || o.delivery_date::text, 0));
  IF o.status <> 'pendiente' THEN RAISE EXCEPTION 'ORDER_ALREADY_ASSIGNED' USING ERRCODE = '23514'; END IF;
  SELECT delivery_latitude, delivery_longitude INTO o_lat, o_lng FROM store_orders WHERE order_id = p_order;
  SELECT r.id INTO r_id FROM routes r WHERE r.zone_id = o.zone_id AND r.service_date = o.delivery_date AND r.status IN ('planificada', 'asignada')
    AND (SELECT count(*) FROM route_stops WHERE route_id = r.id AND released_at IS NULL) < r.capacity_limit
    ORDER BY (SELECT min(distance_km(so.delivery_latitude, so.delivery_longitude, o_lat, o_lng))
                FROM route_stops s JOIN store_orders so ON so.order_id = s.order_id
               WHERE s.route_id = r.id AND s.released_at IS NULL) NULLS LAST,
             r.created_at, r.id LIMIT 1 FOR UPDATE OF r SKIP LOCKED;
  IF r_id IS NULL THEN
    SELECT * INTO c FROM couriers x WHERE x.is_enabled AND x.is_available AND NOT EXISTS (
      SELECT 1 FROM routes WHERE courier_id = x.id AND status IN ('asignada', 'en_curso')
    ) ORDER BY courier_dispatch_score(x.id, o.delivery_date, o_lat, o_lng), x.id LIMIT 1 FOR UPDATE OF x SKIP LOCKED;
    IF c.id IS NULL THEN
      result = jsonb_build_object('status', 'pendiente', 'reason', 'NO_AVAILABLE_COURIER', 'orderId', p_order);
      PERFORM finish_request(op.id, result); RETURN result;
    END IF;
    r_id = create_route(o.zone_id, o.delivery_date, least(p_capacity, c.max_orders_per_trip), 'zona_hora_nn_v2');
    PERFORM add_order_to_route(r_id, p_order); PERFORM assign_route(r_id, c.id);
  ELSE
    PERFORM add_order_to_route(r_id, p_order);
    PERFORM sequence_route_stops(r_id);
  END IF;
  result = jsonb_build_object('status', 'asignado_a_ruta', 'routeId', r_id, 'orderId', p_order);
  PERFORM finish_request(op.id, result); RETURN result;
END $$;

REVOKE ALL ON FUNCTION
  logistica.sequence_route_stops(uuid),
  logistica.courier_dispatch_score(uuid, date, double precision, double precision)
FROM PUBLIC;
