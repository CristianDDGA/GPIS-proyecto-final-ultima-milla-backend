SET search_path = logistica, pg_catalog;

CREATE TABLE IF NOT EXISTS revoked_tokens (
  jti text PRIMARY KEY CHECK (jti ~ '[^[:space:]]'),
  expires_at timestamptz NOT NULL,
  revoked_at timestamptz NOT NULL DEFAULT clock_timestamp()
);

CREATE INDEX IF NOT EXISTS revoked_tokens_expires_idx
  ON revoked_tokens (expires_at);

CREATE FUNCTION revoke_token(p_jti text, p_expires_at timestamptz) RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path=logistica,pg_temp AS $$
BEGIN
  IF btrim(coalesce(p_jti, '')) = '' THEN
    RAISE EXCEPTION 'INVALID_TOKEN_JTI' USING ERRCODE='22023';
  END IF;
  INSERT INTO revoked_tokens(jti, expires_at)
    VALUES (p_jti, p_expires_at)
    ON CONFLICT (jti) DO NOTHING;
END $$;

GRANT SELECT ON logistica.revoked_tokens TO logistica_app;
GRANT EXECUTE ON FUNCTION logistica.revoke_token(text, timestamptz) TO logistica_app;
