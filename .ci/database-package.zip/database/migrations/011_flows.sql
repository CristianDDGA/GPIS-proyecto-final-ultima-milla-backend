SET search_path = logistica, pg_catalog;

-- ============================================================================
-- 011 · Flujos completos por rol: cancelar, entrega fallida y reprogramacion, cobro contra entrega,
--       rendicion de caja, cola de correos y libreta de direcciones.
--
-- Compatibilidad: solo se agregan dos estados (cancelado, entrega_fallida) y objetos nuevos. Ninguno de los flujos
-- existentes llega a esos estados por si solo: solo las funciones nuevas los producen. Las funciones existentes que se
-- reemplazan conservan su firma y comportamiento; solo aceptan los estados nuevos (y change_order_status exige el
-- cobro para pedidos de tienda).
-- Codigos SQLSTATE propios nuevos: LG413 limite de direcciones, LG422 monto cobrado distinto del total.
-- ============================================================================

-- ---------------------------------------------------------------------------
-- 1. Estados nuevos
-- ---------------------------------------------------------------------------
DO $$
DECLARE c record;
BEGIN
  FOR c IN SELECT conname FROM pg_constraint
            WHERE conrelid = 'logistica.orders'::regclass AND contype = 'c' AND pg_get_constraintdef(oid) LIKE '%asignado_a_ruta%' LOOP
    EXECUTE format('ALTER TABLE logistica.orders DROP CONSTRAINT %I', c.conname);
  END LOOP;
END $$;
ALTER TABLE orders ADD CONSTRAINT orders_status_check
  CHECK (status IN ('pendiente', 'asignado_a_ruta', 'recogido', 'en_camino', 'entregado', 'entrega_fallida', 'cancelado'));

-- El libro de stock acepta la devolucion por cancelacion, una sola vez por pedido y producto.
DO $$
DECLARE c record;
BEGIN
  FOR c IN SELECT conname FROM pg_constraint WHERE conrelid = 'logistica.stock_movements'::regclass AND contype = 'c' LOOP
    EXECUTE format('ALTER TABLE logistica.stock_movements DROP CONSTRAINT %I', c.conname);
  END LOOP;
END $$;
ALTER TABLE stock_movements
  ADD CONSTRAINT stock_movements_delta_check CHECK (delta <> 0),
  ADD CONSTRAINT stock_movements_balance_check CHECK (balance_after >= 0),
  ADD CONSTRAINT stock_movements_reason_check CHECK (reason IN ('initial', 'restock', 'correction', 'damage', 'sale', 'cancel')),
  ADD CONSTRAINT stock_movements_order_check CHECK ((reason IN ('sale', 'cancel')) = (order_id IS NOT NULL));
CREATE UNIQUE INDEX stock_movements_cancel_once_idx ON stock_movements(order_id, product_id) WHERE reason = 'cancel';

-- ---------------------------------------------------------------------------
-- 2. Funciones existentes que ahora conocen los estados nuevos (mismo comportamiento para lo anterior)
-- ---------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION guard_order() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF TG_OP='DELETE' THEN RAISE EXCEPTION 'Conservar historial del pedido' USING ERRCODE='23514'; END IF;
  IF TG_OP='INSERT' OR NEW.zone_id IS DISTINCT FROM OLD.zone_id THEN
    PERFORM id FROM zones WHERE id=NEW.zone_id AND is_active FOR SHARE;
    IF NOT FOUND THEN RAISE EXCEPTION 'ZONE_NOT_FOUND_OR_INACTIVE' USING ERRCODE='23503'; END IF;
  END IF;
  IF TG_OP='INSERT' THEN
    IF NEW.status <> 'pendiente' OR NEW.version <> 1 THEN
      RAISE EXCEPTION 'El pedido debe iniciar pendiente/version 1' USING ERRCODE='23514';
    END IF;
  ELSE
    IF NEW.id<>OLD.id OR NEW.created_at<>OLD.created_at THEN
      RAISE EXCEPTION 'Identidad/creacion inmutables' USING ERRCODE='23514';
    END IF;
    IF NEW.status <> OLD.status AND NOT (
      (OLD.status='pendiente' AND NEW.status IN ('asignado_a_ruta','cancelado')) OR
      (OLD.status='asignado_a_ruta' AND NEW.status IN ('pendiente','recogido','cancelado')) OR
      (OLD.status='recogido' AND NEW.status='en_camino') OR
      (OLD.status='en_camino' AND NEW.status IN ('entregado','entrega_fallida')) OR
      (OLD.status='entrega_fallida' AND NEW.status IN ('pendiente','cancelado'))) THEN
      RAISE EXCEPTION 'INVALID_ORDER_TRANSITION: % -> %', OLD.status,NEW.status USING ERRCODE='23514';
    END IF;
    IF OLD.status IN ('entregado','cancelado') THEN RAISE EXCEPTION 'Pedido cerrado inmutable' USING ERRCODE='23514'; END IF;
    NEW.version=OLD.version+1;
    NEW.updated_at=clock_timestamp();
    IF NEW.status='entregado' THEN NEW.delivered_at=clock_timestamp(); END IF;
  END IF;
  RETURN NEW;
END $$;
CREATE OR REPLACE FUNCTION guard_stop() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE r routes; o orders;
BEGIN
  IF TG_OP='DELETE' THEN RAISE EXCEPTION 'Liberar parada, no eliminar historial' USING ERRCODE='23514'; END IF;
  SELECT * INTO r FROM routes WHERE id=NEW.route_id FOR UPDATE;
  SELECT * INTO o FROM orders WHERE id=NEW.order_id FOR UPDATE;
  IF r.id IS NULL OR o.id IS NULL THEN RAISE EXCEPTION 'Ruta/pedido inexistente' USING ERRCODE='23503'; END IF;
  IF TG_OP='INSERT' THEN
    IF NEW.released_at IS NOT NULL OR r.status NOT IN ('planificada','asignada') OR o.status NOT IN ('pendiente','asignado_a_ruta') THEN
      RAISE EXCEPTION 'Parada no elegible: solo antes de salida/recogida' USING ERRCODE='23514';
    END IF;
    IF r.zone_id<>o.zone_id OR r.service_date<>o.delivery_date THEN RAISE EXCEPTION 'DATE_ZONE_MISMATCH' USING ERRCODE='23514'; END IF;
    IF (SELECT count(*) FROM route_stops WHERE route_id=r.id AND released_at IS NULL)>=r.capacity_limit THEN
      RAISE EXCEPTION 'ROUTE_CAPACITY_EXCEEDED' USING ERRCODE='23514';
    END IF;
  ELSE
    IF NEW.id<>OLD.id OR NEW.route_id<>OLD.route_id OR NEW.order_id<>OLD.order_id OR NEW.added_at<>OLD.added_at OR OLD.released_at IS NOT NULL THEN
      RAISE EXCEPTION 'Parada historica/identidad inmutable' USING ERRCODE='23514';
    END IF;
    IF NEW.position<>OLD.position AND (o.status<>'asignado_a_ruta' OR r.status NOT IN ('planificada','asignada')) THEN
      RAISE EXCEPTION 'Reordenamiento solo antes de recogida/salida' USING ERRCODE='23514';
    END IF;
    IF NEW.released_at IS NOT NULL AND (o.status IN ('recogido','en_camino') OR (o.status IN ('entregado','entrega_fallida') AND r.status<>'completada')) THEN
      RAISE EXCEPTION 'No liberar cupo recogido/en camino/entregado antes del cierre' USING ERRCODE='23514';
    END IF;
  END IF;
  RETURN NEW;
END $$;
CREATE OR REPLACE FUNCTION assert_order(p_id uuid) RETURNS void LANGUAGE plpgsql AS $$
DECLARE o orders; n integer; r routes;
BEGIN
  SELECT * INTO o FROM orders WHERE id=p_id;
  SELECT count(*) INTO n FROM route_stops WHERE order_id=p_id AND released_at IS NULL;
  IF (o.status IN ('pendiente','cancelado') AND n<>0) OR (o.status IN ('asignado_a_ruta','recogido','en_camino') AND n<>1) THEN
    RAISE EXCEPTION 'Estado de pedido inconsistente con su asignacion' USING ERRCODE='23514';
  END IF;
  IF n=1 THEN
    SELECT x.* INTO r FROM routes x JOIN route_stops s ON s.route_id=x.id WHERE s.order_id=p_id AND s.released_at IS NULL;
    PERFORM assert_route(r.id);
    IF (o.status='recogido' AND r.status NOT IN ('asignada','en_curso')) OR
       (o.status IN ('en_camino','entregado','entrega_fallida') AND r.status<>'en_curso') THEN
      RAISE EXCEPTION 'Estado de ruta incompatible con entrega' USING ERRCODE='23514';
    END IF;
  END IF;
END $$;
CREATE OR REPLACE FUNCTION complete_route(p_route uuid) RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path=logistica,pg_temp AS $$
BEGIN
  PERFORM id FROM routes WHERE id=p_route AND status='en_curso' FOR UPDATE;
  IF NOT FOUND OR NOT EXISTS (SELECT 1 FROM route_stops WHERE route_id=p_route AND released_at IS NULL) OR EXISTS (
    SELECT 1 FROM route_stops s JOIN orders o ON o.id=s.order_id WHERE s.route_id=p_route AND s.released_at IS NULL AND o.status NOT IN ('entregado','entrega_fallida')
  ) THEN RAISE EXCEPTION 'ROUTE_NOT_COMPLETABLE' USING ERRCODE='23514'; END IF;
  UPDATE routes SET status='completada',completed_at=clock_timestamp() WHERE id=p_route;
  UPDATE route_stops SET released_at=clock_timestamp(),release_reason='ruta_completada' WHERE route_id=p_route AND released_at IS NULL;
END $$;
CREATE OR REPLACE FUNCTION change_order_status(p_order uuid,p_new_status text,p_expected_version bigint,p_actor uuid) RETURNS bigint
LANGUAGE plpgsql SECURITY DEFINER SET search_path=logistica,pg_temp AS $$
DECLARE r routes; o orders; actor app_users;
BEGIN
  SELECT * INTO actor FROM app_users WHERE id=p_actor AND is_active;
  IF actor.id IS NULL THEN RAISE EXCEPTION 'UNAUTHORIZED_ACTOR' USING ERRCODE='42501'; END IF;
  SELECT x.* INTO r FROM routes x JOIN route_stops s ON s.route_id=x.id WHERE s.order_id=p_order AND s.released_at IS NULL FOR UPDATE OF x;
  SELECT * INTO o FROM orders WHERE id=p_order FOR UPDATE;
  IF r.id IS NULL OR o.id IS NULL OR o.version IS DISTINCT FROM p_expected_version THEN RAISE EXCEPTION 'STALE_ORDER_VERSION_OR_ASSIGNMENT' USING ERRCODE='40001'; END IF;
  IF actor.role='repartidor' AND NOT EXISTS (SELECT 1 FROM couriers WHERE id=r.courier_id AND user_id=p_actor AND is_enabled) THEN
    RAISE EXCEPTION 'ORDER_NOT_OWNED_BY_COURIER' USING ERRCODE='42501';
  END IF;
  IF p_new_status NOT IN ('recogido','en_camino','entregado') OR p_new_status=o.status THEN RAISE EXCEPTION 'INVALID_ORDER_TRANSITION' USING ERRCODE='23514'; END IF;
  -- Un pedido de tienda se paga contra entrega: no puede quedar entregado sin el cobro registrado (deliver_store_order).
  IF p_new_status='entregado' AND EXISTS (SELECT 1 FROM store_orders WHERE order_id=p_order)
     AND NOT EXISTS (SELECT 1 FROM order_collections WHERE order_id=p_order) THEN
    RAISE EXCEPTION 'COLLECTION_REQUIRED' USING ERRCODE='23514';
  END IF;
  PERFORM set_config('logistica.actor_subject',actor.auth_subject,true);
  PERFORM set_config('logistica.source',CASE WHEN actor.role='repartidor' THEN 'mobile' ELSE 'web' END,true);
  IF p_new_status='en_camino' AND o.status='recogido' AND r.status='asignada' THEN
    UPDATE routes SET status='en_curso',started_at=clock_timestamp() WHERE id=r.id;
  END IF;
  UPDATE orders SET status=p_new_status WHERE id=p_order RETURNING version INTO p_expected_version;
  RETURN p_expected_version;
END $$;
CREATE OR REPLACE FUNCTION place_store_order(
  p_customer uuid, p_zone uuid, p_address text, p_date date, p_time time,
  p_recipient text, p_phone text, p_notes text, p_items jsonb, p_key uuid
) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path = logistica, pg_temp AS $$
DECLARE
  op operation_requests;
  v_settings store_settings;
  v_items jsonb;
  v_ids uuid[];
  v_lines integer;
  v_conflicts jsonb := '[]'::jsonb;
  v_result jsonb;
  v_order uuid;
  v_total bigint;
  v_count integer;
  v_reserved integer;
  v_zone_active boolean;
  r record;
BEGIN
  IF p_customer IS NULL OR p_zone IS NULL OR p_date IS NULL OR p_time IS NULL OR p_address IS NULL THEN
    RAISE EXCEPTION 'INVALID_ORDER' USING ERRCODE = '22023';
  END IF;
  IF jsonb_typeof(p_items) IS DISTINCT FROM 'array' THEN RAISE EXCEPTION 'INVALID_ITEMS' USING ERRCODE = '22023'; END IF;
  v_lines := jsonb_array_length(p_items);
  IF v_lines NOT BETWEEN 1 AND 20 THEN RAISE EXCEPTION 'INVALID_ITEMS' USING ERRCODE = '22023'; END IF;

  -- Normaliza y ordena las lineas: el mismo contenido produce siempre el mismo hash de idempotencia.
  SELECT jsonb_agg(jsonb_build_object('productId', x.pid, 'quantity', x.qty, 'unitPriceCents', x.price) ORDER BY x.pid)
    INTO v_items
    FROM (SELECT (e ->> 'productId')::uuid AS pid, (e ->> 'quantity')::integer AS qty, (e ->> 'unitPriceCents')::integer AS price
            FROM jsonb_array_elements(p_items) e) x;
  IF EXISTS (SELECT 1 FROM jsonb_to_recordset(v_items) AS t("productId" uuid, quantity integer, "unitPriceCents" integer)
              WHERE t."productId" IS NULL OR t.quantity IS NULL OR t.quantity NOT BETWEEN 1 AND 10
                 OR t."unitPriceCents" IS NULL OR t."unitPriceCents" < 1)
     OR (SELECT count(DISTINCT t."productId") FROM jsonb_to_recordset(v_items) AS t("productId" uuid)) <> v_lines THEN
    RAISE EXCEPTION 'INVALID_ITEMS' USING ERRCODE = '22023';
  END IF;

  op := begin_request('store-order:' || p_customer::text, p_key, jsonb_build_object(
          'zone', p_zone, 'address', btrim(p_address), 'date', p_date, 'time', p_time,
          'recipient', p_recipient, 'phone', p_phone, 'notes', p_notes, 'items', v_items));
  IF op.status = 'completada' THEN
    RETURN op.response_body || jsonb_build_object('replayed', true);
  END IF;

  PERFORM 1 FROM app_users WHERE id = p_customer AND role = 'cliente' AND is_active;
  IF NOT FOUND THEN RAISE EXCEPTION 'CUSTOMER_USER_NOT_FOUND' USING ERRCODE = '23503'; END IF;
  SELECT is_active INTO v_zone_active FROM zones WHERE id = p_zone;
  IF NOT FOUND THEN RAISE EXCEPTION 'ZONE_NOT_FOUND' USING ERRCODE = '23503'; END IF;

  SELECT * INTO v_settings FROM store_settings;

  -- Franja valida: hora en punto, dentro del horario y con la anticipacion minima.
  IF NOT v_zone_active THEN
    v_conflicts := jsonb_build_array(jsonb_build_object('reason', 'zone_inactive'));
  ELSIF extract(minute FROM p_time) <> 0 OR extract(second FROM p_time) <> 0
     OR extract(hour FROM p_time) NOT BETWEEN v_settings.first_slot_hour AND v_settings.last_slot_hour THEN
    v_conflicts := jsonb_build_array(jsonb_build_object('reason', 'slot_invalid'));
  ELSIF (p_date + p_time) < ((clock_timestamp() AT TIME ZONE 'America/Guayaquil') + make_interval(mins => v_settings.min_lead_minutes)) THEN
    v_conflicts := jsonb_build_array(jsonb_build_object('reason', 'slot_unavailable'));
  END IF;

  IF jsonb_array_length(v_conflicts) = 0 THEN
    PERFORM pg_advisory_xact_lock(hashtextextended('slot:' || p_zone::text || ':' || p_date::text || ':' || extract(hour FROM p_time)::integer::text, 0));
    SELECT count(*) INTO v_reserved FROM orders
     WHERE zone_id = p_zone AND delivery_date = p_date AND extract(hour FROM delivery_time) = extract(hour FROM p_time)
       AND status <> 'cancelado';
    IF v_reserved >= v_settings.slot_capacity THEN
      v_conflicts := jsonb_build_array(jsonb_build_object('reason', 'slot_full', 'capacity', v_settings.slot_capacity));
    END IF;
  END IF;

  IF jsonb_array_length(v_conflicts) = 0 THEN
    -- Bloqueo en orden de id (evita interbloqueos entre compras con los mismos productos) y comprobacion ya bloqueada.
    SELECT array_agg(t."productId" ORDER BY t."productId") INTO v_ids
      FROM jsonb_to_recordset(v_items) AS t("productId" uuid);
    PERFORM 1 FROM products WHERE id = ANY (v_ids) ORDER BY id FOR UPDATE;

    FOR r IN
      SELECT t."productId" AS product_id, t.quantity, t."unitPriceCents" AS expected_price,
             p.id AS found_id, p.price_cents, p.stock_quantity,
             (p.is_active AND coalesce(c.is_active, false)) AS orderable
        FROM jsonb_to_recordset(v_items) AS t("productId" uuid, quantity integer, "unitPriceCents" integer)
        LEFT JOIN products p ON p.id = t."productId"
        LEFT JOIN categories c ON c.id = p.category_id
       ORDER BY t."productId"
    LOOP
      IF r.found_id IS NULL OR NOT r.orderable THEN
        v_conflicts := v_conflicts || jsonb_build_object('productId', r.product_id, 'reason', 'unavailable');
      ELSIF r.price_cents <> r.expected_price THEN
        v_conflicts := v_conflicts || jsonb_build_object('productId', r.product_id, 'reason', 'price_changed', 'currentPriceCents', r.price_cents);
      ELSIF r.stock_quantity < r.quantity THEN
        v_conflicts := v_conflicts || jsonb_build_object('productId', r.product_id, 'reason', 'insufficient_stock', 'available', r.stock_quantity);
      END IF;
    END LOOP;
  END IF;

  IF jsonb_array_length(v_conflicts) > 0 THEN
    v_result := jsonb_build_object('status', 'conflict', 'conflicts', v_conflicts, 'replayed', false);
    PERFORM finish_request(op.id, v_result);
    RETURN v_result;
  END IF;

  v_order := create_order_for_customer(p_zone, p_address, p_date, p_time, p_recipient, p_phone, p_notes, p_customer);

  INSERT INTO order_items(order_id, product_id, sku, product_name, unit_price_cents, quantity)
    SELECT v_order, p.id, p.sku, p.name, p.price_cents, t.quantity
      FROM jsonb_to_recordset(v_items) AS t("productId" uuid, quantity integer, "unitPriceCents" integer)
      JOIN products p ON p.id = t."productId";

  UPDATE products p
     SET stock_quantity = p.stock_quantity - t.quantity, updated_at = clock_timestamp()
    FROM jsonb_to_recordset(v_items) AS t("productId" uuid, quantity integer, "unitPriceCents" integer)
   WHERE p.id = t."productId";

  INSERT INTO stock_movements(product_id, order_id, delta, reason, balance_after, actor_user_id)
    SELECT p.id, v_order, -t.quantity, 'sale', p.stock_quantity, p_customer
      FROM jsonb_to_recordset(v_items) AS t("productId" uuid, quantity integer, "unitPriceCents" integer)
      JOIN products p ON p.id = t."productId";

  SELECT sum(line_total_cents), count(*) INTO v_total, v_count FROM order_items WHERE order_id = v_order;
  INSERT INTO store_orders(order_id, customer_user_id, total_cents, items_count) VALUES (v_order, p_customer, v_total, v_count);

  v_result := jsonb_build_object('status', 'ok', 'orderId', v_order, 'totalCents', v_total, 'itemsCount', v_count, 'replayed', false);
  PERFORM finish_request(op.id, v_result);
  RETURN v_result;
END $$;
CREATE OR REPLACE FUNCTION delivery_slots(p_zone uuid, p_date date)
RETURNS TABLE (slot_time time, capacity integer, reserved integer, available boolean)
LANGUAGE sql SECURITY DEFINER SET search_path = logistica, pg_temp AS $$
  SELECT make_time(h, 0, 0),
         s.slot_capacity,
         coalesce(o.n, 0)::integer,
         ((p_date + make_time(h, 0, 0)) >= ((clock_timestamp() AT TIME ZONE 'America/Guayaquil') + make_interval(mins => s.min_lead_minutes))
           AND coalesce(o.n, 0) < s.slot_capacity)
    FROM store_settings s
   CROSS JOIN generate_series(s.first_slot_hour, s.last_slot_hour) AS h
    LEFT JOIN LATERAL (
      SELECT count(*) AS n FROM orders x
       WHERE x.zone_id = p_zone AND x.delivery_date = p_date AND extract(hour FROM x.delivery_time) = h AND x.status <> 'cancelado'
    ) o ON true
   ORDER BY h
$$;

-- ---------------------------------------------------------------------------
-- 3. Tablas nuevas (historial inmutable)
-- ---------------------------------------------------------------------------
CREATE TABLE order_cancellations (
  order_id uuid PRIMARY KEY REFERENCES orders(id) ON DELETE RESTRICT,
  reason text NOT NULL CHECK (reason IN ('cliente_desiste', 'error_en_pedido', 'sin_stock', 'no_localizable', 'demora', 'otro')),
  note text CHECK (note IS NULL OR (length(note) BETWEEN 1 AND 300 AND is_clean_store_multiline(note))),
  cancelled_by uuid NOT NULL REFERENCES app_users(id) ON DELETE RESTRICT,
  restocked boolean NOT NULL,
  cancelled_at timestamptz NOT NULL DEFAULT clock_timestamp()
);

CREATE TABLE delivery_failures (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid NOT NULL REFERENCES orders(id) ON DELETE RESTRICT,
  attempt_no integer NOT NULL CHECK (attempt_no BETWEEN 1 AND 3),
  reason text NOT NULL CHECK (reason IN ('cliente_ausente', 'direccion_incorrecta', 'cliente_rechazo', 'zona_inaccesible', 'otro')),
  note text CHECK (note IS NULL OR (length(note) BETWEEN 1 AND 300 AND is_clean_store_multiline(note))),
  courier_user_id uuid NOT NULL REFERENCES app_users(id) ON DELETE RESTRICT,
  created_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  UNIQUE (order_id, attempt_no)
);

CREATE TABLE order_collections (
  order_id uuid PRIMARY KEY REFERENCES orders(id) ON DELETE RESTRICT,
  amount_cents bigint NOT NULL CHECK (amount_cents > 0),
  courier_user_id uuid NOT NULL REFERENCES app_users(id) ON DELETE RESTRICT,
  method text NOT NULL DEFAULT 'efectivo' CHECK (method IN ('efectivo')),
  collected_at timestamptz NOT NULL DEFAULT clock_timestamp()
);
CREATE INDEX order_collections_courier_idx ON order_collections(courier_user_id, collected_at);

CREATE TABLE cash_settlements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  courier_user_id uuid NOT NULL REFERENCES app_users(id) ON DELETE RESTRICT,
  service_date date NOT NULL,
  expected_cents bigint NOT NULL CHECK (expected_cents > 0),
  received_cents bigint NOT NULL CHECK (received_cents >= 0),
  note text CHECK (note IS NULL OR (length(note) BETWEEN 1 AND 300 AND is_clean_store_multiline(note))),
  settled_by uuid NOT NULL REFERENCES app_users(id) ON DELETE RESTRICT,
  settled_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  UNIQUE (courier_user_id, service_date)
);

CREATE TRIGGER order_cancellations_immutable BEFORE UPDATE OR DELETE ON order_cancellations FOR EACH ROW EXECUTE FUNCTION store_immutable();
CREATE TRIGGER delivery_failures_immutable BEFORE UPDATE OR DELETE ON delivery_failures FOR EACH ROW EXECUTE FUNCTION store_immutable();
CREATE TRIGGER order_collections_immutable BEFORE UPDATE OR DELETE ON order_collections FOR EACH ROW EXECUTE FUNCTION store_immutable();
CREATE TRIGGER cash_settlements_immutable BEFORE UPDATE OR DELETE ON cash_settlements FOR EACH ROW EXECUTE FUNCTION store_immutable();

-- Libreta de direcciones del cliente. Una direccion predeterminada como maximo.
CREATE TABLE customer_addresses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES app_users(id) ON DELETE CASCADE,
  label text NOT NULL CHECK (label = btrim(label) AND length(label) BETWEEN 2 AND 40 AND is_clean_store_text(label)),
  label_key text GENERATED ALWAYS AS (lower(label)) STORED,
  zone_id uuid NOT NULL REFERENCES zones(id) ON DELETE RESTRICT,
  address text NOT NULL CHECK (address = btrim(address) AND length(address) BETWEEN 5 AND 200 AND is_clean_store_text(address)),
  recipient_name text CHECK (recipient_name IS NULL OR (recipient_name = btrim(recipient_name) AND length(recipient_name) BETWEEN 2 AND 120 AND is_clean_store_text(recipient_name))),
  recipient_phone text CHECK (recipient_phone IS NULL OR recipient_phone ~ '^\+?[0-9]{7,15}$'),
  is_default boolean NOT NULL DEFAULT false,
  version bigint NOT NULL DEFAULT 1 CHECK (version > 0),
  created_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  updated_at timestamptz NOT NULL DEFAULT clock_timestamp()
);
CREATE UNIQUE INDEX customer_addresses_label_idx ON customer_addresses(user_id, label_key);
CREATE UNIQUE INDEX customer_addresses_default_idx ON customer_addresses(user_id) WHERE is_default;

-- Cola de correos. Un registro por cambio de estado (UNIQUE order_id + version): nunca se envia dos veces el mismo aviso.
CREATE TABLE notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES app_users(id) ON DELETE CASCADE,
  order_id uuid NOT NULL REFERENCES orders(id) ON DELETE RESTRICT,
  order_version bigint NOT NULL,
  kind text NOT NULL CHECK (kind IN ('order_confirmed', 'order_status', 'order_cancelled', 'order_rescheduled')),
  status_to text,
  state text NOT NULL DEFAULT 'pendiente' CHECK (state IN ('pendiente', 'enviada', 'omitida', 'fallida')),
  attempts integer NOT NULL DEFAULT 0 CHECK (attempts >= 0),
  next_attempt_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  locked_until timestamptz,
  created_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  sent_at timestamptz,
  UNIQUE (order_id, order_version, kind)
);
CREATE INDEX notifications_pending_idx ON notifications(next_attempt_at, id) WHERE state = 'pendiente';

-- Confirmacion al crear el pedido de tienda y avisos de cambio de estado. Se dispara dentro de la misma transaccion
-- que el cambio, asi que si el pedido se confirma el aviso queda en la cola aunque el servidor se caiga despues.
CREATE FUNCTION notify_store_order_created() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = logistica, pg_temp AS $$
DECLARE v_version bigint;
BEGIN
  SELECT version INTO v_version FROM orders WHERE id = NEW.order_id;
  INSERT INTO notifications(user_id, order_id, order_version, kind) VALUES (NEW.customer_user_id, NEW.order_id, v_version, 'order_confirmed')
    ON CONFLICT DO NOTHING;
  RETURN NULL;
END $$;
CREATE TRIGGER store_orders_notify AFTER INSERT ON store_orders FOR EACH ROW EXECUTE FUNCTION notify_store_order_created();

CREATE FUNCTION notify_store_order_status() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = logistica, pg_temp AS $$
DECLARE v_customer uuid; v_kind text;
BEGIN
  IF NEW.status = OLD.status THEN RETURN NULL; END IF;
  SELECT customer_user_id INTO v_customer FROM store_orders WHERE order_id = NEW.id;
  IF v_customer IS NULL THEN RETURN NULL; END IF;
  v_kind := CASE
    WHEN NEW.status = 'cancelado' THEN 'order_cancelled'
    WHEN NEW.status IN ('en_camino', 'entregado', 'entrega_fallida') THEN 'order_status'
    WHEN OLD.status = 'entrega_fallida' AND NEW.status = 'pendiente' THEN 'order_rescheduled'
  END;
  IF v_kind IS NOT NULL THEN
    INSERT INTO notifications(user_id, order_id, order_version, kind, status_to) VALUES (v_customer, NEW.id, NEW.version, v_kind, NEW.status)
      ON CONFLICT DO NOTHING;
  END IF;
  RETURN NULL;
END $$;
CREATE TRIGGER orders_notify AFTER UPDATE ON orders FOR EACH ROW EXECUTE FUNCTION notify_store_order_status();

-- ---------------------------------------------------------------------------
-- 4. Cancelar un pedido (cliente dueno o administrador)
--    Bloqueo en el mismo orden que el resto del despacho: ruta -> pedido -> productos.
--    Idempotente por estado: cancelar un pedido ya cancelado devuelve el mismo resultado sin tocar nada.
-- ---------------------------------------------------------------------------
CREATE FUNCTION cancel_order(p_order uuid, p_actor uuid, p_reason text, p_note text) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path = logistica, pg_temp AS $$
DECLARE
  actor app_users; o orders; r routes; v_restocked boolean := false; v_other integer; v_version bigint;
BEGIN
  SELECT * INTO actor FROM app_users WHERE id = p_actor AND is_active;
  IF actor.id IS NULL OR actor.role NOT IN ('personal', 'cliente') THEN RAISE EXCEPTION 'UNAUTHORIZED_ACTOR' USING ERRCODE = '42501'; END IF;
  IF p_reason IS NULL OR p_reason NOT IN ('cliente_desiste', 'error_en_pedido', 'sin_stock', 'no_localizable', 'demora', 'otro') THEN
    RAISE EXCEPTION 'INVALID_CANCEL_REASON' USING ERRCODE = '22023';
  END IF;

  SELECT x.* INTO r FROM routes x JOIN route_stops st ON st.route_id = x.id WHERE st.order_id = p_order AND st.released_at IS NULL FOR UPDATE OF x;
  SELECT * INTO o FROM orders WHERE id = p_order FOR UPDATE;
  IF o.id IS NULL OR (actor.role = 'cliente' AND o.customer_user_id IS DISTINCT FROM p_actor) THEN
    RAISE EXCEPTION 'ORDER_NOT_FOUND' USING ERRCODE = 'LG404';
  END IF;
  IF o.status = 'cancelado' THEN
    RETURN jsonb_build_object('status', 'cancelado', 'alreadyCancelled', true, 'version', o.version);
  END IF;
  -- El pedido se asigno a una ruta entre la lectura de la ruta y el bloqueo del pedido: se repite (la API reintenta).
  IF o.status = 'asignado_a_ruta' AND r.id IS NULL THEN RAISE EXCEPTION 'ORDER_MOVED' USING ERRCODE = '40001'; END IF;
  -- Pendiente o asignado; o con entrega fallida una vez cerrada la ruta (sin parada vigente).
  IF o.status NOT IN ('pendiente', 'asignado_a_ruta', 'entrega_fallida') OR (o.status = 'entrega_fallida' AND r.id IS NOT NULL) THEN
    RAISE EXCEPTION 'ORDER_NOT_CANCELLABLE' USING ERRCODE = '23514';
  END IF;
  IF o.status = 'asignado_a_ruta' THEN
    SELECT count(*) INTO v_other FROM route_stops WHERE route_id = r.id AND released_at IS NULL AND order_id <> p_order;
    -- Una ruta en curso no puede quedar vacia: la ultima parada no se cancela (el conductor la cierra como fallida).
    IF r.status = 'en_curso' AND v_other = 0 THEN RAISE EXCEPTION 'ORDER_NOT_CANCELLABLE' USING ERRCODE = '23514'; END IF;
  END IF;

  PERFORM set_config('logistica.actor_subject', actor.auth_subject, true);
  PERFORM set_config('logistica.source', 'web', true);
  IF o.status = 'asignado_a_ruta' THEN
    UPDATE route_stops SET released_at = clock_timestamp(), release_reason = 'pedido_cancelado' WHERE order_id = p_order AND released_at IS NULL;
  END IF;
  UPDATE orders SET status = 'cancelado' WHERE id = p_order RETURNING version INTO v_version;
  IF r.id IS NOT NULL AND r.status = 'asignada' AND NOT EXISTS (SELECT 1 FROM route_stops WHERE route_id = r.id AND released_at IS NULL) THEN
    UPDATE routes SET status = 'cancelada' WHERE id = r.id;
  END IF;

  IF EXISTS (SELECT 1 FROM store_orders WHERE order_id = p_order) THEN
    PERFORM 1 FROM products WHERE id IN (SELECT product_id FROM order_items WHERE order_id = p_order) ORDER BY id FOR UPDATE;
    UPDATE products p SET stock_quantity = p.stock_quantity + i.quantity, updated_at = clock_timestamp()
      FROM order_items i WHERE i.order_id = p_order AND p.id = i.product_id;
    INSERT INTO stock_movements(product_id, order_id, delta, reason, balance_after, actor_user_id)
      SELECT p.id, p_order, i.quantity, 'cancel', p.stock_quantity, p_actor
        FROM order_items i JOIN products p ON p.id = i.product_id WHERE i.order_id = p_order;
    v_restocked := true;
  END IF;
  INSERT INTO order_cancellations(order_id, reason, note, cancelled_by, restocked)
    VALUES (p_order, p_reason, NULLIF(btrim(coalesce(p_note, '')), ''), p_actor, v_restocked);
  RETURN jsonb_build_object('status', 'cancelado', 'alreadyCancelled', false, 'restocked', v_restocked, 'version', v_version);
END $$;

-- ---------------------------------------------------------------------------
-- 5. Entrega fallida (conductor) e intento de entrega
-- ---------------------------------------------------------------------------
CREATE FUNCTION fail_delivery(p_order uuid, p_expected_version bigint, p_actor uuid, p_reason text, p_note text, p_key uuid) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path = logistica, pg_temp AS $$
DECLARE
  op operation_requests; actor app_users; r routes; o orders; v_attempt integer; v_version bigint; v_result jsonb;
BEGIN
  SELECT * INTO actor FROM app_users WHERE id = p_actor AND is_active;
  IF actor.id IS NULL OR actor.role <> 'repartidor' THEN RAISE EXCEPTION 'UNAUTHORIZED_ACTOR' USING ERRCODE = '42501'; END IF;
  IF p_reason IS NULL OR p_reason NOT IN ('cliente_ausente', 'direccion_incorrecta', 'cliente_rechazo', 'zona_inaccesible', 'otro') THEN
    RAISE EXCEPTION 'INVALID_FAILURE_REASON' USING ERRCODE = '22023';
  END IF;
  op := begin_request('fail:' || p_actor::text || ':' || p_order::text, p_key,
          jsonb_build_object('orderId', p_order, 'version', p_expected_version, 'reason', p_reason, 'note', p_note));
  IF op.status = 'completada' THEN RETURN op.response_body || jsonb_build_object('replayed', true); END IF;

  SELECT x.* INTO r FROM routes x JOIN route_stops s ON s.route_id = x.id WHERE s.order_id = p_order AND s.released_at IS NULL FOR UPDATE OF x;
  SELECT * INTO o FROM orders WHERE id = p_order FOR UPDATE;
  IF r.id IS NULL OR o.id IS NULL OR o.version IS DISTINCT FROM p_expected_version THEN
    RAISE EXCEPTION 'STALE_ORDER_VERSION_OR_ASSIGNMENT' USING ERRCODE = '40001';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM couriers WHERE id = r.courier_id AND user_id = p_actor AND is_enabled) THEN
    RAISE EXCEPTION 'ORDER_NOT_OWNED_BY_COURIER' USING ERRCODE = '42501';
  END IF;
  IF o.status <> 'en_camino' THEN RAISE EXCEPTION 'INVALID_ORDER_TRANSITION' USING ERRCODE = '23514'; END IF;

  SELECT coalesce(max(attempt_no), 0) + 1 INTO v_attempt FROM delivery_failures WHERE order_id = p_order;
  IF v_attempt > 3 THEN RAISE EXCEPTION 'MAX_DELIVERY_ATTEMPTS' USING ERRCODE = '23514'; END IF;
  PERFORM set_config('logistica.actor_subject', actor.auth_subject, true);
  PERFORM set_config('logistica.source', 'mobile', true);
  INSERT INTO delivery_failures(order_id, attempt_no, reason, note, courier_user_id)
    VALUES (p_order, v_attempt, p_reason, NULLIF(btrim(coalesce(p_note, '')), ''), p_actor);
  UPDATE orders SET status = 'entrega_fallida' WHERE id = p_order RETURNING version INTO v_version;
  v_result := jsonb_build_object('orderId', p_order, 'status', 'entrega_fallida', 'version', v_version, 'attempt', v_attempt, 'replayed', false);
  PERFORM finish_request(op.id, v_result);
  RETURN v_result;
END $$;

-- ---------------------------------------------------------------------------
-- 6. Entrega con cobro (pedidos de tienda, contra entrega): el monto cobrado debe ser exactamente el total.
-- ---------------------------------------------------------------------------
CREATE FUNCTION deliver_store_order(p_order uuid, p_expected_version bigint, p_actor uuid, p_collected_cents bigint, p_key uuid) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path = logistica, pg_temp AS $$
DECLARE
  op operation_requests; s store_orders; v_version bigint; v_result jsonb;
BEGIN
  IF p_actor IS NULL OR NOT EXISTS (SELECT 1 FROM app_users WHERE id = p_actor AND is_active AND role = 'repartidor') THEN
    RAISE EXCEPTION 'UNAUTHORIZED_ACTOR' USING ERRCODE = '42501';
  END IF;
  IF p_collected_cents IS NULL OR p_collected_cents < 1 THEN RAISE EXCEPTION 'INVALID_AMOUNT' USING ERRCODE = '22023'; END IF;
  op := begin_request('deliver:' || p_actor::text || ':' || p_order::text, p_key,
          jsonb_build_object('orderId', p_order, 'version', p_expected_version, 'collected', p_collected_cents));
  IF op.status = 'completada' THEN RETURN op.response_body || jsonb_build_object('replayed', true); END IF;

  SELECT * INTO s FROM store_orders WHERE order_id = p_order;
  IF s.order_id IS NULL THEN RAISE EXCEPTION 'NOT_A_STORE_ORDER' USING ERRCODE = '23514'; END IF;
  IF p_collected_cents <> s.total_cents THEN RAISE EXCEPTION 'COLLECTION_AMOUNT_MISMATCH' USING ERRCODE = 'LG422'; END IF;
  -- change_order_status bloquea ruta y pedido, valida dueno, version y transicion; el cobro se inserta antes porque lo exige.
  INSERT INTO order_collections(order_id, amount_cents, courier_user_id) VALUES (p_order, p_collected_cents, p_actor);
  v_version := change_order_status(p_order, 'entregado', p_expected_version, p_actor);
  v_result := jsonb_build_object('orderId', p_order, 'status', 'entregado', 'version', v_version, 'collectedCents', p_collected_cents, 'replayed', false);
  PERFORM finish_request(op.id, v_result);
  RETURN v_result;
END $$;

-- ---------------------------------------------------------------------------
-- 7. Reprogramar un pedido con entrega fallida (administrador o cliente dueno)
-- ---------------------------------------------------------------------------
CREATE FUNCTION check_slot(p_zone uuid, p_date date, p_time time, p_exclude uuid) RETURNS text
LANGUAGE plpgsql AS $$
DECLARE v_settings store_settings; v_reserved integer;
BEGIN
  SELECT * INTO v_settings FROM store_settings;
  IF extract(minute FROM p_time) <> 0 OR extract(second FROM p_time) <> 0
     OR extract(hour FROM p_time) NOT BETWEEN v_settings.first_slot_hour AND v_settings.last_slot_hour THEN RETURN 'slot_invalid'; END IF;
  IF (p_date + p_time) < ((clock_timestamp() AT TIME ZONE 'America/Guayaquil') + make_interval(mins => v_settings.min_lead_minutes)) THEN
    RETURN 'slot_unavailable';
  END IF;
  PERFORM pg_advisory_xact_lock(hashtextextended('slot:' || p_zone::text || ':' || p_date::text || ':' || extract(hour FROM p_time)::integer::text, 0));
  SELECT count(*) INTO v_reserved FROM orders
   WHERE zone_id = p_zone AND delivery_date = p_date AND extract(hour FROM delivery_time) = extract(hour FROM p_time)
     AND status <> 'cancelado' AND id IS DISTINCT FROM p_exclude;
  IF v_reserved >= v_settings.slot_capacity THEN RETURN 'slot_full'; END IF;
  RETURN NULL;
END $$;

CREATE FUNCTION reschedule_order(p_order uuid, p_date date, p_time time, p_actor uuid) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path = logistica, pg_temp AS $$
DECLARE actor app_users; o orders; v_reason text; v_version bigint;
BEGIN
  SELECT * INTO actor FROM app_users WHERE id = p_actor AND is_active;
  IF actor.id IS NULL OR actor.role NOT IN ('personal', 'cliente') THEN RAISE EXCEPTION 'UNAUTHORIZED_ACTOR' USING ERRCODE = '42501'; END IF;
  IF p_date IS NULL OR p_time IS NULL OR extract(second FROM p_time) <> 0 THEN RAISE EXCEPTION 'INVALID_SCHEDULE' USING ERRCODE = '22023'; END IF;
  SELECT * INTO o FROM orders WHERE id = p_order FOR UPDATE;
  IF o.id IS NULL OR (actor.role = 'cliente' AND o.customer_user_id IS DISTINCT FROM p_actor) THEN
    RAISE EXCEPTION 'ORDER_NOT_FOUND' USING ERRCODE = 'LG404';
  END IF;
  IF o.status <> 'entrega_fallida' OR EXISTS (SELECT 1 FROM route_stops WHERE order_id = p_order AND released_at IS NULL) THEN
    RAISE EXCEPTION 'ORDER_NOT_RESCHEDULABLE' USING ERRCODE = '23514';
  END IF;
  IF (SELECT count(*) FROM delivery_failures WHERE order_id = p_order) >= 3 THEN RAISE EXCEPTION 'MAX_DELIVERY_ATTEMPTS' USING ERRCODE = '23514'; END IF;
  IF p_date < (clock_timestamp() AT TIME ZONE 'America/Guayaquil')::date THEN RAISE EXCEPTION 'DELIVERY_DATE_IN_PAST' USING ERRCODE = '22007'; END IF;
  IF EXISTS (SELECT 1 FROM store_orders WHERE order_id = p_order) THEN
    v_reason := check_slot(o.zone_id, p_date, p_time, p_order);
    IF v_reason IS NOT NULL THEN RETURN jsonb_build_object('status', 'conflict', 'reason', v_reason); END IF;
  END IF;
  PERFORM set_config('logistica.actor_subject', actor.auth_subject, true);
  PERFORM set_config('logistica.source', 'web', true);
  UPDATE orders SET status = 'pendiente', delivery_date = p_date, delivery_time = p_time WHERE id = p_order RETURNING version INTO v_version;
  RETURN jsonb_build_object('status', 'ok', 'orderId', p_order, 'orderStatus', 'pendiente', 'version', v_version);
END $$;

-- ---------------------------------------------------------------------------
-- 8. Rendicion de caja del conductor (administrador)
-- ---------------------------------------------------------------------------
CREATE FUNCTION settle_cash(p_courier_user uuid, p_date date, p_received_cents bigint, p_note text, p_actor uuid) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path = logistica, pg_temp AS $$
DECLARE v_expected bigint;
BEGIN
  PERFORM require_store_admin(p_actor);
  IF p_received_cents IS NULL OR p_received_cents < 0 OR p_date IS NULL THEN RAISE EXCEPTION 'INVALID_AMOUNT' USING ERRCODE = '22023'; END IF;
  PERFORM 1 FROM app_users WHERE id = p_courier_user AND role = 'repartidor';
  IF NOT FOUND THEN RAISE EXCEPTION 'COURIER_NOT_FOUND' USING ERRCODE = 'LG404'; END IF;
  SELECT coalesce(sum(amount_cents), 0) INTO v_expected FROM order_collections
   WHERE courier_user_id = p_courier_user AND (collected_at AT TIME ZONE 'America/Guayaquil')::date = p_date;
  IF v_expected = 0 THEN RAISE EXCEPTION 'NOTHING_TO_SETTLE' USING ERRCODE = '22023'; END IF;
  INSERT INTO cash_settlements(courier_user_id, service_date, expected_cents, received_cents, note, settled_by)
    VALUES (p_courier_user, p_date, v_expected, p_received_cents, NULLIF(btrim(coalesce(p_note, '')), ''), p_actor);
  RETURN jsonb_build_object('expectedCents', v_expected, 'receivedCents', p_received_cents, 'differenceCents', p_received_cents - v_expected);
END $$;

-- ---------------------------------------------------------------------------
-- 9. Libreta de direcciones (cada cliente solo toca las suyas)
-- ---------------------------------------------------------------------------
CREATE FUNCTION create_address(p_user uuid, p_label text, p_zone uuid, p_address text, p_recipient text, p_phone text, p_default boolean) RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path = logistica, pg_temp AS $$
DECLARE v_id uuid; v_count integer; v_default boolean;
BEGIN
  PERFORM 1 FROM app_users WHERE id = p_user AND role = 'cliente' AND is_active FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'UNAUTHORIZED_ACTOR' USING ERRCODE = '42501'; END IF;
  PERFORM 1 FROM zones WHERE id = p_zone AND is_active;
  IF NOT FOUND THEN RAISE EXCEPTION 'ZONE_NOT_FOUND' USING ERRCODE = '23503'; END IF;
  SELECT count(*) INTO v_count FROM customer_addresses WHERE user_id = p_user;
  IF v_count >= 10 THEN RAISE EXCEPTION 'ADDRESS_LIMIT' USING ERRCODE = 'LG413'; END IF;
  v_default := coalesce(p_default, false) OR v_count = 0;
  IF v_default THEN UPDATE customer_addresses SET is_default = false, version = version + 1, updated_at = clock_timestamp() WHERE user_id = p_user AND is_default; END IF;
  INSERT INTO customer_addresses(user_id, label, zone_id, address, recipient_name, recipient_phone, is_default)
    VALUES (p_user, btrim(p_label), p_zone, btrim(p_address), NULLIF(btrim(coalesce(p_recipient, '')), ''), p_phone, v_default) RETURNING id INTO v_id;
  RETURN v_id;
END $$;

CREATE FUNCTION update_address(p_id uuid, p_user uuid, p_patch jsonb, p_expected_version bigint) RETURNS bigint
LANGUAGE plpgsql SECURITY DEFINER SET search_path = logistica, pg_temp AS $$
DECLARE a customer_addresses; v_version bigint;
BEGIN
  IF jsonb_typeof(p_patch) IS DISTINCT FROM 'object' OR p_patch = '{}'::jsonb
     OR EXISTS (SELECT 1 FROM jsonb_object_keys(p_patch) k WHERE k NOT IN ('label', 'zoneId', 'address', 'recipientName', 'recipientPhone', 'isDefault')) THEN
    RAISE EXCEPTION 'INVALID_PATCH' USING ERRCODE = '22023';
  END IF;
  PERFORM 1 FROM app_users WHERE id = p_user AND role = 'cliente' AND is_active FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'UNAUTHORIZED_ACTOR' USING ERRCODE = '42501'; END IF;
  SELECT * INTO a FROM customer_addresses WHERE id = p_id AND user_id = p_user FOR UPDATE;
  IF a.id IS NULL THEN RAISE EXCEPTION 'ADDRESS_NOT_FOUND' USING ERRCODE = 'LG404'; END IF;
  IF a.version <> p_expected_version THEN RAISE EXCEPTION 'VERSION_CONFLICT' USING ERRCODE = 'LG409'; END IF;
  IF p_patch ? 'zoneId' THEN
    PERFORM 1 FROM zones WHERE id = (p_patch ->> 'zoneId')::uuid AND is_active;
    IF NOT FOUND THEN RAISE EXCEPTION 'ZONE_NOT_FOUND' USING ERRCODE = '23503'; END IF;
  END IF;
  IF p_patch ? 'isDefault' THEN
    IF (p_patch ->> 'isDefault')::boolean THEN
      UPDATE customer_addresses SET is_default = false, version = version + 1, updated_at = clock_timestamp() WHERE user_id = p_user AND is_default AND id <> p_id;
    ELSIF a.is_default THEN
      RAISE EXCEPTION 'DEFAULT_REQUIRED' USING ERRCODE = '22023';
    END IF;
  END IF;
  UPDATE customer_addresses SET
    label = CASE WHEN p_patch ? 'label' THEN btrim(p_patch ->> 'label') ELSE label END,
    zone_id = CASE WHEN p_patch ? 'zoneId' THEN (p_patch ->> 'zoneId')::uuid ELSE zone_id END,
    address = CASE WHEN p_patch ? 'address' THEN btrim(p_patch ->> 'address') ELSE address END,
    recipient_name = CASE WHEN p_patch ? 'recipientName' THEN NULLIF(btrim(coalesce(p_patch ->> 'recipientName', '')), '') ELSE recipient_name END,
    recipient_phone = CASE WHEN p_patch ? 'recipientPhone' THEN NULLIF(p_patch ->> 'recipientPhone', '') ELSE recipient_phone END,
    is_default = CASE WHEN p_patch ? 'isDefault' THEN (p_patch ->> 'isDefault')::boolean ELSE is_default END,
    version = version + 1, updated_at = clock_timestamp()
  WHERE id = p_id RETURNING version INTO v_version;
  RETURN v_version;
END $$;

CREATE FUNCTION delete_address(p_id uuid, p_user uuid) RETURNS boolean
LANGUAGE plpgsql SECURITY DEFINER SET search_path = logistica, pg_temp AS $$
DECLARE a customer_addresses;
BEGIN
  PERFORM 1 FROM app_users WHERE id = p_user AND role = 'cliente' AND is_active FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'UNAUTHORIZED_ACTOR' USING ERRCODE = '42501'; END IF;
  DELETE FROM customer_addresses WHERE id = p_id AND user_id = p_user RETURNING * INTO a;
  IF a.id IS NULL THEN RAISE EXCEPTION 'ADDRESS_NOT_FOUND' USING ERRCODE = 'LG404'; END IF;
  IF a.is_default THEN
    UPDATE customer_addresses SET is_default = true, version = version + 1, updated_at = clock_timestamp()
     WHERE id = (SELECT id FROM customer_addresses WHERE user_id = p_user ORDER BY updated_at DESC, id LIMIT 1);
  END IF;
  RETURN true;
END $$;

-- ---------------------------------------------------------------------------
-- 10. Cola de correos: la API reclama avisos pendientes (SKIP LOCKED: varias instancias no se pisan) y los marca.
-- ---------------------------------------------------------------------------
CREATE FUNCTION claim_notifications(p_limit integer DEFAULT 10)
RETURNS TABLE (id uuid, order_id uuid, kind text, status_to text, attempts integer, email text, display_name text, email_verified_via text)
LANGUAGE sql SECURITY DEFINER SET search_path = logistica, pg_temp AS $$
  WITH picked AS (
    SELECT n.id FROM notifications n
     WHERE n.state = 'pendiente' AND n.next_attempt_at <= clock_timestamp() AND (n.locked_until IS NULL OR n.locked_until < clock_timestamp())
     ORDER BY n.next_attempt_at, n.id LIMIT least(greatest(p_limit, 1), 50) FOR UPDATE SKIP LOCKED
  ), upd AS (
    UPDATE notifications n SET locked_until = clock_timestamp() + interval '60 seconds', attempts = n.attempts + 1
      FROM picked WHERE n.id = picked.id
    RETURNING n.id, n.user_id, n.order_id, n.kind, n.status_to, n.attempts
  )
  SELECT upd.id, upd.order_id, upd.kind, upd.status_to, upd.attempts, u.email, u.display_name, u.email_verified_via
    FROM upd JOIN app_users u ON u.id = upd.user_id
$$;

-- outcome: sent (enviado), skipped (sin correo valido o modo demo) o retry (fallo: reintento con espera; 5 intentos y se rinde).
CREATE FUNCTION finish_notification(p_id uuid, p_outcome text) RETURNS boolean
LANGUAGE plpgsql SECURITY DEFINER SET search_path = logistica, pg_temp AS $$
BEGIN
  IF p_outcome NOT IN ('sent', 'skipped', 'retry') THEN RAISE EXCEPTION 'INVALID_OUTCOME' USING ERRCODE = '22023'; END IF;
  IF p_outcome = 'sent' THEN
    UPDATE notifications SET state = 'enviada', sent_at = clock_timestamp(), locked_until = NULL WHERE id = p_id;
  ELSIF p_outcome = 'skipped' THEN
    UPDATE notifications SET state = 'omitida', locked_until = NULL WHERE id = p_id;
  ELSE
    UPDATE notifications SET locked_until = NULL, next_attempt_at = clock_timestamp() + (attempts * 2) * interval '1 minute',
           state = CASE WHEN attempts >= 5 THEN 'fallida' ELSE 'pendiente' END
     WHERE id = p_id;
  END IF;
  RETURN FOUND;
END $$;

-- ---------------------------------------------------------------------------
-- 11. Permisos
-- ---------------------------------------------------------------------------
GRANT SELECT ON logistica.order_cancellations, logistica.delivery_failures, logistica.order_collections, logistica.cash_settlements,
  logistica.customer_addresses, logistica.notifications TO logistica_app, logistica_readonly;

REVOKE ALL ON FUNCTION
  logistica.cancel_order(uuid, uuid, text, text),
  logistica.fail_delivery(uuid, bigint, uuid, text, text, uuid),
  logistica.deliver_store_order(uuid, bigint, uuid, bigint, uuid),
  logistica.check_slot(uuid, date, time, uuid),
  logistica.reschedule_order(uuid, date, time, uuid),
  logistica.settle_cash(uuid, date, bigint, text, uuid),
  logistica.create_address(uuid, text, uuid, text, text, text, boolean),
  logistica.update_address(uuid, uuid, jsonb, bigint),
  logistica.delete_address(uuid, uuid),
  logistica.claim_notifications(integer),
  logistica.finish_notification(uuid, text),
  logistica.notify_store_order_created(),
  logistica.notify_store_order_status()
FROM PUBLIC;

GRANT EXECUTE ON FUNCTION
  logistica.cancel_order(uuid, uuid, text, text),
  logistica.fail_delivery(uuid, bigint, uuid, text, text, uuid),
  logistica.deliver_store_order(uuid, bigint, uuid, bigint, uuid),
  logistica.reschedule_order(uuid, date, time, uuid),
  logistica.settle_cash(uuid, date, bigint, text, uuid),
  logistica.create_address(uuid, text, uuid, text, text, text, boolean),
  logistica.update_address(uuid, uuid, jsonb, bigint),
  logistica.delete_address(uuid, uuid),
  logistica.claim_notifications(integer),
  logistica.finish_notification(uuid, text)
TO logistica_app;
