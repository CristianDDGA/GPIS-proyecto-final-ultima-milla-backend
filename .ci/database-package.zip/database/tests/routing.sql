\set ON_ERROR_STOP on
BEGIN;
SET search_path=logistica,pg_catalog;
CREATE FUNCTION pg_temp.check_true(value boolean,message text) RETURNS void LANGUAGE plpgsql AS $$
BEGIN IF value IS DISTINCT FROM true THEN RAISE EXCEPTION 'TEST_FAILED: %',message; END IF; END $$;

-- Vecino mas cercano: A (10:00) y C (10:20) estan a ~100 m entre si; B (10:10) esta a ~22 km.
DO $$
DECLARE cust uuid; z uuid; a uuid; b uuid; c uuid; r jsonb; rid uuid; ord uuid[]; d date=CURRENT_DATE+5;
BEGIN
  INSERT INTO app_users(auth_subject,role,email,password_hash) VALUES('ruta-cli','cliente','ruta@test.local','scrypt$x$y') RETURNING id INTO cust;
  z=create_zone('Ruteo NN');
  a=create_order(z,'Calle A',d,time '10:00'); b=create_order(z,'Calle B lejos',d,time '10:10'); c=create_order(z,'Calle C',d,time '10:20');
  INSERT INTO store_orders(order_id,customer_user_id,total_cents,items_count,delivery_latitude,delivery_longitude) VALUES
    (a,cust,1000,1,-0.1000,-78.5000),(b,cust,1000,1,-0.3000,-78.5000),(c,cust,1000,1,-0.1010,-78.5000);
  r=generate_routes(d,3,gen_random_uuid());
  rid=(r->'routeIds'->>0)::uuid;
  SELECT array_agg(order_id ORDER BY position) INTO ord FROM route_stops WHERE route_id=rid AND released_at IS NULL;
  PERFORM pg_temp.check_true(ord=ARRAY[a,c,b],'vecino mas cercano: A, C (cerca) y luego B (lejos), no por hora A,B,C');
  PERFORM pg_temp.check_true((SELECT algorithm_version='zona_hora_nn_v2' FROM routes WHERE id=rid),'ruta marcada con el algoritmo nuevo');
END $$;

-- Sin coordenadas el orden sigue siendo por hora.
DO $$
DECLARE z uuid; a uuid; b uuid; r jsonb; rid uuid; ord uuid[]; d date=CURRENT_DATE+6;
BEGIN
  z=create_zone('Ruteo sin pin');
  b=create_order(z,'Calle 2',d,time '11:00'); a=create_order(z,'Calle 1',d,time '09:00');
  r=generate_routes(d,4,gen_random_uuid()); rid=(r->'routeIds'->>0)::uuid;
  SELECT array_agg(order_id ORDER BY position) INTO ord FROM route_stops WHERE route_id=rid AND released_at IS NULL;
  PERFORM pg_temp.check_true(ord=ARRAY[a,b],'sin coordenadas manda la hora');
END $$;

-- Pedido tardio: elige la ruta mas cercana aunque no sea la mas antigua.
DO $$
DECLARE cust uuid; z uuid; far_o uuid; near_o uuid; late uuid; far_r uuid; near_r uuid; res jsonb; d date=CURRENT_DATE+7;
BEGIN
  INSERT INTO app_users(auth_subject,role,email,password_hash) VALUES('tarde-cli','cliente','tarde@test.local','scrypt$x$y') RETURNING id INTO cust;
  z=create_zone('Tardio cercano');
  far_o=create_order(z,'Lejos',d,time '10:00'); near_o=create_order(z,'Cerca',d,time '10:00'); late=create_order(z,'Tardio',d,time '10:30');
  INSERT INTO store_orders(order_id,customer_user_id,total_cents,items_count,delivery_latitude,delivery_longitude) VALUES
    (far_o,cust,1000,1,-0.4000,-78.5000),(near_o,cust,1000,1,-0.1000,-78.5000),(late,cust,1000,1,-0.1005,-78.5000);
  far_r=create_route(z,d,3); near_r=create_route(z,d,3);
  PERFORM add_order_to_route(far_r,far_o); PERFORM add_order_to_route(near_r,near_o);
  res=place_late_order(late,3,gen_random_uuid());
  PERFORM pg_temp.check_true((res->>'routeId')::uuid=near_r,'el pedido tardio va a la ruta mas cercana');
  PERFORM pg_temp.check_true((SELECT count(*)=2 FROM route_stops WHERE route_id=near_r AND released_at IS NULL),'la ruta cercana tiene 2 paradas');
END $$;

-- Conductor: entre dos libres gana el menos cargado del dia.
DO $$
DECLARE u1 uuid; u2 uuid; z uuid; c1 uuid; c2 uuid; o1 uuid; late uuid; rr uuid; v bigint; res jsonb; d date=CURRENT_DATE;
BEGIN
  INSERT INTO app_users(auth_subject,role) VALUES('carga-d1','repartidor') RETURNING id INTO u1;
  INSERT INTO app_users(auth_subject,role) VALUES('carga-d2','repartidor') RETURNING id INTO u2;
  z=create_zone('Carga conductor');
  c1=create_courier('Con carga',3,u1); c2=create_courier('Sin carga',3,u2);
  PERFORM set_courier_availability(c1,true); PERFORM set_courier_availability(c2,true);
  o1=create_order(z,'Entrega 1',d,time '23:00'); rr=create_route(z,d,3); PERFORM add_order_to_route(rr,o1); PERFORM assign_route(rr,c1);
  SELECT version INTO v FROM orders WHERE id=o1; v=change_order_status(o1,'recogido',v,u1);
  v=change_order_status(o1,'en_camino',v,u1); v=change_order_status(o1,'entregado',v,u1);
  PERFORM complete_route(rr);
  PERFORM pg_temp.check_true(courier_dispatch_score(c1,d,NULL,NULL)=3.0,'c1 puntaje 3 por una entrega hecha');
  PERFORM pg_temp.check_true(courier_dispatch_score(c2,d,NULL,NULL)=0,'c2 puntaje 0');
  late=create_order(z,'Tardio',d,time '23:30');
  res=place_late_order(late,3,gen_random_uuid());
  PERFORM pg_temp.check_true((SELECT courier_id=c2 FROM routes WHERE id=(res->>'routeId')::uuid),'gana el conductor menos cargado');
END $$;
ROLLBACK;
SELECT 'PASS: vecino mas cercano, orden por hora sin pin, ruta tardia cercana y conductor por puntaje' AS resultado;
