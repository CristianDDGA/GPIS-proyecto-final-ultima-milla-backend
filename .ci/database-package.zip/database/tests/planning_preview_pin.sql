\set ON_ERROR_STOP on
BEGIN;
SET search_path=logistica,pg_catalog;
CREATE FUNCTION pg_temp.check_true(value boolean,message text) RETURNS void LANGUAGE plpgsql AS $$
BEGIN IF value IS DISTINCT FROM true THEN RAISE EXCEPTION 'TEST_FAILED: %',message; END IF; END $$;

-- Vista previa: coincide con lo que genera generate_routes y no modifica nada (migracion 020).
DO $$
DECLARE za uuid; zb uuid; i integer; p jsonb; r jsonb; d date=CURRENT_DATE+20; failed boolean;
        routes_before integer; routes_after integer; sizes_a integer[]; sizes_b integer[];
BEGIN
  za=create_zone('Vista Previa A'); zb=create_zone('Vista Previa B');
  FOR i IN 1..5 LOOP PERFORM create_order(za,'Calle A '||i,d,time '10:00'); END LOOP;
  PERFORM create_order(zb,'Calle B 1',d,time '11:00');

  SELECT count(*) INTO routes_before FROM routes;
  p=preview_routes(d,2);
  SELECT count(*) INTO routes_after FROM routes;
  PERFORM pg_temp.check_true(routes_before=routes_after,'la vista previa no crea rutas');
  PERFORM pg_temp.check_true((SELECT count(*) FROM orders WHERE delivery_date=d AND status='pendiente')=6,'la vista previa no cambia los pedidos');

  PERFORM pg_temp.check_true((p->>'totalOrders')::int=6,'total de pedidos');
  PERFORM pg_temp.check_true((p->>'totalRoutes')::int=4,'total de rutas: ceil(5/2)+ceil(1/2)');
  PERFORM pg_temp.check_true(p->'zones'->0->>'zoneName'='Vista Previa A' AND (p->'zones'->0->>'orders')::int=5,'zona A: 5 pedidos');
  PERFORM pg_temp.check_true(p->'zones'->0->'routeSizes'='[2,2,1]'::jsonb,'zona A: tamanos 2,2,1');
  PERFORM pg_temp.check_true(p->'zones'->1->'routeSizes'='[1]'::jsonb,'zona B: tamano 1');
  PERFORM pg_temp.check_true(p->>'date'=d::text AND (p->>'capacity')::int=2,'fecha y capacidad devueltas');

  -- Coincide exactamente con el plan real.
  r=generate_routes(d,2,gen_random_uuid());
  PERFORM pg_temp.check_true(jsonb_array_length(r->'routeIds')=(p->>'totalRoutes')::int,'el plan genera las rutas que anuncio la vista previa');
  SELECT array_agg(occupied_slots ORDER BY created_at,id) INTO sizes_a FROM route_summary WHERE zone_id=za AND service_date=d;
  SELECT array_agg(occupied_slots ORDER BY created_at,id) INTO sizes_b FROM route_summary WHERE zone_id=zb AND service_date=d;
  PERFORM pg_temp.check_true(sizes_a=ARRAY[2,2,1],'rutas reales de la zona A: 2,2,1');
  PERFORM pg_temp.check_true(sizes_b=ARRAY[1],'ruta real de la zona B: 1');

  -- Ya sin pedidos pendientes, la vista previa queda vacia.
  p=preview_routes(d,2);
  PERFORM pg_temp.check_true((p->>'totalOrders')::int=0 AND (p->>'totalRoutes')::int=0 AND jsonb_array_length(p->'zones')=0,'sin pendientes, vista previa vacia');

  -- Parametros invalidos.
  failed:=false; BEGIN PERFORM preview_routes(d,0); EXCEPTION WHEN invalid_parameter_value THEN failed:=true; END;
  PERFORM pg_temp.check_true(failed,'capacidad 0 se rechaza');
  failed:=false; BEGIN PERFORM preview_routes(NULL,2); EXCEPTION WHEN invalid_parameter_value THEN failed:=true; END;
  PERFORM pg_temp.check_true(failed,'fecha nula se rechaza');
END $$;

-- Pin en pedidos del administrador (migracion 020).
DO $$
DECLARE z uuid; a uuid; b uuid; c uuid; sin_pin uuid; r jsonb; rid uuid; ord uuid[]; d date=CURRENT_DATE+21; failed boolean; lat double precision; lng double precision;
BEGIN
  z=create_zone('Pin Admin');
  a=create_order_with_pin(z,'Calle A',d,time '10:00',-0.1000,-78.5000);
  b=create_order_with_pin(z,'Calle B lejos',d,time '10:10',-0.3000,-78.5000);
  c=create_order_with_pin(z,'Calle C',d,time '10:20',-0.1010,-78.5000);
  SELECT delivery_latitude,delivery_longitude INTO lat,lng FROM orders WHERE id=a;
  PERFORM pg_temp.check_true(lat=-0.1000 AND lng=-78.5000,'el pedido guarda su pin');
  PERFORM pg_temp.check_true((SELECT version=1 AND status='pendiente' FROM orders WHERE id=a),'el pedido nace pendiente y version 1');

  -- Un pedido sin pin (create_order) sigue funcionando y queda sin coordenadas.
  sin_pin=create_order(z,'Sin pin',d,time '12:00');
  PERFORM pg_temp.check_true((SELECT delivery_latitude IS NULL AND delivery_longitude IS NULL FROM orders WHERE id=sin_pin),'create_order no cambia');

  -- Coordenadas invalidas.
  failed:=false; BEGIN PERFORM create_order_with_pin(z,'X',d,time '10:00',40,-78.5); EXCEPTION WHEN invalid_parameter_value THEN failed:=true; END;
  PERFORM pg_temp.check_true(failed,'un pin fuera de Ecuador se rechaza');
  failed:=false; BEGIN PERFORM create_order_with_pin(z,'X',d,time '10:00',NULL,-78.5); EXCEPTION WHEN invalid_parameter_value THEN failed:=true; END;
  PERFORM pg_temp.check_true(failed,'un pin con una sola coordenada se rechaza');

  -- Las rutas usan el pin del pedido del admin: A, C (cerca) y luego B (lejos), no por hora A,B,C.
  r=generate_routes(d,4,gen_random_uuid());
  rid=(r->'routeIds'->>0)::uuid;
  SELECT array_agg(s.order_id ORDER BY s.position) INTO ord FROM route_stops s WHERE s.route_id=rid AND s.released_at IS NULL AND s.order_id IN (a,b,c);
  PERFORM pg_temp.check_true(ord=ARRAY[a,c,b],'vecino mas cercano con pines de pedidos del admin: A, C, B');
END $$;
ROLLBACK;
SELECT 'PASS: vista previa de planificacion (coincide con el plan, sin efectos) y pin en pedidos del admin' AS resultado;
