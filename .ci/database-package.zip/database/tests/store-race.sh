#!/bin/sh
# Carreras reales de la tienda: varias conexiones PostgreSQL a la vez, liberadas por una compuerta comun.
#   A) ultima unidad          -> exactamente una compra gana, el stock queda en 0
#   B) misma Idempotency-Key  -> un solo pedido; las demas conexiones reciben el mismo resultado
#   C) cupo de una franja     -> exactamente 'cupo' pedidos entran
#   D) productos en orden opuesto -> sin interbloqueos
#   E) compras con ajustes de stock del administrador a la vez -> el libro de stock cuadra
set -eu
[ "$PGDATABASE" = logistica_test ] || { echo 'Solo se permite la base efimera logistica_test'; exit 1; }
OUT=/tmp/store-race
rm -rf "$OUT"; mkdir -p "$OUT"
DATE=$(psql -X -At -c "SELECT (CURRENT_DATE + 5)::text")
ZONE='a1000000-0000-4000-8000-000000000001'
ADMIN='a0000000-0000-4000-8000-000000000001'
CAT='a2000000-0000-4000-8000-000000000001'
cust() { printf 'b0000000-0000-4000-8000-0000000000%02d' "$1"; }
prod() { printf 'c0000000-0000-4000-8000-0000000000%02d' "$1"; }

psql -X -v ON_ERROR_STOP=1 <<SQL
INSERT INTO logistica.app_users(id, auth_subject, role) VALUES ('$ADMIN', 'race-admin', 'personal');
DO \$\$ BEGIN
  FOR i IN 1..12 LOOP
    INSERT INTO logistica.app_users(id, auth_subject, role)
      VALUES (('b0000000-0000-4000-8000-0000000000' || lpad(i::text, 2, '0'))::uuid, 'race-c' || i, 'cliente');
  END LOOP;
END \$\$;
INSERT INTO logistica.zones(id, name) VALUES ('$ZONE', 'Zona carrera tienda');
INSERT INTO logistica.categories(id, name) VALUES ('$CAT', 'Carrera');
INSERT INTO logistica.products(id, sku, name, category_id, price_cents, stock_quantity) VALUES
  ('$(prod 1)', 'RACE-A', 'Ultima unidad', '$CAT', 1000, 1),
  ('$(prod 2)', 'RACE-B', 'Misma clave', '$CAT', 1000, 20),
  ('$(prod 3)', 'RACE-C', 'Cupo de franja', '$CAT', 1000, 100),
  ('$(prod 4)', 'RACE-D1', 'Interbloqueo uno', '$CAT', 1000, 100),
  ('$(prod 5)', 'RACE-D2', 'Interbloqueo dos', '$CAT', 1000, 100),
  ('$(prod 6)', 'RACE-E', 'Con ajustes', '$CAT', 1000, 50);
INSERT INTO logistica.stock_movements(product_id, delta, reason, balance_after)
  SELECT id, stock_quantity, 'initial', stock_quantity FROM logistica.products WHERE sku LIKE 'RACE-%';
UPDATE logistica.store_settings SET slot_capacity = 50, first_slot_hour = 8, last_slot_hour = 20;
SQL

# Compuerta: los trabajadores se bloquean en un candado compartido que el dueno suelta a la vez.
gate_open() {
  rm -f "$OUT/gate-ready"
  psql -X -v ON_ERROR_STOP=1 >"$OUT/gate.log" 2>&1 <<'SQL' &
SELECT pg_advisory_lock(777);
\! touch /tmp/store-race/gate-ready
SELECT pg_sleep(1.5);
SELECT pg_advisory_unlock(777);
SQL
  GATE_PID=$!
  i=0
  until [ -f "$OUT/gate-ready" ]; do
    i=$((i + 1)); [ "$i" -lt 100 ] || { cat "$OUT/gate.log"; echo 'FAIL: la compuerta no abrio'; exit 1; }
    sleep 0.1
  done
}

# place_order <archivo> <cliente> <hora> <clave> <items_json>
place_order() {
  psql -X -At -v ON_ERROR_STOP=1 -c "SELECT pg_advisory_lock_shared(777); SELECT pg_advisory_unlock_shared(777); SELECT logistica.place_store_order('$(cust "$2")'::uuid, '$ZONE'::uuid, 'Av Carrera 123', '$DATE'::date, '$3'::time, NULL, NULL, NULL, '$5'::jsonb, '$4'::uuid)" >"$1" 2>&1 &
}

item() { printf '{"productId":"%s","quantity":%s,"unitPriceCents":1000}' "$1" "$2"; }
uuid() { psql -X -At -c "SELECT gen_random_uuid()"; }
count_matching() { cat "$@" 2>/dev/null | grep -c "$COUNT_PATTERN" || true; }

# ---------------------------------------------------------------- A) ultima unidad
gate_open
for i in 1 2 3 4 5 6 7 8; do
  place_order "$OUT/a-$i.log" "$i" '12:00' "$(uuid)" "[$(item "$(prod 1)" 1)]"
done
wait; wait "$GATE_PID" 2>/dev/null || true
COUNT_PATTERN='"status": "ok"'; ok=$(count_matching "$OUT"/a-*.log)
[ "$ok" -eq 1 ] || { cat "$OUT"/a-*.log; echo "FAIL A: $ok compras ganaron la ultima unidad (se esperaba 1)"; exit 1; }
[ "$(psql -X -At -c "SELECT stock_quantity FROM logistica.products WHERE id='$(prod 1)'")" -eq 0 ] || { echo 'FAIL A: stock distinto de 0'; exit 1; }
[ "$(psql -X -At -c "SELECT count(*) FROM logistica.order_items WHERE product_id='$(prod 1)'")" -eq 1 ] || { echo 'FAIL A: lineas distintas de 1'; exit 1; }
echo 'PASS A: ocho compras a la vez por la ultima unidad, gana una sola'

# ---------------------------------------------------------------- B) misma Idempotency-Key
KEY=$(uuid)
gate_open
for i in 1 2 3 4 5 6; do
  place_order "$OUT/b-$i.log" 11 '13:00' "$KEY" "[$(item "$(prod 2)" 3)]"
done
wait; wait "$GATE_PID" 2>/dev/null || true
COUNT_PATTERN='"status": "ok"'; ok=$(count_matching "$OUT"/b-*.log)
[ "$ok" -eq 6 ] || { cat "$OUT"/b-*.log; echo "FAIL B: $ok respuestas ok de 6 (todas deben devolver el mismo resultado)"; exit 1; }
COUNT_PATTERN='"replayed": false'; fresh=$(count_matching "$OUT"/b-*.log)
[ "$fresh" -eq 1 ] || { echo "FAIL B: $fresh ejecuciones reales (se esperaba 1)"; exit 1; }
[ "$(psql -X -At -c "SELECT count(*) FROM logistica.orders WHERE customer_user_id='$(cust 11)'")" -eq 1 ] || { echo 'FAIL B: mas de un pedido'; exit 1; }
[ "$(psql -X -At -c "SELECT stock_quantity FROM logistica.products WHERE id='$(prod 2)'")" -eq 17 ] || { echo 'FAIL B: el stock se descuento mas de una vez'; exit 1; }
echo 'PASS B: seis conexiones con la misma clave crean un solo pedido'

# ---------------------------------------------------------------- C) cupo de franja
psql -X -v ON_ERROR_STOP=1 -c "UPDATE logistica.store_settings SET slot_capacity = 3" >/dev/null
gate_open
for i in 1 2 3 4 5 6 7 8 9 10; do
  place_order "$OUT/c-$i.log" "$i" '14:00' "$(uuid)" "[$(item "$(prod 3)" 1)]"
done
wait; wait "$GATE_PID" 2>/dev/null || true
COUNT_PATTERN='"status": "ok"'; ok=$(count_matching "$OUT"/c-*.log)
[ "$ok" -eq 3 ] || { cat "$OUT"/c-*.log; echo "FAIL C: $ok pedidos entraron a una franja de cupo 3"; exit 1; }
COUNT_PATTERN='slot_full'; full=$(count_matching "$OUT"/c-*.log)
[ "$full" -eq 7 ] || { echo "FAIL C: $full rechazos por franja llena (se esperaban 7)"; exit 1; }
[ "$(psql -X -At -c "SELECT count(*) FROM logistica.orders WHERE zone_id='$ZONE' AND extract(hour FROM delivery_time)=14")" -eq 3 ] || { echo 'FAIL C: cupo sobrepasado'; exit 1; }
psql -X -v ON_ERROR_STOP=1 -c "UPDATE logistica.store_settings SET slot_capacity = 50" >/dev/null
echo 'PASS C: diez pedidos a una franja de cupo 3, entran exactamente tres'

# ---------------------------------------------------------------- D) productos en orden opuesto
gate_open
for i in 1 2 3 4 5 6 7 8 9 10; do
  if [ $((i % 2)) -eq 0 ]; then items="[$(item "$(prod 4)" 1),$(item "$(prod 5)" 1)]"; else items="[$(item "$(prod 5)" 1),$(item "$(prod 4)" 1)]"; fi
  place_order "$OUT/d-$i.log" "$i" '15:00' "$(uuid)" "$items"
done
wait; wait "$GATE_PID" 2>/dev/null || true
COUNT_PATTERN='"status": "ok"'; ok=$(count_matching "$OUT"/d-*.log)
[ "$ok" -eq 10 ] || { cat "$OUT"/d-*.log; echo "FAIL D: $ok de 10 compras con productos cruzados"; exit 1; }
COUNT_PATTERN='deadlock'; dead=$(count_matching "$OUT"/d-*.log)
[ "$dead" -eq 0 ] || { echo 'FAIL D: hubo interbloqueos'; exit 1; }
echo 'PASS D: diez compras con los mismos productos en orden opuesto, sin interbloqueos'

# ---------------------------------------------------------------- E) compras y ajustes de stock a la vez
gate_open
for i in 1 2 3 4 5 6 7 8; do
  place_order "$OUT/e-$i.log" "$i" '16:00' "$(uuid)" "[$(item "$(prod 6)" 2)]"
done
for i in 1 2 3 4; do
  psql -X -At -v ON_ERROR_STOP=1 -c "SELECT pg_advisory_lock_shared(777); SELECT pg_advisory_unlock_shared(777); SELECT logistica.adjust_stock('$(prod 6)'::uuid, 5, 'restock', '$ADMIN'::uuid)" >"$OUT/e-adj-$i.log" 2>&1 &
done
wait; wait "$GATE_PID" 2>/dev/null || true
COUNT_PATTERN='"status": "ok"'; ok=$(count_matching "$OUT"/e-[0-9].log)
[ "$ok" -eq 8 ] || { cat "$OUT"/e-*.log; echo "FAIL E: $ok de 8 compras"; exit 1; }
# 50 iniciales - 8 compras x 2 + 4 ajustes x 5 = 54
[ "$(psql -X -At -c "SELECT stock_quantity FROM logistica.products WHERE id='$(prod 6)'")" -eq 54 ] || { echo 'FAIL E: stock final distinto de 54'; exit 1; }
echo 'PASS E: compras y ajustes de stock simultaneos, el stock final es exacto'

# ---------------------------------------------------------------- Invariantes finales
bad=$(psql -X -At -c "SELECT count(*) FROM logistica.products p WHERE p.stock_quantity <> coalesce((SELECT sum(delta) FROM logistica.stock_movements m WHERE m.product_id = p.id), 0) OR p.stock_quantity < 0")
[ "$bad" -eq 0 ] || { echo "FAIL: $bad productos con el libro de stock desajustado"; exit 1; }
orphans=$(psql -X -At -c "SELECT count(*) FROM logistica.store_orders s WHERE NOT EXISTS (SELECT 1 FROM logistica.order_items i WHERE i.order_id = s.order_id)")
[ "$orphans" -eq 0 ] || { echo "FAIL: $orphans pedidos de tienda sin lineas"; exit 1; }
stuck=$(psql -X -At -c "SELECT count(*) FROM logistica.operation_requests WHERE scope LIKE 'store-order:%' AND status <> 'completada'")
[ "$stuck" -eq 0 ] || { echo "FAIL: $stuck solicitudes quedaron sin terminar"; exit 1; }
echo 'PASS: tienda, concurrencia real (ultima unidad, idempotencia, cupo, interbloqueos y libro de stock)'
