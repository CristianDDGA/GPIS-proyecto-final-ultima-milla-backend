\set ON_ERROR_STOP on
BEGIN;
SET search_path=logistica,pg_catalog;
CREATE FUNCTION pg_temp.check_true(value boolean,message text) RETURNS void LANGUAGE plpgsql AS $$
BEGIN IF value IS DISTINCT FROM true THEN RAISE EXCEPTION 'TEST_FAILED: %',message; END IF; END $$;

-- Un solo administrador (migracion 017): el segundo se rechaza; los demas roles siguen pudiendo crearse.
DO $$
DECLARE existing integer; first_admin uuid; failed boolean := false; driver uuid; customer uuid;
BEGIN
  SELECT count(*) INTO existing FROM app_users WHERE role = 'personal';
  IF existing = 0 THEN
    first_admin := register_app_user('admin-unico', 'admin.unico@test.local', 'scrypt$x$y', 'personal', 'Admin');
    PERFORM pg_temp.check_true(first_admin IS NOT NULL, 'el primer administrador se crea');
  END IF;

  BEGIN
    PERFORM register_app_user('admin-dos', 'admin.dos@test.local', 'scrypt$x$y', 'personal', 'Otro');
  EXCEPTION WHEN unique_violation THEN
    failed := SQLERRM = 'ADMIN_ALREADY_EXISTS';
  END;
  PERFORM pg_temp.check_true(failed, 'el segundo administrador se rechaza con ADMIN_ALREADY_EXISTS');
  PERFORM pg_temp.check_true(NOT EXISTS (SELECT 1 FROM app_users WHERE email = 'admin.dos@test.local'), 'el rechazo no deja filas');

  failed := false;
  BEGIN
    PERFORM register_trusted_app_user('admin-tres', 'admin.tres@test.local', 'scrypt$x$y', 'personal', 'Otro', 'admin');
  EXCEPTION WHEN unique_violation THEN
    failed := SQLERRM = 'ADMIN_ALREADY_EXISTS';
  END;
  PERFORM pg_temp.check_true(failed, 'tambien se rechaza por la via de cuentas verificadas');

  driver := register_trusted_app_user('conductor-ok', 'conductor.ok@test.local', 'scrypt$x$y', 'repartidor', 'Conductor', 'admin');
  customer := register_app_user('cliente-ok', 'cliente.ok@test.local', 'scrypt$x$y', 'cliente', 'Cliente');
  PERFORM pg_temp.check_true(driver IS NOT NULL AND customer IS NOT NULL, 'repartidores y clientes se crean con normalidad');
END $$;
ROLLBACK;
SELECT 'PASS: un solo administrador (segundo rechazado, otros roles intactos)' AS resultado;
