\set ON_ERROR_STOP on
BEGIN;
SET search_path=logistica,pg_catalog;
CREATE FUNCTION pg_temp.check_true(value boolean,message text) RETURNS void LANGUAGE plpgsql AS $$
BEGIN IF value IS DISTINCT FROM true THEN RAISE EXCEPTION 'TEST_FAILED: %',message; END IF; END $$;
CREATE FUNCTION pg_temp.expect_error(command text,expected_state text) RETURNS void LANGUAGE plpgsql AS $$
BEGIN
  BEGIN EXECUTE command;
  EXCEPTION WHEN OTHERS THEN
    IF SQLSTATE=expected_state THEN RETURN; END IF;
    RAISE EXCEPTION 'TEST_FAILED: esperado %, recibido %: %',expected_state,SQLSTATE,SQLERRM;
  END;
  RAISE EXCEPTION 'TEST_FAILED: se esperaba rechazo de %',command;
END $$;
CREATE FUNCTION pg_temp.item(product uuid,quantity integer,price integer) RETURNS jsonb LANGUAGE sql AS $$
  SELECT jsonb_build_array(jsonb_build_object('productId',product,'quantity',quantity,'unitPriceCents',price)) $$;
CREATE FUNCTION pg_temp.ver(o uuid) RETURNS bigint LANGUAGE sql AS $$ SELECT version FROM orders WHERE id=o $$;
CREATE FUNCTION pg_temp.st(o uuid) RETURNS text LANGUAGE sql AS $$ SELECT status FROM orders WHERE id=o $$;

CREATE FUNCTION pg_temp.cycle(o uuid, zone uuid, courier uuid, drv uuid) RETURNS void LANGUAGE plpgsql AS $$
DECLARE r uuid; day date;
BEGIN
  SELECT delivery_date INTO day FROM orders WHERE id = o;
  r := create_route(zone, day, 3);
  PERFORM add_order_to_route(r, o);
  PERFORM assign_route(r, courier);
  PERFORM change_order_status(o, 'recogido', (SELECT version FROM orders WHERE id = o), drv);
  PERFORM change_order_status(o, 'en_camino', (SELECT version FROM orders WHERE id = o), drv);
  PERFORM fail_delivery(o, (SELECT version FROM orders WHERE id = o), drv, 'otro', NULL, gen_random_uuid());
  PERFORM complete_route(r);
END $$;

DO $$
DECLARE
  adm uuid; cust uuid; cust2 uuid; drv uuid; drv2 uuid; courier uuid; courier2 uuid; z uuid; cat uuid; p1 uuid; p2 uuid;
  d date := CURRENT_DATE + 3; res jsonb; res2 jsonb; o1 uuid; o2 uuid; o3 uuid; o4 uuid; leg uuid; route uuid; route2 uuid; v bigint;
  k uuid; a1 uuid; a2 uuid; n integer; ids uuid[] := '{}'; i integer; ov bigint;
BEGIN
  INSERT INTO app_users(auth_subject,role,email,email_verified_at,email_verified_via) VALUES ('f-admin','personal','admin@test.local',now(),'admin') RETURNING id INTO adm;
  INSERT INTO app_users(auth_subject,role,email,email_verified_at,email_verified_via) VALUES ('f-cust','cliente','cliente@test.local',now(),'code') RETURNING id INTO cust;
  INSERT INTO app_users(auth_subject,role) VALUES ('f-cust2','cliente') RETURNING id INTO cust2;
  INSERT INTO app_users(auth_subject,role) VALUES ('f-drv','repartidor') RETURNING id INTO drv;
  INSERT INTO app_users(auth_subject,role) VALUES ('f-drv2','repartidor') RETURNING id INTO drv2;
  z := create_zone('Zona flujos');
  courier := create_courier('Conductor Uno', 5, drv); PERFORM set_courier_availability(courier, true);
  courier2 := create_courier('Conductor Dos', 5, drv2); PERFORM set_courier_availability(courier2, true);
  cat := create_category('Flujos', adm);
  p1 := create_product('FLU-1', 'Producto uno', NULL, NULL, cat, 1000, NULL, 20, NULL, true, adm);
  p2 := create_product('FLU-2', 'Producto dos', NULL, NULL, cat, 2500, NULL, 20, NULL, true, adm);

  -- ===================== Estados y compatibilidad
  PERFORM pg_temp.expect_error(format('INSERT INTO orders(zone_id,delivery_address,delivery_date,delivery_time,status) VALUES (%L,%L,CURRENT_DATE+1,%L,%L)', z, 'Dir', '10:00', 'otro'),'23514');

  -- ===================== Cancelar un pedido pendiente (cliente dueno)
  res := place_store_order(cust, z, 'Calle 10 y Av 5', d, time '10:00', NULL, NULL, NULL, pg_temp.item(p1, 3, 1000), gen_random_uuid());
  o1 := (res ->> 'orderId')::uuid;
  PERFORM pg_temp.check_true((SELECT stock_quantity FROM products WHERE id=p1)=17,'stock descontado');
  PERFORM pg_temp.check_true((SELECT count(*) FROM notifications WHERE order_id=o1 AND kind='order_confirmed' AND state='pendiente')=1,'aviso de confirmacion en cola');
  PERFORM pg_temp.expect_error(format('SELECT cancel_order(%L,%L,%L,NULL)', o1, cust2, 'cliente_desiste'), 'LG404');
  PERFORM pg_temp.expect_error(format('SELECT cancel_order(%L,%L,%L,NULL)', o1, cust, 'motivo_raro'), '22023');
  PERFORM pg_temp.expect_error(format('SELECT cancel_order(%L,%L,%L,NULL)', o1, drv, 'otro'), '42501');
  PERFORM pg_temp.expect_error(format('SELECT cancel_order(%L,%L,%L,%L)', o1, cust, 'otro', 'Nota con ' || E'\U0001F600'), '23514');
  PERFORM pg_temp.check_true(pg_temp.st(o1)='pendiente','los rechazos no cambian el estado');
  res := cancel_order(o1, cust, 'cliente_desiste', 'Ya no lo necesito');
  PERFORM pg_temp.check_true(res ->> 'status'='cancelado' AND (res ->> 'restocked')::boolean AND NOT (res ->> 'alreadyCancelled')::boolean,'cancelado y repuesto');
  PERFORM pg_temp.check_true(pg_temp.st(o1)='cancelado' AND (SELECT stock_quantity FROM products WHERE id=p1)=20,'stock devuelto');
  PERFORM pg_temp.check_true((SELECT delta=3 AND reason='cancel' FROM stock_movements WHERE order_id=o1 AND product_id=p1 AND reason='cancel'),'movimiento de devolucion');
  PERFORM pg_temp.check_true((SELECT count(*) FROM notifications WHERE order_id=o1 AND kind='order_cancelled')=1,'aviso de cancelacion en cola');
  res2 := cancel_order(o1, adm, 'otro', NULL);
  PERFORM pg_temp.check_true((res2 ->> 'alreadyCancelled')::boolean AND (SELECT stock_quantity FROM products WHERE id=p1)=20,'cancelar dos veces no repone dos veces');
  PERFORM pg_temp.expect_error(format('UPDATE orders SET status=%L WHERE id=%L','pendiente',o1),'23514');  -- cancelado es final
  -- Una cancelacion libera la franja
  PERFORM set_store_settings(1, 8, 20, 60, adm);
  res := place_store_order(cust, z, 'Calle 10 y Av 5', d, time '11:00', NULL, NULL, NULL, pg_temp.item(p1, 1, 1000), gen_random_uuid());
  o2 := (res ->> 'orderId')::uuid;
  res := place_store_order(cust2, z, 'Calle 10 y Av 5', d, time '11:00', NULL, NULL, NULL, pg_temp.item(p1, 1, 1000), gen_random_uuid());
  PERFORM pg_temp.check_true(res -> 'conflicts' -> 0 ->> 'reason'='slot_full','franja llena antes de cancelar');
  PERFORM pg_temp.check_true((SELECT reserved=1 AND NOT available FROM delivery_slots(z,d) WHERE slot_time=time '11:00'),'franja ocupada');
  PERFORM cancel_order(o2, adm, 'sin_stock', NULL);
  PERFORM pg_temp.check_true((SELECT reserved=0 AND available FROM delivery_slots(z,d) WHERE slot_time=time '11:00'),'la cancelacion libera la franja');
  res := place_store_order(cust2, z, 'Calle 10 y Av 5', d, time '11:00', NULL, NULL, NULL, pg_temp.item(p1, 1, 1000), gen_random_uuid());
  PERFORM pg_temp.check_true(res ->> 'status'='ok','otro cliente toma la franja liberada');
  o3 := (res ->> 'orderId')::uuid;
  PERFORM set_store_settings(10, 8, 20, 60, adm);

  -- ===================== Cancelar un pedido ya asignado a una ruta
  route := create_route(z, d, 3);
  PERFORM add_order_to_route(route, o3);
  PERFORM pg_temp.check_true(pg_temp.st(o3)='asignado_a_ruta','asignado');
  PERFORM cancel_order(o3, cust2, 'error_en_pedido', NULL);
  PERFORM pg_temp.check_true(pg_temp.st(o3)='cancelado' AND NOT EXISTS (SELECT 1 FROM route_stops WHERE order_id=o3 AND released_at IS NULL),'cancelado y parada liberada');
  PERFORM pg_temp.check_true((SELECT release_reason FROM route_stops WHERE order_id=o3)='pedido_cancelado','motivo de liberacion');
  PERFORM pg_temp.check_true((SELECT status FROM routes WHERE id=route)='planificada','la ruta planificada sigue');
  -- Una ruta asignada que se queda sin paradas se cancela sola
  res := place_store_order(cust, z, 'Calle 10 y Av 5', d, time '12:00', NULL, NULL, NULL, pg_temp.item(p1, 1, 1000), gen_random_uuid());
  o4 := (res ->> 'orderId')::uuid;
  route2 := create_route(z, d, 3);
  PERFORM add_order_to_route(route2, o4);
  PERFORM assign_route(route2, courier);
  PERFORM cancel_order(o4, adm, 'otro', NULL);
  PERFORM pg_temp.check_true((SELECT status FROM routes WHERE id=route2)='cancelada','ruta vacia cancelada');
  PERFORM pg_temp.check_true(pg_temp.st(o4)='cancelado','pedido cancelado');

  -- ===================== Ciclo completo: recoger, salir, fallar, cerrar ruta y reprogramar
  res := place_store_order(cust, z, 'Calle 10 y Av 5', d, time '10:00', 'Maria Perez', '0991234567', NULL, pg_temp.item(p2, 2, 2500), gen_random_uuid());
  o1 := (res ->> 'orderId')::uuid;
  route := create_route(z, d, 3);
  PERFORM add_order_to_route(route, o1);
  PERFORM assign_route(route, courier);
  PERFORM change_order_status(o1, 'recogido', pg_temp.ver(o1), drv);
  PERFORM pg_temp.expect_error(format('SELECT cancel_order(%L,%L,%L,NULL)', o1, cust, 'otro'), '23514');   -- recogido: ya no se cancela
  PERFORM pg_temp.expect_error(format('SELECT fail_delivery(%L,%s,%L,%L,NULL,%L)', o1, pg_temp.ver(o1), drv, 'cliente_ausente', gen_random_uuid()), '23514'); -- no esta en camino
  PERFORM change_order_status(o1, 'en_camino', pg_temp.ver(o1), drv);
  -- cobro obligatorio en pedidos de tienda
  PERFORM pg_temp.expect_error(format('SELECT change_order_status(%L,%L,%s,%L)', o1, 'entregado', pg_temp.ver(o1), drv), '23514');
  k := gen_random_uuid();
  PERFORM pg_temp.expect_error(format('SELECT fail_delivery(%L,%s,%L,%L,NULL,%L)', o1, pg_temp.ver(o1), drv2, 'cliente_ausente', gen_random_uuid()), '42501');
  PERFORM pg_temp.expect_error(format('SELECT fail_delivery(%L,%s,%L,%L,NULL,%L)', o1, pg_temp.ver(o1), cust, 'cliente_ausente', gen_random_uuid()), '42501');
  PERFORM pg_temp.expect_error(format('SELECT fail_delivery(%L,%s,%L,%L,NULL,%L)', o1, pg_temp.ver(o1), drv, 'porque_si', gen_random_uuid()), '22023');
  PERFORM pg_temp.expect_error(format('SELECT fail_delivery(%L,%s,%L,%L,NULL,%L)', o1, pg_temp.ver(o1) + 5, drv, 'cliente_ausente', gen_random_uuid()), '40001');
  res := fail_delivery(o1, pg_temp.ver(o1), drv, 'cliente_ausente', 'Nadie abrio', k);
  PERFORM pg_temp.check_true(res ->> 'status'='entrega_fallida' AND (res ->> 'attempt')::int=1 AND pg_temp.st(o1)='entrega_fallida','entrega fallida registrada');
  ov := pg_temp.ver(o1);
  res2 := fail_delivery(o1, ov - 1, drv, 'cliente_ausente', 'Nadie abrio', k);
  PERFORM pg_temp.check_true((res2 ->> 'replayed')::boolean AND pg_temp.ver(o1)=ov,'reintento idempotente de la falla');
  PERFORM pg_temp.check_true((SELECT count(*) FROM notifications WHERE order_id=o1 AND kind='order_status' AND status_to='entrega_fallida')=1,'aviso de entrega fallida');
  PERFORM pg_temp.expect_error(format('SELECT reschedule_order(%L,%L,%L,%L)', o1, d + 1, '12:00', cust), '23514'); -- la parada sigue en la ruta
  PERFORM pg_temp.expect_error(format('SELECT cancel_order(%L,%L,%L,NULL)', o1, cust, 'otro'), '23514');            -- ruta abierta: aun no
  PERFORM complete_route(route);
  PERFORM pg_temp.check_true(pg_temp.st(o1)='entrega_fallida' AND NOT EXISTS (SELECT 1 FROM route_stops WHERE order_id=o1 AND released_at IS NULL),'ruta cerrada con la parada fallida liberada');
  -- Reprogramar
  PERFORM pg_temp.expect_error(format('SELECT reschedule_order(%L,%L,%L,%L)', o1, d + 1, '12:00', cust2), 'LG404');
  PERFORM pg_temp.expect_error(format('SELECT reschedule_order(%L,%L,%L,%L)', o1, CURRENT_DATE - 1, '12:00', cust), '22007');
  PERFORM pg_temp.expect_error(format('SELECT reschedule_order(%L,%L,%L,%L)', o1, d + 1, '12:00:30', cust), '22023');
  PERFORM pg_temp.expect_error(format('SELECT reschedule_order(%L,%L,%L,%L)', o1, d + 1, '12:00', drv), '42501');
  res := reschedule_order(o1, d + 1, time '12:30', cust);
  PERFORM pg_temp.check_true(res ->> 'status'='conflict' AND res ->> 'reason'='slot_invalid' AND pg_temp.st(o1)='entrega_fallida','franja invalida al reprogramar');
  res := reschedule_order(o1, d + 1, time '12:00', cust);
  PERFORM pg_temp.check_true(res ->> 'status'='ok' AND pg_temp.st(o1)='pendiente' AND (SELECT delivery_date=d+1 AND delivery_time=time '12:00' FROM orders WHERE id=o1),'reprogramado a pendiente con fecha nueva');
  PERFORM pg_temp.check_true((SELECT count(*) FROM notifications WHERE order_id=o1 AND kind='order_rescheduled')=1,'aviso de reprogramacion');
  PERFORM pg_temp.expect_error(format('SELECT reschedule_order(%L,%L,%L,%L)', o1, d + 2, '12:00', cust), '23514');
  -- Intentos 2 y 3, luego solo queda cancelar
  PERFORM pg_temp.cycle(o1, z, courier, drv);
  PERFORM pg_temp.check_true((SELECT count(*) FROM delivery_failures WHERE order_id=o1)=2,'segundo intento fallido');
  PERFORM reschedule_order(o1, d + 2, time '12:00', adm);
  PERFORM pg_temp.cycle(o1, z, courier, drv);
  PERFORM pg_temp.check_true((SELECT count(*) FROM delivery_failures WHERE order_id=o1)=3,'tercer intento fallido');
  PERFORM pg_temp.expect_error(format('SELECT reschedule_order(%L,%L,%L,%L)', o1, d + 3, '12:00', adm), '23514');
  PERFORM pg_temp.check_true((SELECT stock_quantity FROM products WHERE id=p2)=18,'el stock sigue descontado mientras el pedido vive');
  res := cancel_order(o1, cust, 'no_localizable', 'Tres intentos fallidos');
  PERFORM pg_temp.check_true(pg_temp.st(o1)='cancelado' AND (SELECT stock_quantity FROM products WHERE id=p2)=20,'cancelado tras fallos y stock devuelto');

  -- ===================== Entrega con cobro
  res := place_store_order(cust, z, 'Calle 10 y Av 5', d, time '14:00', NULL, NULL, NULL, pg_temp.item(p1, 2, 1000), gen_random_uuid());
  o2 := (res ->> 'orderId')::uuid;
  leg := create_order(z, 'Direccion de un pedido normal', d, time '15:00');
  route := create_route(z, d, 4);
  PERFORM add_order_to_route(route, o2); PERFORM add_order_to_route(route, leg);
  PERFORM assign_route(route, courier);
  PERFORM change_order_status(o2, 'recogido', pg_temp.ver(o2), drv); PERFORM change_order_status(leg, 'recogido', pg_temp.ver(leg), drv);
  PERFORM change_order_status(o2, 'en_camino', pg_temp.ver(o2), drv); PERFORM change_order_status(leg, 'en_camino', pg_temp.ver(leg), drv);
  PERFORM pg_temp.expect_error(format('SELECT change_order_status(%L,%L,%s,%L)', o2, 'entregado', pg_temp.ver(o2), drv), '23514');
  k := gen_random_uuid();
  PERFORM pg_temp.expect_error(format('SELECT deliver_store_order(%L,%s,%L,1999,%L)', o2, pg_temp.ver(o2), drv, k), 'LG422');
  PERFORM pg_temp.expect_error(format('SELECT deliver_store_order(%L,%s,%L,2001,%L)', o2, pg_temp.ver(o2), drv, k), 'LG422');
  PERFORM pg_temp.expect_error(format('SELECT deliver_store_order(%L,%s,%L,0,%L)', o2, pg_temp.ver(o2), drv, k), '22023');
  PERFORM pg_temp.expect_error(format('SELECT deliver_store_order(%L,%s,%L,2000,%L)', o2, pg_temp.ver(o2), drv2, k), '42501');
  PERFORM pg_temp.expect_error(format('SELECT deliver_store_order(%L,%s,%L,2000,%L)', o2, pg_temp.ver(o2), cust, k), '42501');
  PERFORM pg_temp.expect_error(format('SELECT deliver_store_order(%L,%s,%L,2000,%L)', leg, pg_temp.ver(leg), drv, gen_random_uuid()), '23514');
  PERFORM pg_temp.expect_error(format('SELECT deliver_store_order(%L,%s,%L,2000,%L)', o2, pg_temp.ver(o2) + 3, drv, gen_random_uuid()), '40001');
  PERFORM pg_temp.check_true(NOT EXISTS (SELECT 1 FROM order_collections WHERE order_id=o2) AND pg_temp.st(o2)='en_camino','los rechazos no dejan cobro ni cambian el estado');
  res := deliver_store_order(o2, pg_temp.ver(o2), drv, 2000, k);
  PERFORM pg_temp.check_true(res ->> 'status'='entregado' AND (res ->> 'collectedCents')::bigint=2000 AND pg_temp.st(o2)='entregado','entregado con cobro');
  ov := pg_temp.ver(o2);
  res2 := deliver_store_order(o2, ov - 1, drv, 2000, k);
  PERFORM pg_temp.check_true((res2 ->> 'replayed')::boolean AND pg_temp.ver(o2)=ov AND (SELECT count(*) FROM order_collections WHERE order_id=o2)=1,'reintento idempotente del cobro');
  PERFORM change_order_status(leg, 'entregado', pg_temp.ver(leg), drv);
  PERFORM pg_temp.check_true(pg_temp.st(leg)='entregado','el pedido normal se entrega como siempre');
  PERFORM pg_temp.expect_error(format('SELECT cancel_order(%L,%L,%L,NULL)', o2, adm, 'otro'), '23514');
  PERFORM complete_route(route);

  -- ===================== Rendicion de caja
  PERFORM pg_temp.expect_error(format('SELECT settle_cash(%L,%L,2000,NULL,%L)', drv, (clock_timestamp() AT TIME ZONE 'America/Guayaquil')::date, cust), '42501');
  PERFORM pg_temp.expect_error(format('SELECT settle_cash(%L,%L,2000,NULL,%L)', drv2, (clock_timestamp() AT TIME ZONE 'America/Guayaquil')::date, adm), '22023');
  PERFORM pg_temp.expect_error(format('SELECT settle_cash(%L,%L,2000,NULL,%L)', cust, (clock_timestamp() AT TIME ZONE 'America/Guayaquil')::date, adm), 'LG404');
  PERFORM pg_temp.expect_error(format('SELECT settle_cash(%L,%L,-1,NULL,%L)', drv, (clock_timestamp() AT TIME ZONE 'America/Guayaquil')::date, adm), '22023');
  res := settle_cash(drv, (clock_timestamp() AT TIME ZONE 'America/Guayaquil')::date, 1500, 'Faltaron 5 dolares', adm);
  PERFORM pg_temp.check_true((res ->> 'expectedCents')::bigint=2000 AND (res ->> 'differenceCents')::bigint=-500,'rendicion con diferencia');
  PERFORM pg_temp.expect_error(format('SELECT settle_cash(%L,%L,2000,NULL,%L)', drv, (clock_timestamp() AT TIME ZONE 'America/Guayaquil')::date, adm), '23505');

  -- ===================== Libreta de direcciones
  a1 := create_address(cust, 'Casa', z, 'Av. 9 de Octubre 123', 'Maria Perez', '0991234567', false);
  PERFORM pg_temp.check_true((SELECT is_default FROM customer_addresses WHERE id=a1),'la primera direccion es la predeterminada');
  a2 := create_address(cust, 'Trabajo', z, 'Calle Larga 45', NULL, NULL, true);
  PERFORM pg_temp.check_true((SELECT count(*) FROM customer_addresses WHERE user_id=cust AND is_default)=1 AND (SELECT is_default FROM customer_addresses WHERE id=a2),'una sola predeterminada');
  PERFORM pg_temp.expect_error(format('SELECT create_address(%L,%L,%L,%L,NULL,NULL,false)', cust, 'CASA', z, 'Otra direccion 99'), '23505');
  PERFORM pg_temp.expect_error(format('SELECT create_address(%L,%L,%L,%L,NULL,NULL,false)', cust, 'Casa ' || E'\U0001F3E0', z, 'Otra direccion 99'), '23514');
  PERFORM pg_temp.expect_error(format('SELECT create_address(%L,%L,%L,%L,NULL,%L,false)', cust, 'Otra', z, 'Otra direccion 99', 'abc'), '23514');
  PERFORM pg_temp.expect_error(format('SELECT create_address(%L,%L,%L,%L,NULL,NULL,false)', cust, 'Otra', gen_random_uuid(), 'Otra direccion 99'), '23503');
  PERFORM pg_temp.expect_error(format('SELECT create_address(%L,%L,%L,%L,NULL,NULL,false)', adm, 'Otra', z, 'Otra direccion 99'), '42501');
  PERFORM pg_temp.expect_error(format('SELECT update_address(%L,%L,%L,1)', a1, cust2, '{"label":"Hackeada"}'), 'LG404');
  PERFORM pg_temp.expect_error(format('SELECT update_address(%L,%L,%L,9)', a1, cust, '{"label":"Casa nueva"}'), 'LG409');
  SELECT version INTO v FROM customer_addresses WHERE id=a1;
  PERFORM pg_temp.expect_error(format('SELECT update_address(%L,%L,%L,%s)', a1, cust, '{"zoneId":"00000000-0000-4000-8000-000000000000"}', v), '23503');
  PERFORM pg_temp.expect_error(format('SELECT update_address(%L,%L,%L,1)', a1, cust, '{"otro":1}'), '22023');
  SELECT version INTO v FROM customer_addresses WHERE id=a1;
  ov := update_address(a1, cust, '{"label":"Casa nueva","isDefault":true}', v);
  PERFORM pg_temp.check_true(ov > v AND (SELECT is_default FROM customer_addresses WHERE id=a1) AND NOT (SELECT is_default FROM customer_addresses WHERE id=a2),'editar y volver predeterminada');
  SELECT version INTO v FROM customer_addresses WHERE id=a1;
  PERFORM pg_temp.expect_error(format('SELECT update_address(%L,%L,%L,%s)', a1, cust, '{"isDefault":false}', v), '22023');
  PERFORM pg_temp.expect_error(format('SELECT delete_address(%L,%L)', a1, cust2), 'LG404');
  PERFORM delete_address(a1, cust);
  PERFORM pg_temp.check_true((SELECT is_default FROM customer_addresses WHERE id=a2),'al borrar la predeterminada otra la reemplaza');
  FOR i IN 1..9 LOOP PERFORM create_address(cust, 'Direccion ' || i, z, 'Calle numero ' || i || ' y Av. Principal', NULL, NULL, false); END LOOP;
  PERFORM pg_temp.expect_error(format('SELECT create_address(%L,%L,%L,%L,NULL,NULL,false)', cust, 'Una mas', z, 'Calle once y Av. Principal'), 'LG413');

  -- ===================== Cola de correos
  SELECT count(*) INTO n FROM notifications WHERE state='pendiente';
  PERFORM pg_temp.check_true(n >= 6,'hay avisos pendientes');
  SELECT count(*) INTO n FROM claim_notifications(100);
  PERFORM pg_temp.check_true(n = (SELECT count(*) FROM notifications WHERE locked_until IS NOT NULL),'se reclaman todos los pendientes');
  PERFORM pg_temp.check_true((SELECT count(*) FROM claim_notifications(100))=0,'un aviso reclamado no se entrega dos veces');
  PERFORM pg_temp.check_true(EXISTS (SELECT 1 FROM notifications n JOIN app_users u ON u.id=n.user_id WHERE u.email='cliente@test.local' AND n.attempts=1),'el aviso del cliente con correo quedo reclamado');
  SELECT id INTO k FROM notifications WHERE state='pendiente' ORDER BY id LIMIT 1;
  PERFORM finish_notification(k, 'sent');
  PERFORM pg_temp.check_true((SELECT state='enviada' AND sent_at IS NOT NULL FROM notifications WHERE id=k),'marcar enviado');
  SELECT id INTO k FROM notifications WHERE state='pendiente' ORDER BY id LIMIT 1;
  PERFORM finish_notification(k, 'skipped');
  PERFORM pg_temp.check_true((SELECT state='omitida' FROM notifications WHERE id=k),'marcar omitido');
  SELECT id INTO k FROM notifications WHERE state='pendiente' ORDER BY id LIMIT 1;
  PERFORM finish_notification(k, 'retry');
  PERFORM pg_temp.check_true((SELECT state='pendiente' AND locked_until IS NULL AND next_attempt_at > clock_timestamp() FROM notifications WHERE id=k),'un fallo reprograma el reintento');
  UPDATE notifications SET attempts = 5 WHERE id=k;
  PERFORM finish_notification(k, 'retry');
  PERFORM pg_temp.check_true((SELECT state='fallida' FROM notifications WHERE id=k),'tras 5 intentos se rinde');
  PERFORM pg_temp.expect_error(format('SELECT finish_notification(%L,%L)', k, 'otro'), '22023');
  PERFORM pg_temp.check_true((SELECT count(*) FROM notifications n WHERE n.kind='order_status' AND n.status_to='entregado')=1,'aviso de entregado');

  -- ===================== Historial inmutable
  PERFORM pg_temp.expect_error('UPDATE order_collections SET amount_cents = 1', '23514');
  PERFORM pg_temp.expect_error('DELETE FROM order_cancellations', '23514');
  PERFORM pg_temp.expect_error('DELETE FROM delivery_failures', '23514');
  PERFORM pg_temp.expect_error('UPDATE cash_settlements SET received_cents = 1', '23514');
  PERFORM pg_temp.check_true((SELECT count(*) FROM products p WHERE p.stock_quantity <> coalesce((SELECT sum(delta) FROM stock_movements m WHERE m.product_id=p.id),0))=0,'el libro de stock cuadra');
END $$;

-- Privilegios: la API solo lee tablas nuevas y ejecuta funciones
SET LOCAL ROLE logistica_app;
SELECT pg_temp.expect_error('INSERT INTO logistica.notifications(user_id,order_id,order_version,kind) VALUES (gen_random_uuid(),gen_random_uuid(),1,''order_confirmed'')','42501');
SELECT pg_temp.expect_error('UPDATE logistica.customer_addresses SET label = ''x''','42501');
SELECT pg_temp.expect_error('INSERT INTO logistica.order_collections(order_id,amount_cents,courier_user_id) VALUES (gen_random_uuid(),1,gen_random_uuid())','42501');
SELECT pg_temp.expect_error('SELECT logistica.check_slot(gen_random_uuid(),CURRENT_DATE,''10:00'',NULL)','42501');
SELECT pg_temp.check_true((SELECT count(*) FROM logistica.order_collections) >= 1,'logistica_app lee los cobros');
RESET ROLE;
SET CONSTRAINTS ALL IMMEDIATE;
ROLLBACK;
SELECT 'PASS: flujos (cancelar, entrega fallida, reprogramar, cobro, caja, direcciones, correos, historial y privilegios)' AS resultado;
