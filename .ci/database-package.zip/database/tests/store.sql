\set ON_ERROR_STOP on
BEGIN;
SET search_path=logistica,pg_catalog;
CREATE FUNCTION pg_temp.check_true(value boolean,message text) RETURNS void LANGUAGE plpgsql AS $$
BEGIN IF value IS DISTINCT FROM true THEN RAISE EXCEPTION 'TEST_FAILED: %',message; END IF; END $$;
CREATE FUNCTION pg_temp.expect_error(command text,expected_state text) RETURNS void LANGUAGE plpgsql AS $$
BEGIN
  BEGIN EXECUTE command;
  EXCEPTION WHEN OTHERS THEN
    IF SQLSTATE=expected_state THEN RETURN; END IF;
    RAISE EXCEPTION 'TEST_FAILED: esperado %, recibido %: %',expected_state,SQLSTATE,SQLERRM;
  END;
  RAISE EXCEPTION 'TEST_FAILED: se esperaba rechazo de %',command;
END $$;
CREATE FUNCTION pg_temp.item(product uuid,quantity integer,price integer) RETURNS jsonb LANGUAGE sql AS $$
  SELECT jsonb_build_object('productId',product,'quantity',quantity,'unitPriceCents',price) $$;

DO $$
DECLARE
  adm uuid; cust uuid; cust2 uuid; z uuid; cat uuid; p1 uuid; p2 uuid; p3 uuid; v bigint; res jsonb; res2 jsonb;
  k uuid := gen_random_uuid(); d date := CURRENT_DATE + 3; o uuid; n integer;
BEGIN
  INSERT INTO app_users(auth_subject,role) VALUES ('store-admin','personal') RETURNING id INTO adm;
  INSERT INTO app_users(auth_subject,role) VALUES ('store-cust','cliente') RETURNING id INTO cust;
  INSERT INTO app_users(auth_subject,role) VALUES ('store-cust2','cliente') RETURNING id INTO cust2;
  z := create_zone('Zona tienda');

  -- Texto: acepta letras, tildes, numeros y puntuacion basica; rechaza emojis, keycaps, ZWJ y controles.
  PERFORM pg_temp.check_true(is_clean_store_text('Cámara 4K (2024) - Edición ñandú #1'),'texto limpio con tildes y numeros');
  PERFORM pg_temp.check_true(NOT is_clean_store_text('Bici ' || E'\U0001F6B2'),'rechaza emoji');
  PERFORM pg_temp.check_true(NOT is_clean_store_text('Set 1' || E'️⃣'),'rechaza keycap');
  PERFORM pg_temp.check_true(NOT is_clean_store_text('Hogar' || E'‍' || 'casa'),'rechaza ZWJ');
  PERFORM pg_temp.check_true(NOT is_clean_store_text('Zona' || E'‮' || 'abc'),'rechaza inversion de direccion');
  PERFORM pg_temp.check_true(NOT is_clean_store_text('Audifonos ' || E'™'),'rechaza simbolo de marca');
  PERFORM pg_temp.check_true(NOT is_clean_store_text(E'Linea\nDos'),'una linea no admite salto');
  PERFORM pg_temp.check_true(is_clean_store_multiline(E'Linea\nDos'),'la descripcion admite salto');
  PERFORM pg_temp.check_true(store_search_text('Audífonos Ñandú') = 'audifonos nandu','busqueda sin tildes');

  -- Categorias
  PERFORM pg_temp.expect_error(format('SELECT create_category(%L,%L)', 'Bebe ' || E'\U0001F37C', adm), '23514');
  PERFORM pg_temp.expect_error(format('SELECT create_category(%L,%L)', 'Tecnologia 1' || E'️⃣', adm), '23514');
  PERFORM pg_temp.expect_error(format('SELECT create_category(%L,%L)', 'Hogar', cust), '42501');
  PERFORM pg_temp.expect_error(format('SELECT create_category(%L,%L)', 'X', adm), '23514');
  cat := create_category('Deportes y fitness', adm);
  PERFORM pg_temp.expect_error(format('SELECT create_category(%L,%L)', 'DEPORTES Y FITNESS', adm), '23505');
  SELECT version INTO v FROM categories WHERE id = cat;
  PERFORM pg_temp.check_true(update_category(cat, 'Deportes', NULL, v, adm) = v + 1, 'categoria sube de version');
  PERFORM pg_temp.expect_error(format('SELECT update_category(%L,%L,NULL,%s,%L)', cat, 'Otro', v, adm), 'LG409');
  PERFORM pg_temp.expect_error(format('SELECT update_category(%L,%L,NULL,1,%L)', gen_random_uuid(), 'Otro', adm), 'LG404');

  -- Productos
  p1 := create_product('AUD-100', 'Audifonos inalambricos serie 100', 'SoundMax', 'Cancelacion de ruido', cat, 6999, 8999, 10, NULL, true, adm);
  p2 := create_product('BAND-5', 'Bandas de resistencia set 5 niveles', 'FitFlex', NULL, cat, 1549, NULL, 1, NULL, true, adm);
  p3 := create_product('BASC-1', 'Bascula digital de bano', NULL, NULL, cat, 2249, NULL, 5, NULL, true, adm);
  PERFORM pg_temp.check_true((SELECT count(*) FROM product_events WHERE action = 'created') = 3, 'evento de creacion por producto');
  PERFORM pg_temp.expect_error(format('SELECT create_product(%L,%L,NULL,NULL,%L,100,NULL,1,NULL,true,%L)', 'aud-100', 'Nombre valido', cat, adm), '23514');
  PERFORM pg_temp.expect_error(format('SELECT create_product(%L,%L,NULL,NULL,%L,100,NULL,1,NULL,true,%L)', 'AUD-100', 'Nombre valido', cat, adm), '23505');
  PERFORM pg_temp.expect_error(format('SELECT create_product(%L,%L,NULL,NULL,%L,0,NULL,1,NULL,true,%L)', 'NEW-1', 'Nombre valido', cat, adm), '23514');
  PERFORM pg_temp.expect_error(format('SELECT create_product(%L,%L,NULL,NULL,%L,500,500,1,NULL,true,%L)', 'NEW-2', 'Nombre valido', cat, adm), '23514');
  PERFORM pg_temp.expect_error(format('SELECT create_product(%L,%L,NULL,NULL,%L,500,NULL,-1,NULL,true,%L)', 'NEW-3', 'Nombre valido', cat, adm), '22023');
  PERFORM pg_temp.expect_error(format('SELECT create_product(%L,%L,NULL,NULL,%L,500,NULL,1,%L,true,%L)', 'NEW-4', 'Nombre valido', cat, 'ruta/../x.jpg', adm), '23514');
  PERFORM pg_temp.expect_error(format('SELECT create_product(%L,%L,NULL,NULL,%L,500,NULL,1,NULL,true,%L)', 'NEW-5', 'Set 1' || E'️⃣' || ' piezas', cat, adm), '23514');
  PERFORM pg_temp.expect_error(format('SELECT create_product(%L,%L,NULL,NULL,%L,500,NULL,1,NULL,true,%L)', 'NEW-6', 'Mesa ' || E'\U0001FA91', cat, adm), '23514');
  PERFORM pg_temp.expect_error(format('SELECT create_product(%L,%L,NULL,NULL,%L,500,NULL,1,NULL,true,%L)', 'NEW-7', 'Nombre valido', cat, cust), '42501');

  -- Edicion con version y stock por diferencia
  SELECT version INTO v FROM products WHERE id = p1;
  res := update_product(p1, v, '{"priceCents":5999}', adm);
  PERFORM pg_temp.check_true((res ->> 'version')::bigint = v + 1, 'update sube la version');
  PERFORM pg_temp.expect_error(format('SELECT update_product(%L,%s,%L,%L)', p1, v, '{"priceCents":5000}', adm), 'LG409');
  PERFORM pg_temp.expect_error(format('SELECT update_product(%L,%s,%L,%L)', p1, v + 1, '{"sku":"NUEVO-1"}', adm), '22023');
  PERFORM pg_temp.expect_error(format('SELECT update_product(%L,%s,%L,%L)', p1, v + 1, '{}', adm), '22023');
  PERFORM pg_temp.expect_error(format('SELECT update_product(%L,%s,%L,%L)', p1, v + 1, '{"name":"Hola ' || E'\U0001F6B2' || '"}', adm), '23514');
  PERFORM pg_temp.check_true((SELECT version FROM products WHERE id = p1) = v + 1, 'rechazos no cambian la version');
  res := adjust_stock(p1, 5, 'restock', adm);
  PERFORM pg_temp.check_true((res ->> 'stock')::integer = 15, 'restock suma');
  PERFORM pg_temp.check_true((SELECT version FROM products WHERE id = p1) = v + 1, 'el stock no cambia la version');
  PERFORM pg_temp.expect_error(format('SELECT adjust_stock(%L,-100,%L,%L)', p1, 'damage', adm), 'LG412');
  PERFORM pg_temp.expect_error(format('SELECT adjust_stock(%L,1,%L,%L)', gen_random_uuid(), 'restock', adm), 'LG404');
  PERFORM pg_temp.expect_error(format('SELECT adjust_stock(%L,1,%L,%L)', p1, 'sale', adm), '22023');
  PERFORM pg_temp.expect_error(format('SELECT adjust_stock(%L,0,%L,%L)', p1, 'restock', adm), '22023');

  -- Pedido: camino feliz, copia de nombre y precio, descuento de stock
  res := place_store_order(cust, z, 'Calle 10 y Av 5', d, time '10:00', NULL, NULL, NULL, jsonb_build_array(pg_temp.item(p1, 2, 5999)), k);
  PERFORM pg_temp.check_true(res ->> 'status' = 'ok' AND (res ->> 'totalCents')::bigint = 11998 AND (res ->> 'replayed')::boolean = false, 'pedido ok');
  o := (res ->> 'orderId')::uuid;
  PERFORM pg_temp.check_true((SELECT stock_quantity FROM products WHERE id = p1) = 13, 'stock descontado');
  PERFORM pg_temp.check_true((SELECT status = 'pendiente' AND customer_user_id = cust FROM orders WHERE id = o), 'es un pedido normal del cliente');
  PERFORM pg_temp.check_true((SELECT product_name = 'Audifonos inalambricos serie 100' AND unit_price_cents = 5999 AND line_total_cents = 11998 FROM order_items WHERE order_id = o), 'copia de nombre y precio');
  PERFORM pg_temp.check_true((SELECT total_cents = 11998 AND items_count = 1 FROM store_orders WHERE order_id = o), 'encabezado de pedido');
  PERFORM pg_temp.check_true((SELECT delta = -2 AND balance_after = 13 AND reason = 'sale' FROM stock_movements WHERE order_id = o), 'movimiento de venta');

  -- Idempotencia: misma clave y mismo contenido = mismo pedido, sin descontar otra vez
  res2 := place_store_order(cust, z, 'Calle 10 y Av 5', d, time '10:00', NULL, NULL, NULL, jsonb_build_array(pg_temp.item(p1, 2, 5999)), k);
  PERFORM pg_temp.check_true((res2 ->> 'orderId')::uuid = o AND (res2 ->> 'replayed')::boolean = true, 'reintento devuelve el mismo pedido');
  PERFORM pg_temp.check_true((SELECT stock_quantity FROM products WHERE id = p1) = 13, 'el reintento no vuelve a descontar');
  PERFORM pg_temp.check_true((SELECT count(*) FROM orders WHERE customer_user_id = cust) = 1, 'un solo pedido');
  PERFORM pg_temp.expect_error(format('SELECT place_store_order(%L,%L,%L,%L,%L,NULL,NULL,NULL,%L,%L)', cust, z, 'Calle 10 y Av 5', d, '10:00', jsonb_build_array(pg_temp.item(p1, 3, 5999)), k), '23514');
  PERFORM pg_temp.expect_error(format('SELECT place_store_order(%L,%L,%L,%L,%L,NULL,NULL,NULL,%L,NULL)', cust, z, 'Calle 10 y Av 5', d, '10:00', jsonb_build_array(pg_temp.item(p1, 1, 5999))), '22004');

  -- Rechazos de negocio: no escriben nada
  res := place_store_order(cust, z, 'Calle 10 y Av 5', d, time '10:00', NULL, NULL, NULL, jsonb_build_array(pg_temp.item(p1, 1, 6999)), gen_random_uuid());
  PERFORM pg_temp.check_true(res ->> 'status' = 'conflict' AND res -> 'conflicts' -> 0 ->> 'reason' = 'price_changed' AND (res -> 'conflicts' -> 0 ->> 'currentPriceCents')::integer = 5999, 'precio cambiado');
  res := place_store_order(cust, z, 'Calle 10 y Av 5', d, time '10:00', NULL, NULL, NULL, jsonb_build_array(pg_temp.item(p2, 2, 1549)), gen_random_uuid());
  PERFORM pg_temp.check_true(res -> 'conflicts' -> 0 ->> 'reason' = 'insufficient_stock' AND (res -> 'conflicts' -> 0 ->> 'available')::integer = 1, 'stock insuficiente');
  res := place_store_order(cust, z, 'Calle 10 y Av 5', d, time '10:00', NULL, NULL, NULL, jsonb_build_array(pg_temp.item(gen_random_uuid(), 1, 100)), gen_random_uuid());
  PERFORM pg_temp.check_true(res -> 'conflicts' -> 0 ->> 'reason' = 'unavailable', 'producto inexistente');
  PERFORM update_product(p3, (SELECT version FROM products WHERE id = p3), '{"isActive":false}', adm);
  res := place_store_order(cust, z, 'Calle 10 y Av 5', d, time '10:00', NULL, NULL, NULL, jsonb_build_array(pg_temp.item(p3, 1, 2249)), gen_random_uuid());
  PERFORM pg_temp.check_true(res -> 'conflicts' -> 0 ->> 'reason' = 'unavailable', 'producto desactivado');
  PERFORM pg_temp.check_true((SELECT stock_quantity FROM products WHERE id = p2) = 1 AND (SELECT stock_quantity FROM products WHERE id = p3) = 5, 'los rechazos no descuentan stock');
  PERFORM pg_temp.check_true((SELECT count(*) FROM orders WHERE customer_user_id = cust) = 1, 'los rechazos no crean pedidos');
  -- Un conflicto queda como resultado de su clave: el reintento con la misma clave devuelve el mismo conflicto
  k := gen_random_uuid();
  res := place_store_order(cust, z, 'Calle 10 y Av 5', d, time '10:00', NULL, NULL, NULL, jsonb_build_array(pg_temp.item(p1, 1, 6999)), k);
  res2 := place_store_order(cust, z, 'Calle 10 y Av 5', d, time '10:00', NULL, NULL, NULL, jsonb_build_array(pg_temp.item(p1, 1, 6999)), k);
  PERFORM pg_temp.check_true(res2 ->> 'status' = 'conflict' AND (res2 ->> 'replayed')::boolean = true, 'el conflicto tambien es idempotente');

  -- Franjas
  res := place_store_order(cust, z, 'Calle 10 y Av 5', d, time '10:30', NULL, NULL, NULL, jsonb_build_array(pg_temp.item(p1, 1, 5999)), gen_random_uuid());
  PERFORM pg_temp.check_true(res -> 'conflicts' -> 0 ->> 'reason' = 'slot_invalid', 'franja fuera de la hora en punto');
  res := place_store_order(cust, z, 'Calle 10 y Av 5', d, time '07:00', NULL, NULL, NULL, jsonb_build_array(pg_temp.item(p1, 1, 5999)), gen_random_uuid());
  PERFORM pg_temp.check_true(res -> 'conflicts' -> 0 ->> 'reason' = 'slot_invalid', 'franja fuera de horario');
  res := place_store_order(cust, z, 'Calle 10 y Av 5', CURRENT_DATE - 1, time '10:00', NULL, NULL, NULL, jsonb_build_array(pg_temp.item(p1, 1, 5999)), gen_random_uuid());
  PERFORM pg_temp.check_true(res -> 'conflicts' -> 0 ->> 'reason' = 'slot_unavailable', 'franja pasada');
  PERFORM set_store_settings(1, 8, 20, 60, adm);
  res := place_store_order(cust2, z, 'Av Amazonas 123', d, time '11:00', NULL, NULL, NULL, jsonb_build_array(pg_temp.item(p1, 1, 5999)), gen_random_uuid());
  PERFORM pg_temp.check_true(res ->> 'status' = 'ok', 'primer pedido toma el cupo');
  res := place_store_order(cust, z, 'Calle 10 y Av 5', d, time '11:00', NULL, NULL, NULL, jsonb_build_array(pg_temp.item(p1, 1, 5999)), gen_random_uuid());
  PERFORM pg_temp.check_true(res -> 'conflicts' -> 0 ->> 'reason' = 'slot_full', 'franja llena');
  PERFORM pg_temp.check_true((SELECT count(*) FROM delivery_slots(z, d)) = 13, 'trece franjas entre las 8 y las 20');
  PERFORM pg_temp.check_true((SELECT reserved = 1 AND NOT available FROM delivery_slots(z, d) WHERE slot_time = time '11:00'), 'la franja de las 11 aparece llena');
  PERFORM pg_temp.check_true((SELECT available FROM delivery_slots(z, d) WHERE slot_time = time '15:00'), 'otra franja sigue libre');
  PERFORM set_store_settings(10, 8, 20, 60, adm);
  PERFORM pg_temp.expect_error(format('SELECT set_store_settings(10,20,8,60,%L)', adm), '23514');
  PERFORM pg_temp.expect_error(format('SELECT set_store_settings(10,8,20,60,%L)', cust), '42501');

  -- Formas invalidas
  PERFORM pg_temp.expect_error(format('SELECT place_store_order(%L,%L,%L,%L,%L,NULL,NULL,NULL,%L,%L)', cust, z, 'Calle 10 y Av 5', d, '10:00', '[]', gen_random_uuid()), '22023');
  PERFORM pg_temp.expect_error(format('SELECT place_store_order(%L,%L,%L,%L,%L,NULL,NULL,NULL,%L,%L)', cust, z, 'Calle 10 y Av 5', d, '10:00', jsonb_build_array(pg_temp.item(p1, 11, 5999)), gen_random_uuid()), '22023');
  PERFORM pg_temp.expect_error(format('SELECT place_store_order(%L,%L,%L,%L,%L,NULL,NULL,NULL,%L,%L)', cust, z, 'Calle 10 y Av 5', d, '10:00', jsonb_build_array(pg_temp.item(p1, 1, 5999), pg_temp.item(p1, 1, 5999)), gen_random_uuid()), '22023');
  PERFORM pg_temp.expect_error(format('SELECT place_store_order(%L,%L,%L,%L,%L,NULL,NULL,NULL,%L,%L)', cust, z, 'Calle 10 y Av 5', d, '10:00', '{"a":1}', gen_random_uuid()), '22023');
  PERFORM pg_temp.expect_error(format('SELECT place_store_order(%L,%L,%L,%L,%L,NULL,NULL,NULL,%L,%L)', cust, z, 'Calle 10 y Av 5', d, '10:00', (SELECT jsonb_agg(pg_temp.item(gen_random_uuid(), 1, 100)) FROM generate_series(1, 21)), gen_random_uuid()), '22023');
  PERFORM pg_temp.expect_error(format('SELECT place_store_order(%L,%L,%L,%L,%L,NULL,NULL,NULL,%L,%L)', adm, z, 'Calle 10 y Av 5', d, '10:00', jsonb_build_array(pg_temp.item(p1, 1, 5999)), gen_random_uuid()), '23503');
  PERFORM pg_temp.expect_error(format('SELECT place_store_order(%L,%L,%L,%L,%L,NULL,NULL,NULL,%L,%L)', gen_random_uuid(), z, 'Calle 10 y Av 5', d, '10:00', jsonb_build_array(pg_temp.item(p1, 1, 5999)), gen_random_uuid()), '23503');
  PERFORM pg_temp.expect_error(format('SELECT place_store_order(%L,%L,%L,%L,%L,NULL,NULL,NULL,%L,%L)', cust, gen_random_uuid(), 'Calle 10 y Av 5', d, '10:00', jsonb_build_array(pg_temp.item(p1, 1, 5999)), gen_random_uuid()), '23503');

  -- Inmutabilidad del historial
  PERFORM pg_temp.expect_error(format('UPDATE order_items SET quantity = 5 WHERE order_id = %L', o), '23514');
  PERFORM pg_temp.expect_error(format('DELETE FROM store_orders WHERE order_id = %L', o), '23514');
  PERFORM pg_temp.expect_error('DELETE FROM stock_movements', '23514');
  PERFORM pg_temp.expect_error('UPDATE product_events SET action = ''created''', '23514');

  -- El libro de stock cuadra con el stock actual de cada producto
  SELECT count(*) INTO n FROM products p
   WHERE p.stock_quantity <> coalesce((SELECT sum(delta) FROM stock_movements m WHERE m.product_id = p.id), 0);
  PERFORM pg_temp.check_true(n = 0, 'stock = suma de movimientos');
END $$;

-- Privilegios: la API solo lee tablas y ejecuta funciones
SET LOCAL ROLE logistica_app;
SELECT pg_temp.expect_error('INSERT INTO logistica.products(sku,name,category_id,price_cents) VALUES (''X-ABC'',''Nombre'',gen_random_uuid(),100)','42501');
SELECT pg_temp.expect_error('UPDATE logistica.products SET price_cents = 1','42501');
SELECT pg_temp.expect_error('DELETE FROM logistica.order_items','42501');
SELECT pg_temp.expect_error('UPDATE logistica.store_settings SET slot_capacity = 999','42501');
SELECT pg_temp.check_true((SELECT count(*) FROM logistica.products) >= 3, 'logistica_app lee productos');
RESET ROLE;
SET CONSTRAINTS ALL IMMEDIATE;
ROLLBACK;
SELECT 'PASS: tienda (texto, catalogo, version, stock, pedido, idempotencia, franjas, inmutabilidad y privilegios)' AS resultado;
