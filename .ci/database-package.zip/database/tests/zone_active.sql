\set ON_ERROR_STOP on
BEGIN;
SET search_path=logistica,pg_catalog;
CREATE FUNCTION pg_temp.check_true(value boolean,message text) RETURNS void LANGUAGE plpgsql AS $$
BEGIN IF value IS DISTINCT FROM true THEN RAISE EXCEPTION 'TEST_FAILED: %',message; END IF; END $$;

-- Activar y desactivar zonas (migracion 019).
DO $$
DECLARE z uuid; r uuid; o uuid; failed boolean; active boolean;
BEGIN
  z=create_zone('Zona Activa Prueba');
  PERFORM set_zone_coverage(z,-1.2491,-78.6167,5);

  -- Una zona sin trabajo se desactiva y se reactiva; repetir el cambio es idempotente.
  PERFORM pg_temp.check_true(set_zone_active(z,false),'se desactiva una zona sin trabajo');
  SELECT is_active INTO active FROM zones WHERE id=z;
  PERFORM pg_temp.check_true(active=false,'queda inactiva');
  PERFORM pg_temp.check_true(set_zone_active(z,false),'desactivar de nuevo es idempotente');
  PERFORM pg_temp.check_true(zone_for_point(-1.2491,-78.6167) IS DISTINCT FROM z,'una zona inactiva no atiende puntos');
  PERFORM pg_temp.check_true(set_zone_active(z,true),'se reactiva');
  SELECT is_active INTO active FROM zones WHERE id=z;
  PERFORM pg_temp.check_true(active,'queda activa');
  PERFORM pg_temp.check_true(zone_for_point(-1.2491,-78.6167)=z,'la zona reactivada vuelve a atender puntos');

  -- Una zona inexistente devuelve false.
  PERFORM pg_temp.check_true(set_zone_active('00000000-0000-4000-8000-000000000000',false)=false,'zona inexistente');

  -- Un pedido sin cerrar bloquea la desactivacion.
  o=create_order(z,'Av. Cevallos 123',current_date+1,'10:00');
  failed:=false;
  BEGIN PERFORM set_zone_active(z,false);
  EXCEPTION WHEN check_violation THEN failed:=true; END;
  PERFORM pg_temp.check_true(failed,'un pedido pendiente bloquea la desactivacion');

  -- Cancelado el pedido, ya se puede.
  UPDATE orders SET status='cancelado' WHERE id=o;
  PERFORM pg_temp.check_true(set_zone_active(z,false),'con el pedido cancelado se desactiva');
  PERFORM set_zone_active(z,true);

  -- Una ruta planificada tambien lo bloquea.
  INSERT INTO routes(zone_id,service_date,capacity_limit,algorithm_version) VALUES (z,current_date+1,4,'prueba') RETURNING id INTO r;
  failed:=false;
  BEGIN PERFORM set_zone_active(z,false);
  EXCEPTION WHEN check_violation THEN failed:=true; END;
  PERFORM pg_temp.check_true(failed,'una ruta planificada bloquea la desactivacion');
  PERFORM cancel_route(r);
  PERFORM pg_temp.check_true(set_zone_active(z,false),'con la ruta cancelada se desactiva');

  -- Una zona inactiva no recibe pedidos nuevos.
  failed:=false;
  BEGIN PERFORM create_order(z,'Av. Cevallos 456',current_date+1,'11:00');
  EXCEPTION WHEN OTHERS THEN failed:=true; END;
  PERFORM pg_temp.check_true(failed,'una zona inactiva no recibe pedidos');
END $$;
ROLLBACK;
SELECT 'PASS: zonas activar/desactivar (reglas de trabajo abierto, idempotencia, puntos y pedidos)' AS resultado;
