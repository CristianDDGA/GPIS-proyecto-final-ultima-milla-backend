\set ON_ERROR_STOP on
BEGIN;
SET search_path=logistica,pg_catalog;
CREATE FUNCTION pg_temp.check_true(value boolean,message text) RETURNS void LANGUAGE plpgsql AS $$
BEGIN IF value IS DISTINCT FROM true THEN RAISE EXCEPTION 'TEST_FAILED: %',message; END IF; END $$;
CREATE FUNCTION pg_temp.expect_error(command text,expected_state text) RETURNS void LANGUAGE plpgsql AS $$
BEGIN
  BEGIN EXECUTE command;
  EXCEPTION WHEN OTHERS THEN
    IF SQLSTATE=expected_state THEN RETURN; END IF;
    RAISE EXCEPTION 'TEST_FAILED: esperado %, recibido %: %',expected_state,SQLSTATE,SQLERRM;
  END;
  RAISE EXCEPTION 'TEST_FAILED: se esperaba rechazo de %',command;
END $$;

DO $$
DECLARE u uuid; off uuid; centro uuid; izamba uuid; sin_cob uuid; apagada uuid;
BEGIN
  -- ===================== Perfil: nombre y telefono
  INSERT INTO app_users(auth_subject, role, email, password_hash) VALUES ('p-1', 'cliente', 'perfil@test.local', 'scrypt$x$y') RETURNING id INTO u;
  PERFORM pg_temp.check_true(update_profile(u, '  Ana Perez ', '0991234567'), 'un usuario activo actualiza su perfil');
  PERFORM pg_temp.check_true((SELECT display_name = 'Ana Perez' AND phone = '0991234567' FROM app_users WHERE id = u), 'nombre recortado y telefono guardados');
  PERFORM pg_temp.check_true(update_profile(u, NULL, ''), 'se pueden borrar nombre y telefono');
  PERFORM pg_temp.check_true((SELECT display_name IS NULL AND phone IS NULL FROM app_users WHERE id = u), 'nombre y telefono quedan vacios');
  PERFORM pg_temp.expect_error(format('SELECT update_profile(%L, NULL, %L)', u, '099-123'), '23514');
  PERFORM pg_temp.expect_error(format('SELECT update_profile(%L, NULL, %L)', u, 'abc1234567'), '23514');
  PERFORM pg_temp.check_true(update_profile(u, NULL, '+593991234567'), 'acepta el formato internacional');
  INSERT INTO app_users(auth_subject, role, email, password_hash, is_active) VALUES ('p-2', 'cliente', 'inactivo@test.local', 'scrypt$x$y', false) RETURNING id INTO off;
  PERFORM pg_temp.check_true(NOT update_profile(off, 'Nadie', NULL), 'una cuenta inactiva no cambia su perfil');
  PERFORM pg_temp.check_true(NOT update_profile(gen_random_uuid(), 'Nadie', NULL), 'una cuenta inexistente responde false');

  -- ===================== Distancia
  PERFORM pg_temp.check_true(distance_km(-1.2491, -78.6167, -1.2491, -78.6167) = 0, 'misma coordenada, distancia cero');
  PERFORM pg_temp.check_true(abs(distance_km(-0.1807, -78.4678, -1.2491, -78.6167) - 119.9) < 2, 'Quito a Ambato son unos 120 km');

  -- ===================== Cobertura de zonas
  centro := create_zone('Prueba Ambato Centro');
  izamba := create_zone('Prueba Izamba');
  sin_cob := create_zone('Prueba Sin cobertura');
  apagada := create_zone('Prueba Apagada');
  PERFORM pg_temp.check_true(set_zone_coverage(centro, -1.2420, -78.6280, 3), 'fija la cobertura del centro');
  PERFORM pg_temp.check_true(set_zone_coverage(izamba, -1.2100, -78.5990, 3), 'fija la cobertura de Izamba');
  PERFORM pg_temp.check_true(set_zone_coverage(apagada, -1.2420, -78.6280, 10), 'fija la cobertura de una zona que se apagara');
  UPDATE zones SET is_active = false WHERE id = apagada;
  PERFORM pg_temp.check_true(NOT set_zone_coverage(gen_random_uuid(), -1.2, -78.6, 2), 'zona inexistente responde false');

  PERFORM pg_temp.check_true(zone_for_point(-1.2430, -78.6270) = centro, 'un punto del centro cae en la zona centro');
  PERFORM pg_temp.check_true(zone_for_point(-1.2110, -78.6000) = izamba, 'un punto de Izamba cae en Izamba');
  PERFORM pg_temp.check_true(zone_for_point(-1.2260, -78.6135) IN (centro, izamba), 'en el solape gana la de centro mas cercano');
  PERFORM pg_temp.check_true(zone_for_point(-0.1807, -78.4678) IS NULL, 'Quito no esta cubierto');
  PERFORM pg_temp.check_true(zone_for_point(40.4, -3.7) IS NULL, 'un punto fuera de Ecuador no tiene zona');
  PERFORM pg_temp.check_true(zone_for_point(NULL, NULL) IS NULL, 'sin punto no hay zona');

  PERFORM pg_temp.expect_error(format('SELECT set_zone_coverage(%L, -1.2, -78.6, 0)', sin_cob), '23514');
  PERFORM pg_temp.expect_error(format('SELECT set_zone_coverage(%L, -1.2, -78.6, 60)', sin_cob), '23514');
  PERFORM pg_temp.expect_error(format('SELECT set_zone_coverage(%L, 10, -78.6, 2)', sin_cob), '23514');
  PERFORM pg_temp.expect_error(format('SELECT set_zone_coverage(%L, -1.2, NULL, 2)', sin_cob), '23514');
  PERFORM pg_temp.check_true(set_zone_coverage(centro, NULL, NULL, NULL), 'se puede quitar la cobertura');
  PERFORM pg_temp.check_true(zone_for_point(-1.2430, -78.6270) IS NULL, 'sin cobertura la zona deja de detectarse');
END $$;
ROLLBACK;
