\set ON_ERROR_STOP on
BEGIN;
SET search_path=logistica,pg_catalog;
CREATE FUNCTION pg_temp.check_true(value boolean,message text) RETURNS void LANGUAGE plpgsql AS $$
BEGIN IF value IS DISTINCT FROM true THEN RAISE EXCEPTION 'TEST_FAILED: %',message; END IF; END $$;

-- Un nombre de zona no se repite, sin importar mayusculas ni espacios en los extremos (migracion 018).
DO $$
DECLARE z uuid; failed boolean := false; variant text;
BEGIN
  z=create_zone('Zona Unica Prueba');
  PERFORM pg_temp.check_true(z IS NOT NULL,'la primera zona se crea');
  FOREACH variant IN ARRAY ARRAY['Zona Unica Prueba','zona unica prueba','  ZONA UNICA PRUEBA  '] LOOP
    failed := false;
    BEGIN
      PERFORM create_zone(variant);
    EXCEPTION WHEN unique_violation THEN failed := true;
    END;
    PERFORM pg_temp.check_true(failed,'el nombre repetido se rechaza: "'||variant||'"');
  END LOOP;
  -- Un nombre distinto sigue permitido.
  PERFORM pg_temp.check_true(create_zone('Zona Unica Prueba Norte') IS NOT NULL,'un nombre distinto se crea');
  PERFORM pg_temp.check_true((SELECT count(*)=2 FROM zones WHERE lower(btrim(name)) LIKE 'zona unica prueba%'),'solo existen las dos zonas distintas');
END $$;
ROLLBACK;
SELECT 'PASS: nombre de zona unico (mayusculas, espacios y nombre distinto)' AS resultado;
