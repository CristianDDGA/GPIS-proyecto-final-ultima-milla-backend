\set ON_ERROR_STOP on
BEGIN;
SET search_path=logistica,pg_catalog;
CREATE FUNCTION pg_temp.check_true(value boolean,message text) RETURNS void LANGUAGE plpgsql AS $$
BEGIN IF value IS DISTINCT FROM true THEN RAISE EXCEPTION 'TEST_FAILED: %',message; END IF; END $$;
CREATE FUNCTION pg_temp.expect_error(command text,expected_state text) RETURNS void LANGUAGE plpgsql AS $$
BEGIN
  BEGIN EXECUTE command;
  EXCEPTION WHEN OTHERS THEN
    IF SQLSTATE=expected_state THEN RETURN; END IF;
    RAISE EXCEPTION 'TEST_FAILED: esperado %, recibido %: %',expected_state,SQLSTATE,SQLERRM;
  END;
  RAISE EXCEPTION 'TEST_FAILED: se esperaba rechazo de %',command;
END $$;

DO $$
DECLARE g uuid; g2 uuid; c uuid; c_pending uuid; adm uuid; drv uuid; res text;
BEGIN
  -- ===================== Alta con Google: cliente verificado, sin contrasena
  g := register_google_user('1001', 'Ana.Google@Gmail.com', 'Ana Perez');
  PERFORM pg_temp.check_true((SELECT role = 'cliente' AND email = 'ana.google@gmail.com' AND auth_subject = 'ana.google@gmail.com'
    AND password_hash IS NULL AND email_verified_via = 'google' AND email_verified_at IS NOT NULL AND google_sub = '1001' AND is_active
    FROM app_users WHERE id = g), 'el alta con Google crea un cliente verificado y sin contrasena');
  PERFORM pg_temp.expect_error('SELECT register_google_user(''1001'', ''otro@gmail.com'', NULL)', '23505'); -- identidad repetida
  PERFORM pg_temp.expect_error('SELECT register_google_user(''1002'', ''ANA.GOOGLE@gmail.com'', NULL)', '23505'); -- correo repetido
  PERFORM pg_temp.expect_error('SELECT register_google_user(''1003'', ''no-es-correo'', NULL)', '22023');
  PERFORM pg_temp.expect_error('SELECT register_google_user('''', ''x@gmail.com'', NULL)', '22023');
  PERFORM pg_temp.expect_error('INSERT INTO app_users(auth_subject, role, google_sub) VALUES (''g-mal'', ''cliente'', ''con espacios'')', '23514');
  PERFORM pg_temp.expect_error('INSERT INTO app_users(auth_subject, role, email_verified_at, email_verified_via) VALUES (''g-via'', ''cliente'', now(), ''facebook'')', '23514');

  -- ===================== Vincular: solo clientes activos con el correo confirmado por codigo
  INSERT INTO app_users(auth_subject, role, email, email_verified_at, email_verified_via, password_hash) VALUES ('g-c', 'cliente', 'cliente.codigo@test.local', now(), 'code', 'scrypt$x$y') RETURNING id INTO c;
  INSERT INTO app_users(auth_subject, role, email, password_hash) VALUES ('g-p', 'cliente', 'cliente.pendiente@test.local', 'scrypt$x$y') RETURNING id INTO c_pending;
  INSERT INTO app_users(auth_subject, role, email, email_verified_at, email_verified_via, password_hash) VALUES ('g-a', 'personal', 'jefe@test.local', now(), 'admin', 'scrypt$x$y') RETURNING id INTO adm;
  INSERT INTO app_users(auth_subject, role, email, email_verified_at, email_verified_via, password_hash) VALUES ('g-d', 'repartidor', 'conductor@test.local', now(), 'admin', 'scrypt$x$y') RETURNING id INTO drv;

  PERFORM pg_temp.check_true(link_google_account(c, '2001') = 'OK', 'un cliente confirmado por codigo se vincula');
  PERFORM pg_temp.check_true((SELECT google_sub = '2001' AND email_verified_via = 'code' AND password_hash IS NOT NULL FROM app_users WHERE id = c), 'al vincular conserva su contrasena y su verificacion');
  PERFORM pg_temp.check_true(link_google_account(c, '2001') = 'OK', 'vincular de nuevo la misma identidad es idempotente');
  PERFORM pg_temp.check_true(link_google_account(c, '2999') = 'NOT_ELIGIBLE', 'una cuenta ya vinculada no cambia de identidad');
  PERFORM pg_temp.check_true(link_google_account(c_pending, '2002') = 'NOT_ELIGIBLE', 'un correo sin confirmar no se vincula');
  PERFORM pg_temp.check_true(link_google_account(adm, '2003') = 'NOT_ELIGIBLE', 'un administrador no se vincula');
  PERFORM pg_temp.check_true(link_google_account(drv, '2004') = 'NOT_ELIGIBLE', 'un conductor no se vincula');
  PERFORM pg_temp.check_true(link_google_account(gen_random_uuid(), '2005') = 'NOT_ELIGIBLE', 'un usuario inexistente no se vincula');
  PERFORM pg_temp.check_true(link_google_account(g, '2006') = 'NOT_ELIGIBLE', 'una cuenta creada con Google (verificada por google) no cambia de identidad');
  UPDATE app_users SET email_verified_via = 'code', email_verified_at = now() WHERE id = c_pending;
  PERFORM pg_temp.check_true(link_google_account(c_pending, '2001') = 'SUB_IN_USE', 'una identidad no se puede vincular a dos cuentas');
  UPDATE app_users SET is_active = false WHERE id = c_pending;
  PERFORM pg_temp.check_true(link_google_account(c_pending, '2007') = 'NOT_ELIGIBLE', 'una cuenta inactiva no se vincula');
  PERFORM pg_temp.expect_error('SELECT link_google_account(gen_random_uuid(), NULL)', '22023');

  -- ===================== Un cliente vinculado que pasa a conductor conserva su identidad (aprobacion de solicitud)
  UPDATE app_users SET role = 'repartidor' WHERE id = c;
  PERFORM pg_temp.check_true((SELECT google_sub = '2001' AND role = 'repartidor' FROM app_users WHERE id = c), 'el cliente aprobado como conductor sigue vinculado');
  PERFORM pg_temp.check_true(link_google_account(c, '2001') = 'NOT_ELIGIBLE', 'y no se vuelve a vincular como conductor');
END $$;

-- Privilegios: la API ejecuta las dos funciones y solo lee la tabla
SET LOCAL ROLE logistica_app;
SELECT pg_temp.check_true(register_google_user('9001', 'privilegios@test.local', NULL) IS NOT NULL, 'logistica_app ejecuta register_google_user');
SELECT pg_temp.expect_error('UPDATE logistica.app_users SET google_sub = ''hack''', '42501');
SELECT pg_temp.check_true((SELECT count(*) FROM logistica.app_users WHERE google_sub = '9001') = 1, 'logistica_app puede buscar por google_sub');
RESET ROLE;
SET CONSTRAINTS ALL IMMEDIATE;
ROLLBACK;
SELECT 'PASS: inicio de sesion con Google (alta, vinculacion, reglas por rol, unicidad y privilegios)' AS resultado;
