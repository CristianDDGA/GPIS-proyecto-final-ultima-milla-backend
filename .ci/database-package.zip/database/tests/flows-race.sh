#!/bin/sh
# Carreras reales de los flujos (011), con varias conexiones PostgreSQL liberadas por una compuerta comun.
#   A) cancelar vs asignar a ruta a la vez   -> todos terminan cancelados, sin paradas vigentes y con el stock repuesto una vez
#   B) cancelar el mismo pedido varias veces -> una sola cancelacion real y una sola devolucion de stock
#   C) cobrar la misma entrega               -> misma clave: un solo cobro; claves distintas: gana una
#   D) reclamar avisos de correo en paralelo -> ningun aviso se reclama dos veces
set -eu
[ "$PGDATABASE" = logistica_test ] || { echo 'Solo se permite la base efimera logistica_test'; exit 1; }
OUT=/tmp/flows-race
rm -rf "$OUT"; mkdir -p "$OUT"
DATE=$(psql -X -At -c "SELECT (CURRENT_DATE + 6)::text")
ZONE='e3000000-0000-4000-8000-000000000001'
ADMIN='e1000000-0000-4000-8000-000000000001'
DRV='e2000000-0000-4000-8000-000000000001'
CAT='e4000000-0000-4000-8000-000000000001'
PROD='e5000000-0000-4000-8000-000000000001'
cust() { printf 'e0000000-0000-4000-8000-0000000000%02d' "$1"; }
uuid() { psql -X -At -c "SELECT gen_random_uuid()"; }
Q() { psql -X -At -v ON_ERROR_STOP=1 "$@"; }

psql -X -v ON_ERROR_STOP=1 <<SQL
INSERT INTO logistica.app_users(id, auth_subject, role) VALUES ('$ADMIN', 'frace-admin', 'personal'), ('$DRV', 'frace-driver', 'repartidor');
DO \$\$ BEGIN
  FOR i IN 1..4 LOOP
    INSERT INTO logistica.app_users(id, auth_subject, role)
      VALUES (('e0000000-0000-4000-8000-0000000000' || lpad(i::text, 2, '0'))::uuid, 'frace-c' || i, 'cliente');
  END LOOP;
END \$\$;
INSERT INTO logistica.zones(id, name) VALUES ('$ZONE', 'Zona carrera flujos');
INSERT INTO logistica.categories(id, name) VALUES ('$CAT', 'Carrera flujos');
INSERT INTO logistica.products(id, sku, name, category_id, price_cents, stock_quantity) VALUES ('$PROD', 'FRACE-1', 'Producto de carrera', '$CAT', 1500, 100);
INSERT INTO logistica.stock_movements(product_id, delta, reason, balance_after) VALUES ('$PROD', 100, 'initial', 100);
UPDATE logistica.store_settings SET slot_capacity = 50, first_slot_hour = 8, last_slot_hour = 20;
SQL
COURIER=$(Q -c "SELECT logistica.create_courier('Conductor de carrera', 20, '$DRV')")
Q -c "SELECT logistica.set_courier_availability('$COURIER', true)" >/dev/null

gate_open() {
  rm -f "$OUT/gate-ready"
  psql -X -v ON_ERROR_STOP=1 >"$OUT/gate.log" 2>&1 <<'SQL' &
SELECT pg_advisory_lock(888);
\! touch /tmp/flows-race/gate-ready
SELECT pg_sleep(1.5);
SELECT pg_advisory_unlock(888);
SQL
  i=0
  until [ -f "$OUT/gate-ready" ]; do
    i=$((i + 1)); [ "$i" -lt 100 ] || { cat "$OUT/gate.log"; echo 'FAIL: la compuerta no abrio'; exit 1; }
    sleep 0.1
  done
}
# gated <archivo> <sentencia SQL>
gated() { psql -X -At -v ON_ERROR_STOP=1 -c "SELECT pg_advisory_lock_shared(888); SELECT pg_advisory_unlock_shared(888); $2" >"$1" 2>&1 & }

new_order() { # <cliente> <hora> -> id del pedido
  Q -c "SELECT logistica.place_store_order('$(cust "$1")'::uuid, '$ZONE'::uuid, 'Av Flujos 123', '$DATE'::date, '$2'::time, NULL, NULL, NULL,
        '[{\"productId\":\"$PROD\",\"quantity\":2,\"unitPriceCents\":1500}]'::jsonb, '$(uuid)'::uuid) ->> 'orderId'"
}
stock() { Q -c "SELECT stock_quantity FROM logistica.products WHERE id='$PROD'"; }
fail() { echo "FAIL $*"; exit 1; }

# ---------------------------------------------------------------- A) cancelar vs asignar a ruta
ROUTE=$(Q -c "SELECT logistica.create_route('$ZONE'::uuid, '$DATE'::date, 20)")
ORDERS=""
for h in 08 09 10 11 12 13 14 15 16 17; do ORDERS="$ORDERS $(new_order 1 "$h:00")"; done
[ "$(stock)" -eq 80 ] || fail "A: stock inicial inesperado $(stock)"
gate_open
n=0
for o in $ORDERS; do
  n=$((n + 1))
  gated "$OUT/a-cancel-$n.log" "SELECT logistica.cancel_order('$o'::uuid, '$ADMIN'::uuid, 'otro', NULL)"
  gated "$OUT/a-add-$n.log" "SELECT logistica.add_order_to_route('$ROUTE'::uuid, '$o'::uuid)"
done
wait
cat "$OUT"/a-*.log | grep -qi "deadlock" && fail "A: hubo interbloqueos"
cat "$OUT"/a-*.log | grep -i "ERROR" | grep -viE "ORDER_ALREADY_ASSIGNED|ORDER_MOVED|ORDER_NOT_CANCELLABLE|cancelado" && fail "A: errores inesperados" || true
# Si la cancelacion perdio la carrera de lectura (ORDER_MOVED, la API reintenta), se repite igual que lo hace la API.
for o in $ORDERS; do
  if [ "$(Q -c "SELECT status FROM logistica.orders WHERE id='$o'")" != "cancelado" ]; then
    Q -c "SELECT logistica.cancel_order('$o'::uuid, '$ADMIN'::uuid, 'otro', NULL)" >/dev/null
  fi
  [ "$(Q -c "SELECT status FROM logistica.orders WHERE id='$o'")" = "cancelado" ] || fail "A: $o no quedo cancelado"
  [ "$(Q -c "SELECT count(*) FROM logistica.route_stops WHERE order_id='$o' AND released_at IS NULL")" -eq 0 ] || fail "A: $o conserva una parada vigente"
  [ "$(Q -c "SELECT count(*) FROM logistica.stock_movements WHERE order_id='$o' AND reason='cancel'")" -eq 1 ] || fail "A: $o no repuso stock exactamente una vez"
done
[ "$(stock)" -eq 100 ] || fail "A: stock final $(stock), se esperaba 100"
echo 'PASS A: diez cancelaciones contra diez asignaciones a ruta a la vez, todo consistente y stock repuesto una vez'

# ---------------------------------------------------------------- B) cancelar el mismo pedido varias veces
OB=$(new_order 2 '09:00')
[ "$(stock)" -eq 98 ] || fail "B: stock inicial"
gate_open
for i in 1 2 3 4 5 6; do
  if [ $((i % 2)) -eq 0 ]; then actor="$ADMIN"; else actor=$(cust 2); fi
  gated "$OUT/b-$i.log" "SELECT logistica.cancel_order('$OB'::uuid, '$actor'::uuid, 'cliente_desiste', NULL)"
done
wait
real=$(cat "$OUT"/b-*.log | grep -c '"alreadyCancelled": false' || true)
[ "$real" -eq 1 ] || { cat "$OUT"/b-*.log; fail "B: $real cancelaciones reales (se esperaba 1)"; }
[ "$(stock)" -eq 100 ] || fail "B: el stock no volvio a 100 ($(stock))"
[ "$(Q -c "SELECT count(*) FROM logistica.stock_movements WHERE order_id='$OB' AND reason='cancel'")" -eq 1 ] || fail "B: mas de una devolucion"
echo 'PASS B: seis cancelaciones simultaneas del mismo pedido, una sola devolucion de stock'

# ---------------------------------------------------------------- C) cobrar la misma entrega
OC=$(new_order 3 '10:00')
RC=$(Q -c "SELECT logistica.create_route('$ZONE'::uuid, '$DATE'::date, 20)")
Q -c "SELECT logistica.add_order_to_route('$RC'::uuid, '$OC'::uuid)" >/dev/null
Q -c "SELECT logistica.assign_route('$RC'::uuid, '$COURIER'::uuid)" >/dev/null
ver() { Q -c "SELECT version FROM logistica.orders WHERE id='$1'"; }
Q -c "SELECT logistica.change_order_status('$OC'::uuid, 'recogido', $(ver "$OC"), '$DRV'::uuid)" >/dev/null
Q -c "SELECT logistica.change_order_status('$OC'::uuid, 'en_camino', $(ver "$OC"), '$DRV'::uuid)" >/dev/null
V=$(ver "$OC"); KEY=$(uuid)
gate_open
for i in 1 2 3 4 5; do gated "$OUT/c-$i.log" "SELECT logistica.deliver_store_order('$OC'::uuid, $V, '$DRV'::uuid, 3000, '$KEY'::uuid)"; done
wait
ok=$(cat "$OUT"/c-[0-9].log | grep -c '"status": "entregado"' || true)
fresh=$(cat "$OUT"/c-[0-9].log | grep -c '"replayed": false' || true)
[ "$ok" -eq 5 ] || { cat "$OUT"/c-[0-9].log; fail "C: $ok respuestas ok de 5"; }
[ "$fresh" -eq 1 ] || fail "C: $fresh ejecuciones reales (se esperaba 1)"
[ "$(Q -c "SELECT count(*) FROM logistica.order_collections WHERE order_id='$OC'")" -eq 1 ] || fail "C: mas de un cobro"

echo 'PASS C: cinco cobros simultaneos con la misma clave, un solo cobro'

# ---------------------------------------------------------------- D) reclamar avisos de correo en paralelo
pend=$(Q -c "SELECT count(*) FROM logistica.notifications WHERE state='pendiente' AND locked_until IS NULL")
[ "$pend" -ge 20 ] || fail "D: pocos avisos pendientes ($pend)"
gate_open
for i in 1 2 3 4; do gated "$OUT/d-$i.log" "SELECT id FROM logistica.claim_notifications(10)"; done
wait
total=$(cat "$OUT"/d-[0-9].log | grep -cE '^[0-9a-f-]{36}$' || true)
unique=$(cat "$OUT"/d-[0-9].log | grep -E '^[0-9a-f-]{36}$' | sort -u | wc -l | tr -d ' ')
[ "$total" -eq 40 ] || fail "D: se reclamaron $total avisos (se esperaban 40)"
[ "$total" -eq "$unique" ] || fail "D: avisos reclamados dos veces ($total reclamados, $unique distintos)"
echo 'PASS D: cuatro trabajadores reclaman avisos a la vez, ninguno se reclama dos veces'

# ---------------------------------------------------------------- Invariantes finales
bad=$(Q -c "SELECT count(*) FROM logistica.products p WHERE p.stock_quantity <> coalesce((SELECT sum(delta) FROM logistica.stock_movements m WHERE m.product_id = p.id), 0) OR p.stock_quantity < 0")
[ "$bad" -eq 0 ] || fail "$bad productos con el libro de stock desajustado"
stuck=$(Q -c "SELECT count(*) FROM logistica.operation_requests WHERE status <> 'completada'")
[ "$stuck" -eq 0 ] || fail "$stuck solicitudes quedaron sin terminar"
echo 'PASS: flujos, concurrencia real (cancelar vs asignar, doble cancelacion, doble cobro, cola de correos)'
